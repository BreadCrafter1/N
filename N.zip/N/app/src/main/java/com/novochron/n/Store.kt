package com.novochron.n

import android.content.Context

/**
 * Everything N remembers between launches.
 *
 * The shared repo and the GitHub token are hardcoded below rather than typed in on first
 * launch — every install of this particular build talks to the same repo/token, so there's
 * nothing to configure except a display name.
 *
 * ⚠️ Because these are baked into the source (and from there into every built APK), treat this
 * token as public the moment it's committed: anyone with the APK can pull it back out with a
 * decompiler or even `strings`, and anyone with repo access can read it out of git history —
 * regardless of whether the GitHub repo itself is public or private. Use a token scoped to only
 * this one repo, and if it's ever exposed more widely than intended, rotate it on GitHub
 * (Settings → Developer settings → Personal access tokens) and paste the new one in here.
 */
class Store(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("n_prefs", Context.MODE_PRIVATE)

    val repo: String = "BreadCrafter1/chatter"
    val token: String = "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"

    var branch: String
        get() = prefs.getString("branch", "main") ?: "main"
        set(v) { prefs.edit().putString("branch", v.trim().ifBlank { "main" }).apply() }

    var name: String
        get() = prefs.getString("name", "") ?: ""
        set(v) { prefs.edit().putString("name", v.trim()).apply() }
}
