# N

A tiny Novochron-styled app: text, photo, video, and voice messages with one other person, using a
shared GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving
is polling the same folder.

## Setting the GitHub token
The token used to talk to the repo is no longer written into any source file, so it can't get
swept up in a `git push` and auto-revoked by GitHub's secret scanning.

- **Building locally:** copy `local.properties.example` to `local.properties` (already
  git-ignored) and paste your token in place of `ghp_your_token_here`.
- **Building via the "Build N" GitHub Actions workflow:** add the token as a repo secret instead
  — repo → **Settings → Secrets and variables → Actions → New repository secret**, name it
  `N_GH_TOKEN`, paste the token as the value. Then, in the workflow file's build step (the one
  that runs `./gradlew assembleDebug` or similar), add:
  ```yaml
  env:
    N_GH_TOKEN: ${{ secrets.N_GH_TOKEN }}
  ```
  (This project's workflow file wasn't part of what I edited — add that `env:` block to yours if
  it isn't there already, or ask me to write the whole workflow file if you'd rather start over.)

Either way, if you ever rotate the token, there's no source file to edit — just update
`local.properties` and/or the `N_GH_TOKEN` secret.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Tap `[mic]` to
   record a voice message — the button turns into a running timer and `[stop]`; tap it again (or
   `[cancel]` to discard) to send it. First tap asks for microphone permission.
3. Keep photos/videos/voice clips under ~1 MB — GitHub's Contents API can't hand back the base64
   body of a larger file, so anything bigger can be sent but won't display back in the app. A
   minute or so of voice recording (AAC, in an .m4a container) comfortably fits under that limit.

Tap `[repo]` any time to change the repo, token, or name.
