package com.novochron.n

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class RepoRef(val owner: String, val name: String) {
    val full: String get() = "$owner/$name"
    companion object {
        fun parse(text: String): RepoRef? {
            val cleaned = text.trim()
                .removePrefix("https://github.com/")
                .removePrefix("http://github.com/")
                .removePrefix("github.com/")
                .removeSuffix(".git")
                .removeSuffix("/")
            val parts = cleaned.split("/").filter { it.isNotBlank() }
            return if (parts.size >= 2) RepoRef(parts[0], parts[1]) else null
        }
    }
}

data class RepoFile(val path: String, val isDir: Boolean, val sha: String = "")

class GitHubApiException(val code: Int, val body: String) : IOException("GitHub API HTTP $code: $body")

/**
 * Thin GitHub REST client, just enough to use a repo as a shared mailbox: list a folder, read a
 * file's decoded text or raw bytes, and commit (create/update) a file. Auth is a plain personal
 * access token pasted in by the user (Settings on github.com > Developer settings > Tokens,
 * "repo" scope) rather than the OAuth device flow Novochron uses, so there's no client ID to
 * register - paste a token and go.
 */
class GitHubClient(private val token: String, private val branch: String = "main") {

    suspend fun listFiles(path: String, repo: RepoRef): List<RepoFile> = withContext(Dispatchers.IO) {
        val clean = encodePath(path.trim('/'))
        val url = "https://api.github.com/repos/${repo.full}/contents/$clean?ref=$branch"
        val body = try { getRaw(url) } catch (e: GitHubApiException) {
            if (e.code == 404) return@withContext emptyList() else throw e
        }
        if (body.trimStart().startsWith("[")) {
            val arr = JSONArray(body)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RepoFile(o.getString("path"), o.getString("type") == "dir", o.optString("sha", ""))
            }
        } else {
            val o = JSONObject(body)
            listOf(RepoFile(o.getString("path"), false, o.optString("sha", "")))
        }
    }

    /** Decoded text content, or null if the file can't be read as text. */
    suspend fun readFile(path: String, repo: RepoRef): String? = withContext(Dispatchers.IO) {
        val o = getContents(path, repo) ?: return@withContext null
        if (o.optString("encoding") != "base64") return@withContext null
        String(Base64.decode(o.getString("content").replace("\n", ""), Base64.DEFAULT), Charsets.UTF_8)
    }

    /** Raw decoded bytes (photo/video). Files over ~1 MB can't be read back via this endpoint. */
    suspend fun readFileBytes(path: String, repo: RepoRef): ByteArray? = withContext(Dispatchers.IO) {
        val o = getContents(path, repo) ?: return@withContext null
        if (o.optString("encoding") != "base64") return@withContext null
        Base64.decode(o.getString("content").replace("\n", ""), Base64.DEFAULT)
    }

    private fun getContents(path: String, repo: RepoRef): JSONObject? {
        val clean = encodePath(path.trim('/'))
        val url = "https://api.github.com/repos/${repo.full}/contents/$clean?ref=$branch"
        return try { get(url, "application/vnd.github.object+json") } catch (e: GitHubApiException) {
            if (e.code == 404) null else throw e
        }
    }

    suspend fun commitFile(path: String, content: String, message: String, repo: RepoRef): Unit =
        commitBytes(path, content.toByteArray(Charsets.UTF_8), message, repo)

    suspend fun commitBytes(path: String, bytes: ByteArray, message: String, repo: RepoRef): Unit =
        withContext(Dispatchers.IO) {
            val existing = getContents(path, repo)
            val clean = encodePath(path.trim('/'))
            val url = "https://api.github.com/repos/${repo.full}/contents/$clean"
            val body = JSONObject().apply {
                put("message", message)
                put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
                put("branch", branch)
                existing?.optString("sha")?.let { if (it.isNotBlank()) put("sha", it) }
            }
            put(url, body)
            Unit
        }

    /** Deletes one existing file in one commit. [sha] is the file's current blob sha (from [listFiles]). */
    suspend fun deleteFile(path: String, sha: String, message: String, repo: RepoRef): Unit =
        withContext(Dispatchers.IO) {
            val clean = encodePath(path.trim('/'))
            val url = "https://api.github.com/repos/${repo.full}/contents/$clean"
            val body = JSONObject().apply {
                put("message", message)
                put("sha", sha)
                put("branch", branch)
            }
            delete(url, body)
            Unit
        }

    /**
     * Recursively deletes every file under [path] (walking into subfolders like Msg/media), one
     * commit per file. Used by "clear chat history" to wipe the whole Msg/ tree in the shared repo.
     */
    suspend fun deleteAll(path: String, repo: RepoRef, message: String): Unit = withContext(Dispatchers.IO) {
        for (f in listFiles(path, repo)) {
            if (f.isDir) deleteAll(f.path, repo, message) else deleteFile(f.path, f.sha, message, repo)
        }
    }

    // ---------------- plain HTTP helpers ----------------

    private fun get(url: String, accept: String = "application/vnd.github+json"): JSONObject =
        JSONObject(getRaw(url, accept))

    private fun getRaw(url: String, accept: String = "application/vnd.github+json"): String {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        conn.requestMethod = "GET"
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", accept)
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299) throw GitHubApiException(code, text)
        return text
    }

    private fun put(url: String, body: JSONObject): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        conn.requestMethod = "PUT"
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299) throw GitHubApiException(code, text)
        return JSONObject(text)
    }

    private fun delete(url: String, body: JSONObject): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        conn.requestMethod = "DELETE"
        conn.doOutput = true
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299) throw GitHubApiException(code, text)
        return if (text.isBlank()) JSONObject() else JSONObject(text)
    }

    private fun readBody(conn: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun encodePath(path: String): String =
        path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
}
