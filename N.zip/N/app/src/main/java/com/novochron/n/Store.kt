package com.novochron.n

import android.content.Context

/**
 * Everything N remembers between launches.
 *
 * The shared repo defaults to the hardcoded value below — every install of this particular
 * build talks to the same repo out of the box. That default can be overridden per-install from
 * the debug panel (a "custom repo" set there is stored locally in prefs and takes priority);
 * clearing it falls back to the built-in default again.
 *
 * The GitHub token is NOT hardcoded here. It's injected at build time into BuildConfig from
 * either local.properties (git-ignored — see local.properties.example) for local builds, or
 * an N_GH_TOKEN GitHub Actions secret for CI builds. See app/build.gradle.kts.
 *
 * ⚠️ It still ends up baked into the built APK as a string constant — anyone with the APK can
 * pull it back out with a decompiler or even `strings`, same as before. What this setup fixes
 * is the token being committed to git/GitHub, where secret scanning would auto-revoke it (or
 * where anyone with repo access could read it out of history) regardless of whether the repo
 * is public or private. Use a token scoped to only this one repo, and if it's ever exposed
 * more widely than intended, rotate it on GitHub (Settings → Developer settings → Personal
 * access tokens).
 */
class Store(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("n_prefs", Context.MODE_PRIVATE)

    private val defaultRepo = "BreadCrafter1/chonke"

    /** The custom repo override, or "" if none is set (falls back to [defaultRepo]). */
    var customRepo: String
        get() = prefs.getString("custom_repo", "") ?: ""
        set(v) { prefs.edit().putString("custom_repo", v.trim()).apply() }

    /** The "home" repo: the custom override if one is set, else the built-in default. The secret word and voice keys live here. */
    val baseRepo: String get() = customRepo.ifBlank { defaultRepo }

    /**
     * Set when a repo voice key was spoken at the gate: N runs on that repo until the app locks or
     * is closed. Kept in memory only (shared by every Store in the process) — never persisted, so
     * every fresh launch starts on [baseRepo] again.
     */
    var sessionRepo: String
        get() = sessionRepoValue
        set(v) { sessionRepoValue = v.trim() }

    /** The repo actually in use right now: the voice-key repo if one was picked, else [baseRepo]. */
    val repo: String get() = sessionRepoValue.ifBlank { baseRepo }

    val token: String = BuildConfig.GITHUB_TOKEN

    var branch: String
        get() = prefs.getString("branch", "main") ?: "main"
        set(v) { prefs.edit().putString("branch", v.trim().ifBlank { "main" }).apply() }

    var name: String
        get() = prefs.getString("name", "") ?: ""
        set(v) { prefs.edit().putString("name", v.trim()).apply() }

    // ---- appearance (local to this device; only the background theme is synced through the repo) ----

    /** true = dark mode (the original look), false = light mode. */
    var darkMode: Boolean
        get() = prefs.getBoolean("dark_mode", true)
        set(v) { prefs.edit().putBoolean("dark_mode", v).apply() }

    /** Accent colour (buttons, labels): a swatch key like "blue", a "#RRGGBB" hex, or "" for the default. */
    var accentKey: String
        get() = prefs.getString("accent_key", "") ?: ""
        set(v) { prefs.edit().putString("accent_key", v.trim()).apply() }

    /** Letter colour: a swatch key, a "#RRGGBB" hex, or "" for the default. */
    var textKey: String
        get() = prefs.getString("text_key", "") ?: ""
        set(v) { prefs.edit().putString("text_key", v.trim()).apply() }

    /**
     * Last background theme received from / sent to the repo, so it shows instantly on launch.
     * Stored PER REPO: a theme set in one repo never shows up in another. (Older builds kept a single
     * universal copy; it's only read as a fallback for the home repo, so nothing is lost on update.)
     */
    var bgThemeJson: String
        get() = prefs.getString("bg_theme_json:$repo", null)
            ?: (if (repo == baseRepo) prefs.getString("bg_theme_json", "") else "") ?: ""
        set(v) { prefs.edit().putString("bg_theme_json:$repo", v).apply() }

    /** Cached nicknames/pictures of everyone in the current repo (JSON), per repo like the theme. */
    var profilesJson: String
        get() = prefs.getString("profiles_json:$repo", null)
            ?: (if (repo == baseRepo) prefs.getString("profiles_json", "") else "") ?: ""
        set(v) { prefs.edit().putString("profiles_json:$repo", v).apply() }

    // ---- sign-in (ONE account system for the whole app: accounts live in the home repo and the saved
    // login is shared by every repo, so a voice-key repo never asks you to sign in again) ----

    private var authRaw: String
        get() = prefs.getString("auth_global", null)
            ?: prefs.getString("auth:$baseRepo", "") ?: ""      // fallback: login saved by the older per-repo build
        set(v) { prefs.edit().putString("auth_global", v).apply() }

    /** The account hash saved when [name] last signed in on this phone in this repo, or "" if not signed in as that name. */
    fun savedAuthHash(name: String): String {
        val p = authRaw.split("\n")
        return if (p.size == 2 && p[0] == name) p[1] else ""
    }

    fun saveAuth(name: String, hash: String) { authRaw = name + "\n" + hash }

    fun clearAuth() { prefs.edit().remove("auth:$baseRepo").apply(); authRaw = "" }

    // ---- notifications ----

    var notifEnabled: Boolean
        get() = prefs.getBoolean("notif_enabled", false)
        set(v) { prefs.edit().putBoolean("notif_enabled", v).apply() }

    /** false (default) = notifications only say "new message from X"; true = they include the text. */
    var notifPreview: Boolean
        get() = prefs.getBoolean("notif_preview", false)
        set(v) { prefs.edit().putBoolean("notif_preview", v).apply() }

    /** Month folder the background listener last looked at ("" = it has never run yet). */
    var notifBucket: String
        get() = prefs.getString("notif_bucket", "") ?: ""
        set(v) { prefs.edit().putString("notif_bucket", v).apply() }

    /** Message files in [notifBucket] the background listener has already dealt with. */
    var notifSeen: Set<String>
        get() = HashSet(prefs.getStringSet("notif_seen", emptySet()) ?: emptySet())
        set(v) { prefs.edit().putStringSet("notif_seen", HashSet(v)).apply() }

    private companion object {
        @Volatile var sessionRepoValue: String = ""
    }
}
