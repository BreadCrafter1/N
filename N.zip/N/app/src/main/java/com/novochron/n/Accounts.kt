package com.novochron.n

import android.util.Base64
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// ---------------------------------------------------------------------------------------------
// Accounts: a username is claimed with a password.
//
// ONE account system for the whole app, not one per repo: accounts always live in the HOME repo
// (Store.baseRepo), and the saved sign-in is shared by every repo. Opening a voice-key repo reuses
// the same account — same username, same password, no second sign-in. (Profiles, themes etc. are
// still per repo.)
//
// There is no server, so accounts live in the home repo like everything else: one small file per
// username at Config/accounts/<name>.json holding a random salt and a PBKDF2-SHA256 hash of the
// password (never the password itself). Usernames are matched ignoring case/punctuation (the file
// name is safeName(user)), so "Bob" and "bob" are the same account.
//
//   * Username nobody has used  -> "create account": pick a password and the name is yours.
//   * Username that has account -> "sign in": the password must match.
//   * A name already in use on this phone from before accounts existed has no account file yet, so
//     the first launch asks for a password to protect it (whoever sets it first owns the name).
//
// A successful sign-in is remembered on this phone (per repo) as the account's hash, so you are not
// asked again — until the password changes somewhere else, or you log out.
//
// Honest limits: the check runs inside the app, and the app carries the repo token. Someone who
// pulls that token out of the APK could read the hashes (so use a long password) or edit the repo
// directly. This stops casual impersonation inside the app; it is not server-grade security.
// ---------------------------------------------------------------------------------------------

data class Account(val user: String, val salt: String, val hash: String, val iter: Int, val created: Long)

object Accounts {
    const val DIR = "Config/accounts"
    const val MIN_LEN = 6
    private const val ITER = 150_000

    fun path(user: String) = "$DIR/${safeName(user)}.json"

    private fun pbkdf2(password: String, salt: ByteArray, iter: Int): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, iter, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally { spec.clearPassword() }
    }

    private fun toJson(a: Account): String = JSONObject().apply {
        put("user", a.user); put("salt", a.salt); put("hash", a.hash); put("iter", a.iter); put("created", a.created)
    }.toString(2)

    private fun parse(text: String): Account? = try {
        val o = JSONObject(text)
        val u = o.optString("user", ""); val s = o.optString("salt", ""); val h = o.optString("hash", "")
        if (u.isBlank() || s.isBlank() || h.isBlank()) null
        else Account(u, s, h, o.optInt("iter", ITER), o.optLong("created", 0L))
    } catch (_: Exception) { null }

    private suspend fun make(user: String, password: String, created: Long): Account = withContext(Dispatchers.IO) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = pbkdf2(password, salt, ITER)
        Account(
            user, Base64.encodeToString(salt, Base64.NO_WRAP), Base64.encodeToString(hash, Base64.NO_WRAP),
            ITER, created
        )
    }

    /** The account for [user], or null if that username is free. Throws if the repo can't be reached. */
    suspend fun fetch(client: GitHubClient, repo: RepoRef, user: String): Account? =
        client.readFile(path(user), repo)?.let { parse(it) }

    /** True if [password] is the right one for [acc]. */
    suspend fun verify(acc: Account, password: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val salt = Base64.decode(acc.salt, Base64.NO_WRAP)
            MessageDigest.isEqual(Base64.decode(acc.hash, Base64.NO_WRAP), pbkdf2(password, salt, acc.iter))
        } catch (_: Exception) { false }
    }

    /**
     * Claims [user]. The file is created with commitFile, which fails (HTTP 422) if it already exists,
     * so two people claiming the same name at once can't both win — the loser gets a GitHubApiException.
     */
    suspend fun register(client: GitHubClient, repo: RepoRef, user: String, password: String): Account {
        val acc = make(user, password, System.currentTimeMillis())
        client.commitFile(path(user), toJson(acc), "n: account", repo)
        return acc
    }

    /** Replaces the password of [acc] (the caller has already checked the old one). */
    suspend fun changePassword(client: GitHubClient, repo: RepoRef, acc: Account, newPassword: String): Account {
        val n = make(acc.user, newPassword, acc.created)
        client.writeFile(path(acc.user), toJson(n), "n: password", repo)
        return n
    }
}

/**
 * Shown in place of the chat until this phone is signed in: pick a username, then either sign in
 * (it has an account) or create the account (it doesn't). [onDone] runs once store.name and the
 * saved login are set.
 */
@Composable
fun AuthScreen(store: Store, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    val repo = remember(store.baseRepo) { RepoRef.parse(store.baseRepo) }   // accounts live in the home repo
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    var name by remember { mutableStateOf(store.name) }
    var account by remember { mutableStateOf<Account?>(null) }
    var stage by remember { mutableStateOf(0) }          // 0 = username, 1 = sign in, 2 = create account
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var fails by remember { mutableStateOf(0) }
    var lockUntil by remember { mutableStateOf(0L) }

    fun errText(e: Exception): String = if (e is GitHubApiException) "HTTP ${e.code}" else (e.message ?: "unknown error").take(80)

    fun finish(acc: Account) {
        store.name = acc.user
        store.saveAuth(acc.user, acc.hash)
        DebugLog.add("signed in")
        onDone()
    }

    fun lookup() {
        val n = name.trim().take(30)
        if (n.isEmpty()) { status = "Enter a username."; return }
        if (client == null || repo == null) { status = "No repo/token configured."; return }
        name = n
        scope.launch {
            busy = true; status = ""
            try {
                val acc = Accounts.fetch(client, repo, n)
                account = acc; pw = ""; pw2 = ""
                stage = if (acc != null) 1 else 2
            } catch (e: Exception) {
                status = "Couldn't reach the repo: ${errText(e)}"
            }
            busy = false
        }
    }

    fun signIn() {
        val acc = account ?: return
        if (System.currentTimeMillis() < lockUntil) { status = "Too many wrong passwords. Wait a few seconds."; return }
        scope.launch {
            busy = true; status = ""
            val ok = Accounts.verify(acc, pw)
            busy = false
            if (ok) finish(acc) else {
                fails++
                if (fails >= 5) { lockUntil = System.currentTimeMillis() + 30_000; fails = 0; status = "Too many wrong passwords. Wait 30 seconds." }
                else status = "Wrong password."
                pw = ""
            }
        }
    }

    fun create() {
        if (pw.length < Accounts.MIN_LEN) { status = "Use at least ${Accounts.MIN_LEN} characters."; return }
        if (pw != pw2) { status = "The two passwords don't match."; return }
        if (client == null || repo == null) { status = "No repo/token configured."; return }
        scope.launch {
            busy = true; status = ""
            try {
                finish(Accounts.register(client, repo, name.trim(), pw))
            } catch (e: Exception) {
                if (e is GitHubApiException && e.code == 422) {
                    status = "Somebody just claimed that username. Sign in or pick another."
                    stage = 0
                } else status = "Couldn't create the account: ${errText(e)}"
            }
            busy = false
        }
    }

    // A name that is already saved on this phone: go straight to its sign-in / set-password step.
    LaunchedEffect(Unit) { if (name.isNotBlank()) lookup() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
        when (stage) {
            0 -> {
                Text("sign in or create an account", color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text("Pick your username. If it already has a password you'll sign in; if it's free, you'll claim it.", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                NTextField(name, { name = it.take(30) }, "username")
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { lookup() }, enabled = !busy) { Text("[continue]", color = Accent, fontFamily = TermFont, fontSize = 14.sp) }
            }
            1 -> {
                Text("welcome back, ${account?.user ?: name}", color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text("This username has a password.", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                NTextField(pw, { pw = it }, "password", password = !show)
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    TextButton(onClick = { signIn() }, enabled = !busy && pw.isNotEmpty()) { Text("[sign in]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                    TextButton(onClick = { show = !show }) { Text(if (show) "[hide]" else "[show]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
                    TextButton(onClick = { stage = 0; status = ""; pw = "" }) { Text("[not you?]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
                }
            }
            else -> {
                val legacy = name.trim() == store.name
                Text(if (legacy) "protect \"${name.trim()}\" with a password" else "create account \"${name.trim()}\"", color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (legacy) "This username has no password yet. Set one now so nobody else can sign in as you." else "Nobody has used this username yet. Choose a password to claim it.",
                    color = Dim, fontFamily = TermFont, fontSize = 12.sp
                )
                Spacer(Modifier.height(12.dp))
                NTextField(pw, { pw = it }, "password (${Accounts.MIN_LEN}+ characters)", password = !show)
                Spacer(Modifier.height(6.dp))
                NTextField(pw2, { pw2 = it }, "repeat password", password = !show)
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    TextButton(onClick = { create() }, enabled = !busy) { Text("[create account]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                    TextButton(onClick = { show = !show }) { Text(if (show) "[hide]" else "[show]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
                    TextButton(onClick = { stage = 0; status = ""; pw = ""; pw2 = "" }) { Text("[back]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
                }
                Text("There is no password reset — if you forget it, the account has to be deleted from the repo.", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        if (busy) { Spacer(Modifier.height(8.dp)); Text("working…", color = Dim, fontFamily = TermFont, fontSize = 12.sp) }
        if (status.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp) }
    }
}
