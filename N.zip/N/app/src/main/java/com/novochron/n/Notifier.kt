package com.novochron.n

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------
// Message notifications.
//
// There's no server to push from, so "notify me of new messages" has to mean "keep checking the
// repo while the app isn't on screen". MessageService is a small foreground service (Android
// requires a persistent, silent notification for that) that polls the current month's Msg/
// folder every few seconds — the same cheap ETag'd listing the chat itself uses — and posts a
// normal notification for each new message from someone else.
//
// Nothing is notified while the app is on screen (you can already see the chat), and the first
// run only records what's already there, so enabling notifications doesn't dump old history.
// ---------------------------------------------------------------------------------------------

private const val CH_MESSAGES = "n_messages"
const val CH_SYNC = "n_sync"
private const val CH_CALLS = "n_calls"
private const val CALL_NOTIF_ID = 4
private const val SYNC_NOTIF_ID = 3
private const val BG_POLL_MS = 3_000L
private const val BG_RETRY_MS = 30_000L

/** Whether the UI is currently visible — set by MainActivity (onStart/onStop). */
object AppState {
    @Volatile var foreground = false
}

object Notifier {
    /** Unread count per sender since the app was last in the foreground (so bursts collapse into one notification). */
    private val unread = HashMap<String, Int>()

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_MESSAGES, "Messages", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_CALLS, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Rings when someone calls you while N is closed."
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 800, 600, 800, 600, 800)
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
        })
        nm.createNotificationChannel(NotificationChannel(CH_SYNC, "Background check", NotificationManager.IMPORTANCE_MIN).apply {
            description = "Required by Android while N waits for messages. Silent, no icon in the status bar. You can switch this channel off."
            setShowBadge(false)
            lockscreenVisibility = Notification.VISIBILITY_SECRET
        })
    }

    /** True if the OS will actually show our notifications (permission on Android 13+, not switched off). */
    fun canPost(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    fun start(ctx: Context) {
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, MessageService::class.java)) }
        catch (e: Exception) { DebugLog.add("notif: couldn't start listener: ${e.message?.take(60)}") }
    }

    fun stop(ctx: Context) { ctx.stopService(Intent(ctx, MessageService::class.java)) }

    private fun openAppIntent(ctx: Context, requestCode: Int) = PendingIntent.getActivity(
        ctx, requestCode,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Posts (or updates) the notification for [from]. [preview] is a short description like "hi!" or "sent a photo". */
    fun showMessage(ctx: Context, from: String, preview: String, showText: Boolean) {
        if (!canPost(ctx)) return
        ensureChannels(ctx)
        val count = synchronized(unread) { val c = (unread[from] ?: 0) + 1; unread[from] = c; c }
        val title = if (showText) from else "Constellation"
        val body = when {
            !showText -> if (count == 1) "New message from $from" else "$count new messages from $from"
            count == 1 -> preview
            else -> "$preview  (+${count - 1} more)"
        }
        // What the lock screen shows when the phone is set to hide sensitive content.
        val public = Notification.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("Constellation").setContentText("New message")
            .build()
        val n = Notification.Builder(ctx, CH_MESSAGES)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setPublicVersion(public)
            .setContentIntent(openAppIntent(ctx, 1))
            .setAutoCancel(true)
            .setWhen(System.currentTimeMillis())
            .build()
        try { NotificationManagerCompat.from(ctx).notify(from.hashCode(), n) } catch (_: SecurityException) {}
    }

    /** A ringing "incoming call" alert. It repeats the ringtone until answered, cancelled, or the ring times out. */
    fun showCall(ctx: Context, from: String, video: Boolean, showName: Boolean) {
        if (!canPost(ctx)) return
        ensureChannels(ctx)
        val kind = if (video) "video call" else "call"
        val open = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, MainActivity::class.java).putExtra("incoming_call", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val public = Notification.Builder(ctx, CH_CALLS)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Constellation").setContentText("Incoming $kind")
            .build()
        val n = Notification.Builder(ctx, CH_CALLS)
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(if (showName) "$from is calling" else "Incoming $kind")
            .setContentText(if (showName) "Incoming $kind · tap to answer" else "Tap to answer")
            .setCategory(Notification.CATEGORY_CALL)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setPublicVersion(public)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setAutoCancel(true)
            .setTimeoutAfter(RING_TIMEOUT_MS)
            .build()
        n.flags = n.flags or Notification.FLAG_INSISTENT          // keep ringing until it's dealt with
        try { NotificationManagerCompat.from(ctx).notify(CALL_NOTIF_ID, n) } catch (_: SecurityException) {}
    }

    fun clearCall(ctx: Context) {
        try { NotificationManagerCompat.from(ctx).cancel(CALL_NOTIF_ID) } catch (_: Exception) {}
    }

    /** Removes message notifications (not the background-check one) — called when the app comes to the front. */
    fun clearMessages(ctx: Context) {
        synchronized(unread) { unread.clear() }
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        try {
            nm.activeNotifications.filter { it.notification.channelId == CH_MESSAGES }.forEach { nm.cancel(it.id) }
        } catch (_: Exception) {}
    }
}

/** Auto-start: brings the listener back after a reboot or after N is updated. */
class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val store = Store(context.applicationContext)
        if (store.notifEnabled && Notifier.canPost(context)) Notifier.start(context.applicationContext)
    }
}

class MessageService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifier.ensureChannels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH_SYNC)
            .setContentTitle("Constellation")
            .setContentText("Listening for new messages")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentIntent(open)
            .setOngoing(true)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .setPriority(Notification.PRIORITY_MIN)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SYNC_NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)   // no time limit, allowed at boot
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(SYNC_NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(SYNC_NOTIF_ID, n)
        }
        if (job == null) job = scope.launch { listen() }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun listen() {
        val store = Store(applicationContext)
        val repo = RepoRef.parse(store.baseRepo)   // background alerts always follow the home repo
        if (repo == null || store.token.isBlank()) { stopSelf(); return }
        val client = GitHubClient(store.token, store.branch)
        Profiles.load(store)
        var failing = false
        var cycle = 0
        while (currentCoroutineContext().isActive) {
            if (!store.notifEnabled) { stopSelf(); return }
            var failed = false
            try { checkOnce(store, client, repo) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { failed = true; DebugLog.add("notif poll: ${e.message?.take(60)}") }
            try { checkCalls(store, client, repo) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { failed = true; DebugLog.add("call poll: ${e.message?.take(60)}") }
            failing = failed
            // Every so often, pick up nickname changes so alerts show the name you'd expect.
            if (++cycle % 10 == 0) {
                try { Profiles.syncOnce(applicationContext, store, client, repo, false) } catch (_: Exception) {}
            }
            delay(if (failing) BG_RETRY_MS else BG_POLL_MS)
        }
    }

    // ---- incoming calls ----
    private var lastRoomSha = ""
    private val notifiedCalls = HashSet<String>()
    private var ringingCallId: String? = null
    private var ringingInitiator = ""
    private var ringingUntil = 0L

    /** Watches Call/room.json (the same ring signal the app uses) and rings the phone for a call from someone else. */
    private suspend fun checkCalls(store: Store, client: GitHubClient, repo: RepoRef) {
        val files = client.listFiles("Call", repo)          // 304 / cached most of the time, so cheap
        val now = System.currentTimeMillis()

        // Stop ringing if the caller hung up, it timed out, or you opened the app (it rings by itself then).
        ringingCallId?.let { id ->
            val callerLeft = files.any { it.path.substringAfterLast('/') == "leave-$id-${safeName(ringingInitiator)}.json" }
            if (callerLeft || now > ringingUntil || AppState.foreground) { Notifier.clearCall(applicationContext); ringingCallId = null }
        }

        val room = files.firstOrNull { it.path.substringAfterLast('/') == "room.json" } ?: return
        if (room.sha == lastRoomSha) return
        lastRoomSha = room.sha
        if (AppState.foreground) return                       // the open app handles its own ringing

        val o = JSONObject(client.readFile(room.path, repo) ?: return)
        val callId = o.optString("callId", ""); if (callId.isBlank() || callId in notifiedCalls) return
        val initiator = o.optString("initiator", "")
        val me = store.name.ifBlank { "me" }
        if (initiator.isBlank() || initiator == me) return
        val ts = o.optLong("ts", 0L)
        if (now - ts > RING_TIMEOUT_MS) return                // stale: an old call, not a ringing one
        val arr = o.optJSONArray("participants")
        val participants = if (arr != null) (0 until arr.length()).map { arr.getString(it) } else emptyList()
        if (me in participants || participants.size >= MAX_CALL_PARTICIPANTS) return
        if (files.any { it.path.substringAfterLast('/') == "leave-$callId-${safeName(initiator)}.json" }) return

        notifiedCalls += callId
        ringingCallId = callId; ringingInitiator = initiator
        ringingUntil = minOf(ts, now) + RING_TIMEOUT_MS
        Notifier.showCall(applicationContext, Profiles.display(initiator), o.optBoolean("video", false), store.notifPreview)
    }

    private suspend fun checkOnce(store: Store, client: GitHubClient, repo: RepoRef) {
        val bucket = bucketFor(System.currentTimeMillis())
        val files = try {
            client.listFiles("$MSG_DIR/$bucket", repo)
        } catch (e: GitHubApiException) { if (e.code == 404) emptyList() else throw e }
        val paths = files.filter { !it.isDir && it.path.endsWith(".json") }.map { it.path }

        val lastBucket = store.notifBucket
        if (lastBucket.isEmpty()) {           // very first run: just note what's already there
            store.notifBucket = bucket; store.notifSeen = paths.toSet()
            return
        }
        // A new calendar month starts with an empty "seen" set, so its first messages do notify.
        val seen = if (lastBucket == bucket) store.notifSeen else emptySet()
        val fresh = paths.filter { it !in seen }.sorted()
        if (fresh.isEmpty()) {
            if (lastBucket != bucket) { store.notifBucket = bucket; store.notifSeen = paths.toSet() }
            return
        }

        val me = store.name.ifBlank { "me" }
        val failed = HashSet<String>()
        for (p in fresh) {
            if (AppState.foreground) continue     // you're looking at the chat — no need to alert
            try {
                val text = client.readFile(p, repo) ?: continue
                val o = JSONObject(text)
                val from = o.optString("from", "")
                if (from.isBlank() || from == me) continue
                val preview = when (o.optString("type", "TEXT")) {
                    "PHOTO" -> "sent a photo"
                    "VIDEO" -> "sent a video"
                    "VOICE" -> "sent a voice message"
                    "STICKER" -> o.optString("text", "").ifBlank { "sent a sticker" }
                    else -> o.optString("text", "").take(200).ifBlank { "sent a message" }
                }
                Notifier.showMessage(applicationContext, Profiles.display(from), preview, store.notifPreview)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { failed += p }   // retried next round
        }
        store.notifBucket = bucket
        store.notifSeen = paths.toSet() - failed
    }
}
