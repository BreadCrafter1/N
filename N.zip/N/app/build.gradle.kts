import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Reads the token from local.properties (git-ignored, for local builds) with a fallback to
// an environment variable named N_GH_TOKEN (for CI, set as a GitHub Actions secret). Either
// way, the token never has to be written into a source file that gets committed.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val ghToken: String = localProps.getProperty("githubToken") ?: System.getenv("N_GH_TOKEN") ?: ""

android {
    namespace = "com.novochron.n"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novochron.n"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"

        buildConfigField("String", "GITHUB_TOKEN", "\"$ghToken\"")
    }

    // Fixed debug signing so every CI build installs over the last one on your phone. Without
    // this, each CI run signs with its own throwaway ~/.android/debug.keystore, so every build
    // has a different signature and installing a new one over an existing one fails with
    // "There was a problem parsing the package" (Android's generic message for a signature
    // mismatch on update). debug.keystore is checked into the repo (it's a debug-only key, not
    // a secret) so every machine — your laptop or a GitHub Actions runner — signs the same way.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // WebRTC for calling (voice/video + STUN-assisted ICE). This is Stream's actively-maintained
    // build of Google's WebRTC, published under the same org.webrtc package names — Google stopped
    // publishing google-webrtc itself. https://github.com/GetStream/webrtc-android
    implementation("io.getstream:stream-webrtc-android:1.3.9")
}
