package com.novochron.n

import android.content.Context
import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.facemesh.FaceMesh
import com.google.mlkit.vision.facemesh.FaceMeshDetection
import com.google.mlkit.vision.facemesh.FaceMeshDetector
import com.google.mlkit.vision.facemesh.FaceMeshDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A lightweight, fully on-device "does this match a hardcoded face?" gate.
 *
 * How it works: ML Kit's face mesh model finds 468 3D points covering the whole face for
 * every frame. Every point is re-expressed relative to the eye line — centered on the
 * midpoint between two fixed eye-corner points, rotated so that line is horizontal, and
 * scaled by the distance between them — so the result doesn't depend on head tilt, distance
 * from the phone, or camera framing. That aligned 468-point cloud is compared, point for
 * point, against the same thing computed from the hardcoded reference photo(s) bundled in
 * the app.
 *
 * This is dense shape matching, not a trained face-embedding model (like FaceID or a real
 * recognition pipeline uses), so treat it as "keeps casual snoopers and different-looking
 * people out," not a hardened biometric. MATCH_THRESHOLD is the one knob that trades
 * strictness for tolerance — FaceLockScreen shows the live distance number on screen so you
 * can calibrate it against your own face and a few other people's.
 *
 * To add or change whose face unlocks the app: drop a clear, front-facing, well-lit photo
 * into res/drawable (e.g. ref_face_2.jpg) and add its resource id to REFERENCE_DRAWABLES.
 */
object FaceLock {

    // Hardcoded reference face(s). Add more R.drawable.xxx ids here to allow more than one face.
    private val REFERENCE_DRAWABLES = listOf(R.drawable.ref_face_1)

    // Lower = stricter match. Start here, then watch the on-screen distance number: see the
    // comment in FaceLockScreen for how to tune this to your specific face/lighting/camera.
    private const val MATCH_THRESHOLD = 0.12f

    // A face has to fill at least this fraction of the frame's shorter side to count — keeps
    // a face that just wanders into the background of the shot from being evaluated at all.
    private const val MIN_FACE_FRACTION = 0.15f

    // Standard face-mesh topology indices for the outer corner of each eye, used purely to
    // align (center/rotate/scale) the point cloud — not tied to "eye" meaning anything special.
    private const val RIGHT_EYE_ANCHOR = 33
    private const val LEFT_EYE_ANCHOR = 263

    private var cachedReferenceVectors: List<FloatArray>? = null

    private val detector: FaceMeshDetector by lazy {
        FaceMeshDetection.getClient(
            FaceMeshDetectorOptions.Builder()
                .setUseCase(FaceMeshDetectorOptions.FACE_MESH)
                .build()
        )
    }

    sealed class Result {
        data class Match(val distance: Float) : Result()
        data class NoMatch(val distance: Float) : Result()
        object NoFaceFound : Result()
        data class Error(val message: String) : Result()
    }

    /** Warms up the reference vectors so the first live frame doesn't stall on decoding them. */
    suspend fun preload(ctx: Context) {
        referenceVectors(ctx)
    }

    /** Runs mesh detection on a single camera frame and compares it against the hardcoded reference(s). */
    suspend fun verifyImage(ctx: Context, image: InputImage): Result {
        return try {
            val meshes = detectMeshes(image)
            val mesh = meshes
                .filter { largestSideFraction(it, image.width, image.height) >= MIN_FACE_FRACTION }
                .maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
                ?: return Result.NoFaceFound

            val liveVector = meshToVector(mesh) ?: return Result.NoFaceFound

            val references = referenceVectors(ctx)
            if (references.isEmpty()) return Result.Error("No reference face is bundled in the app.")

            val bestDistance = references.minOf { distance(it, liveVector) }
            if (bestDistance <= MATCH_THRESHOLD) Result.Match(bestDistance) else Result.NoMatch(bestDistance)
        } catch (e: Exception) {
            Result.Error(e.message ?: "face check failed")
        }
    }

    private fun largestSideFraction(mesh: FaceMesh, imageWidth: Int, imageHeight: Int): Float {
        val shorterSide = minOf(imageWidth, imageHeight).coerceAtLeast(1)
        return mesh.boundingBox.width().toFloat() / shorterSide
    }

    private suspend fun referenceVectors(ctx: Context): List<FloatArray> {
        cachedReferenceVectors?.let { return it }
        val vectors = REFERENCE_DRAWABLES.mapNotNull { resId ->
            val bmp = BitmapFactory.decodeResource(ctx.resources, resId) ?: return@mapNotNull null
            val meshes = detectMeshes(InputImage.fromBitmap(bmp, 0))
            val mesh = meshes.maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
            mesh?.let { meshToVector(it) }
        }
        cachedReferenceVectors = vectors
        return vectors
    }

    private suspend fun detectMeshes(image: InputImage): List<FaceMesh> =
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { meshes -> if (cont.isActive) cont.resume(meshes) }
                .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
        }

    /**
     * Builds an aligned, scale-normalized 468-point cloud (x, y, z per point) for a face mesh,
     * expressed relative to a fixed pair of eye-corner points (see class doc). Returns null if
     * either anchor point is missing so every returned vector has the same fixed length.
     */
    private fun meshToVector(mesh: FaceMesh): FloatArray? {
        val points = mesh.allPoints.sortedBy { it.index }
        if (points.isEmpty()) return null

        val right = points.firstOrNull { it.index == RIGHT_EYE_ANCHOR }?.position ?: return null
        val left = points.firstOrNull { it.index == LEFT_EYE_ANCHOR }?.position ?: return null

        val midX = (left.x + right.x) / 2f
        val midY = (left.y + right.y) / 2f
        val dx = left.x - right.x
        val dy = left.y - right.y
        val eyeDist = hypot(dx, dy)
        if (eyeDist < 1f) return null

        val angle = atan2(dy.toDouble(), dx.toDouble())
        val cosA = cos(-angle).toFloat()
        val sinA = sin(-angle).toFloat()

        val dims = FloatArray(points.size * 3)
        var i = 0
        for (p in points) {
            val pos = p.position
            val tx = pos.x - midX
            val ty = pos.y - midY
            val rx = (tx * cosA - ty * sinA) / eyeDist
            val ry = (tx * sinA + ty * cosA) / eyeDist
            val rz = pos.z / eyeDist
            dims[i++] = rx
            dims[i++] = ry
            dims[i++] = rz
        }
        return dims
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return Float.MAX_VALUE
        var sum = 0f
        for (i in a.indices) {
            val diff = a[i] - b[i]
            sum += diff * diff
        }
        return sqrt(sum / a.size)
    }

    private fun hypot(dx: Float, dy: Float): Float = sqrt(dx * dx + dy * dy)
}
