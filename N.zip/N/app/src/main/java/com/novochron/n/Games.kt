package com.novochron.n

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------
// Minigames. Opened from the [games] button next to [settings].
//
//   sudoku — singleplayer, generated on the phone, progress saved on the phone.
//   chess  — two players. Each game is one small file in the shared repo (Games/chess/<id>.json)
//            holding both player names and the list of moves so far. Only the player whose turn it
//            is ever writes a move, so there are no merge conflicts, and both phones just poll the
//            folder (ETag'd, so idle polling is free) and replay the moves to get the same board.
// ---------------------------------------------------------------------------------------------

private const val CHESS_DIR = "Games/chess"

@Composable
internal fun GTitle(text: String) {
    Spacer(Modifier.height(14.dp))
    Text(text, color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
internal fun GHint(text: String, color: Color = Dim) {
    Text(text, color = color, fontFamily = TermFont, fontSize = 11.sp)
}

@Composable
internal fun GBtn(label: String, color: Color = Accent, enabled: Boolean = true, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)) {
        Text(label, color = if (enabled) color else Dim, fontFamily = TermFont, fontSize = 13.sp)
    }
}

@Composable
fun GamesPanel(store: Store, onClose: () -> Unit) {
    var screen by remember { mutableStateOf("menu") }
    BackHandler { if (screen == "menu") onClose() else screen = "menu" }

    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) {
        ThemedBackground()
        Box(Modifier.fillMaxSize().background(Bg.copy(alpha = 0.55f)))
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(when (screen) { "menu" -> "minigames"; "tictactoe" -> "tic tac toe"; else -> screen }, color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TextButton(onClick = { if (screen == "menu") onClose() else screen = "menu" }) {
                    Text(if (screen == "menu") "[close]" else "[back]", color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                }
            }
            when (screen) {
                "sudoku" -> SudokuScreen()
                "chess" -> ChessScreen(store)
                "tictactoe" -> TicTacToeScreen(store)
                else -> GamesMenu { screen = it }
            }
        }
    }
}

@Composable
private fun GamesMenu(onPick: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Spacer(Modifier.height(6.dp))
        GameCard("\u265E\uFE0E", "chess", "2 players", "Play the other person over the shared repo. Full rules; each move shows up on their phone within a couple of seconds.") { onPick("chess") }
        GameCard("#", "tic tac toe", "2 players", "Quick rounds against the other person, with instant rematches. Plays over the shared repo like chess.") { onPick("tictactoe") }
        GameCard("\u25A6", "sudoku", "singleplayer", "A fresh puzzle every time, three difficulties, pencil notes and hints. Your progress is saved on this phone.") { onPick("sudoku") }
        GHint("More games can be added here later.")
    }
}

@Composable
private fun GameCard(icon: String, title: String, tag: String, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Raised)
            .border(1.dp, Line, RoundedCornerShape(12.dp)).clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(icon, color = Accent, fontSize = 34.sp)
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("[$tag]", color = Accent, fontFamily = TermFont, fontSize = 11.sp)
            }
            Spacer(Modifier.height(3.dp))
            Text(text, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }
    }
}

// =============================================================================================
// SUDOKU
// =============================================================================================

private fun sBox(i: Int) = (i / 27) * 3 + (i % 9) / 3
private fun sPeers(i: Int, j: Int) = i / 9 == j / 9 || i % 9 == j % 9 || sBox(i) == sBox(j)

private object Sudoku {
    /** Counts solutions of [start] (stopping at [limit]); used to keep every puzzle uniquely solvable. */
    fun countSolutions(start: IntArray, limit: Int): Int {
        val g = start.copyOf()
        val rows = IntArray(9); val cols = IntArray(9); val boxes = IntArray(9)
        for (i in 0 until 81) if (g[i] != 0) {
            val b = 1 shl g[i]
            rows[i / 9] = rows[i / 9] or b; cols[i % 9] = cols[i % 9] or b; boxes[sBox(i)] = boxes[sBox(i)] or b
        }
        var count = 0
        fun rec() {
            if (count >= limit) return
            var best = -1; var bestAvail = 0; var bestN = 10
            for (i in 0 until 81) {
                if (g[i] != 0) continue
                val used = rows[i / 9] or cols[i % 9] or boxes[sBox(i)]
                val avail = 0x3FE and used.inv()
                val n = Integer.bitCount(avail)
                if (n < bestN) { bestN = n; best = i; bestAvail = avail; if (n <= 1) break }
            }
            if (best == -1) { count++; return }
            if (bestN == 0) return
            for (d in 1..9) {
                val b = 1 shl d
                if ((bestAvail and b) == 0) continue
                g[best] = d
                rows[best / 9] = rows[best / 9] or b; cols[best % 9] = cols[best % 9] or b; boxes[sBox(best)] = boxes[sBox(best)] or b
                rec()
                g[best] = 0
                rows[best / 9] = rows[best / 9] and b.inv(); cols[best % 9] = cols[best % 9] and b.inv(); boxes[sBox(best)] = boxes[sBox(best)] and b.inv()
                if (count >= limit) return
            }
        }
        rec()
        return count
    }

    /** A complete, valid, random grid. */
    fun randomSolution(): IntArray {
        val g = IntArray(81)
        val rows = IntArray(9); val cols = IntArray(9); val boxes = IntArray(9)
        fun rec(): Boolean {
            var best = -1; var bestAvail = 0; var bestN = 10
            for (i in 0 until 81) {
                if (g[i] != 0) continue
                val used = rows[i / 9] or cols[i % 9] or boxes[sBox(i)]
                val avail = 0x3FE and used.inv()
                val n = Integer.bitCount(avail)
                if (n < bestN) { bestN = n; best = i; bestAvail = avail; if (n <= 1) break }
            }
            if (best == -1) return true
            if (bestN == 0) return false
            val digits = (1..9).filter { (bestAvail and (1 shl it)) != 0 }.shuffled()
            for (d in digits) {
                val b = 1 shl d
                g[best] = d
                rows[best / 9] = rows[best / 9] or b; cols[best % 9] = cols[best % 9] or b; boxes[sBox(best)] = boxes[sBox(best)] or b
                if (rec()) return true
                g[best] = 0
                rows[best / 9] = rows[best / 9] and b.inv(); cols[best % 9] = cols[best % 9] and b.inv(); boxes[sBox(best)] = boxes[sBox(best)] and b.inv()
            }
            return false
        }
        rec()
        return g
    }

    /** Returns (puzzle, solution). Cells are removed one by one, keeping only removals that leave exactly one solution. */
    fun generate(clues: Int): Pair<IntArray, IntArray> {
        val sol = randomSolution()
        val puz = sol.copyOf()
        var left = 81
        for (i in (0 until 81).shuffled()) {
            if (left <= clues) break
            val keep = puz[i]
            puz[i] = 0
            if (countSolutions(puz, 2) != 1) puz[i] = keep else left--
        }
        return Pair(puz, sol)
    }
}

private class SudokuGame(
    val difficulty: String,
    val puzzle: IntArray,
    val solution: IntArray,
    v0: IntArray, n0: IntArray, m0: Int, h0: Int, t0: Int
) {
    var values by mutableStateOf(v0)
    var notes by mutableStateOf(n0)
    var mistakes by mutableStateOf(m0)
    var hints by mutableStateOf(h0)
    var seconds by mutableStateOf(t0)

    fun isSolved(): Boolean {
        val v = values
        for (i in 0 until 81) if (v[i] != solution[i]) return false
        return true
    }

    fun toJson(): String = JSONObject().apply {
        put("d", difficulty); put("p", puzzle.joinToString("")); put("s", solution.joinToString(""))
        put("v", values.joinToString("")); put("n", notes.joinToString(","))
        put("m", mistakes); put("h", hints); put("t", seconds)
    }.toString()

    companion object {
        private fun digits(s: String): IntArray? = if (s.length == 81) s.map { it - '0' }.toIntArray() else null

        fun fromJson(text: String): SudokuGame? = try {
            val o = JSONObject(text)
            val p = digits(o.getString("p")); val s = digits(o.getString("s")); val v = digits(o.getString("v"))
            val n = o.getString("n").split(",").map { it.toInt() }.toIntArray()
            if (p == null || s == null || v == null || n.size != 81) null
            else SudokuGame(o.optString("d", "medium"), p, s, v, n, o.optInt("m", 0), o.optInt("h", 0), o.optInt("t", 0))
        } catch (_: Exception) { null }
    }
}

private fun noteText(mask: Int): String = buildString {
    for (d in 1..9) {
        append(if ((mask and (1 shl d)) != 0) ('0' + d) else ' ')
        if (d % 3 != 0) append(' ') else if (d < 9) append('\n')
    }
}

private fun clock(s: Int) = "%d:%02d".format(s / 60, s % 60)

@Composable
private fun SudokuScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.applicationContext.getSharedPreferences("n_games", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var game by remember { mutableStateOf<SudokuGame?>(prefs.getString("sudoku", null)?.let { SudokuGame.fromJson(it) }) }
    var generating by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(-1) }
    var notesMode by remember { mutableStateOf(false) }

    fun save() { game?.let { prefs.edit().putString("sudoku", it.toJson()).apply() } }

    fun startNew(diff: String) {
        if (generating) return
        generating = true; selected = -1; notesMode = false
        scope.launch {
            val clues = when (diff) { "easy" -> 40; "hard" -> 28; else -> 34 }
            val made = withContext(Dispatchers.Default) { Sudoku.generate(clues) }
            game = SudokuGame(diff, made.first, made.second, made.first.copyOf(), IntArray(81), 0, 0, 0)
            generating = false
            save()
        }
    }
    LaunchedEffect(Unit) { if (game == null) startNew("medium") }

    val g = game
    val solved = g != null && g.isSolved()

    // Clock: ticks while a puzzle is on screen and unsolved.
    LaunchedEffect(g, solved, generating) {
        if (g == null || solved || generating) return@LaunchedEffect
        while (true) {
            delay(1000)
            g.seconds += 1
            if (g.seconds % 5 == 0) save()
        }
    }

    fun enter(d: Int) {
        val gg = game ?: return
        val i = selected
        if (i < 0 || gg.puzzle[i] != 0 || gg.isSolved()) return
        if (notesMode) {
            if (gg.values[i] != 0) return
            val n = gg.notes.copyOf(); n[i] = n[i] xor (1 shl d); gg.notes = n
        } else {
            if (gg.values[i] == d) return
            val v = gg.values.copyOf(); v[i] = d; gg.values = v
            val n = gg.notes.copyOf(); n[i] = 0
            if (d == gg.solution[i]) {
                for (j in 0 until 81) if (sPeers(i, j)) n[j] = n[j] and (1 shl d).inv()   // tidy the pencil marks
            } else gg.mistakes += 1
            gg.notes = n
        }
        save()
    }

    fun erase() {
        val gg = game ?: return
        val i = selected
        if (i < 0 || gg.puzzle[i] != 0 || gg.isSolved()) return
        val v = gg.values.copyOf(); v[i] = 0; gg.values = v
        val n = gg.notes.copyOf(); n[i] = 0; gg.notes = n
        save()
    }

    fun hint() {
        val gg = game ?: return
        if (gg.isSolved()) return
        var t = selected
        if (t < 0 || gg.puzzle[t] != 0 || gg.values[t] == gg.solution[t]) {
            t = (0 until 81).firstOrNull { gg.values[it] != gg.solution[it] } ?: return
        }
        val v = gg.values.copyOf(); v[t] = gg.solution[t]; gg.values = v
        val n = gg.notes.copyOf(); n[t] = 0
        for (j in 0 until 81) if (sPeers(t, j)) n[j] = n[j] and (1 shl gg.solution[t]).inv()
        gg.notes = n
        gg.hints += 1
        selected = t
        save()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(8.dp))
        if (g == null) {
            GHint("making a puzzle…")
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(g.difficulty, color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(clock(g.seconds), color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Text("mistakes ${g.mistakes}", color = if (g.mistakes > 0) Warn else Dim, fontFamily = TermFont, fontSize = 13.sp)
                Text("hints ${g.hints}", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            }
            Spacer(Modifier.height(8.dp))
            SudokuBoard(g, selected) { selected = if (selected == it) -1 else it }
            Spacer(Modifier.height(10.dp))

            if (solved) {
                Text(
                    "\u2713 solved in ${clock(g.seconds)} \u00B7 ${g.mistakes} mistake${if (g.mistakes == 1) "" else "s"} \u00B7 ${g.hints} hint${if (g.hints == 1) "" else "s"}",
                    color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    for (d in 1..9) {
                        val left = 9 - (0 until 81).count { g.values[it] == d && g.solution[it] == d }
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(Raised)
                                .clickable(enabled = left > 0) { enter(d) }.padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("$d", color = if (left > 0) Accent else Dim, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text("$left", color = Dim, fontFamily = TermFont, fontSize = 9.sp)
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    GBtn(if (notesMode) "[notes: on]" else "[notes: off]", if (notesMode) Accent else Ink) { notesMode = !notesMode }
                    GBtn("[erase]", Ink) { erase() }
                    GBtn("[hint]", Ink) { hint() }
                }
            }
        }

        GTitle("new game")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            GBtn("[easy]", enabled = !generating) { startNew("easy") }
            GBtn("[medium]", enabled = !generating) { startNew("medium") }
            GBtn("[hard]", enabled = !generating) { startNew("hard") }
        }
        if (generating) GHint("making a puzzle…")
        else GHint("Wrong digits show in red and count as mistakes. Tap a number to place it; turn notes on for pencil marks.")
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SudokuBoard(g: SudokuGame, selected: Int, onSelect: (Int) -> Unit) {
    val ink = Ink; val dim = Dim; val accent = Accent; val warn = Warn
    val values = g.values; val notes = g.notes
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cell = maxWidth / 9
        val side = cell * 9
        Box(Modifier.size(side).background(Raised)) {
            Column {
                for (r in 0 until 9) {
                    Row {
                        for (c in 0 until 9) {
                            val i = r * 9 + c
                            val v = values[i]
                            val given = g.puzzle[i] != 0
                            val selV = if (selected >= 0) values[selected] else 0
                            val bg = when {
                                i == selected -> accent.copy(alpha = 0.38f)
                                selected >= 0 && sPeers(selected, i) -> accent.copy(alpha = 0.12f)
                                selV != 0 && v == selV -> accent.copy(alpha = 0.24f)
                                else -> Color.Transparent
                            }
                            Box(Modifier.size(cell).background(bg).clickable { onSelect(i) }, contentAlignment = Alignment.Center) {
                                if (v != 0) {
                                    Text(
                                        "$v",
                                        color = when { given -> ink; v != g.solution[i] -> warn; else -> accent },
                                        fontFamily = TermFont,
                                        fontWeight = if (given) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = (cell.value * 0.55f).sp
                                    )
                                } else if (notes[i] != 0) {
                                    Text(
                                        noteText(notes[i]), color = dim, fontFamily = TermFont, textAlign = TextAlign.Center,
                                        fontSize = (cell.value * 0.24f).sp, lineHeight = (cell.value * 0.27f).sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Canvas(Modifier.size(side)) {
                val cellPx = size.width / 9f
                for (k in 0..9) {
                    val thick = k % 3 == 0
                    val w = if (thick) 2.5.dp.toPx() else 0.6.dp.toPx()
                    val col = if (thick) ink else dim.copy(alpha = 0.45f)
                    val p = k * cellPx
                    drawLine(col, Offset(p, 0f), Offset(p, size.height), strokeWidth = w)
                    drawLine(col, Offset(0f, p), Offset(size.width, p), strokeWidth = w)
                }
            }
        }
    }
}

// =============================================================================================
// CHESS — multiplayer
// =============================================================================================

private data class ChessGameData(
    val id: String,
    val white: String,          // username, "" = seat still open
    val black: String,
    val moves: List<String>,    // coordinate notation: "e2e4", "e7e8q"
    val result: String,         // "" = in progress, "white" / "black" = that side won, "draw"
    val reason: String,         // checkmate / resign / agreed / stalemate / insufficient / fifty / repetition
    val drawOffer: String,      // username who has offered a draw, or ""
    val rev: Int,               // bumped on every write so a slow poll can't overwrite a newer local state
    val created: Long
) {
    fun toJson(): String = JSONObject().apply {
        put("id", id); put("white", white); put("black", black); put("moves", JSONArray(moves))
        put("result", result); put("reason", reason); put("drawOffer", drawOffer)
        put("rev", rev); put("created", created)
    }.toString(2)

    /** true = white, false = black, null = not playing in this game. */
    fun colorOf(user: String): Boolean? = if (user == white) true else if (user == black) false else null
}

private fun parseChess(text: String): ChessGameData? = try {
    val o = JSONObject(text)
    val arr = o.optJSONArray("moves") ?: JSONArray()
    ChessGameData(
        o.getString("id"), o.optString("white", ""), o.optString("black", ""),
        (0 until arr.length()).map { arr.getString(it) },
        o.optString("result", ""), o.optString("reason", ""), o.optString("drawOffer", ""),
        o.optInt("rev", 0), o.optLong("created", 0L)
    )
} catch (_: Exception) { null }

private val PieceGlyph = arrayOf("", "\u265F\uFE0E", "\u265E\uFE0E", "\u265D\uFE0E", "\u265C\uFE0E", "\u265B\uFE0E", "\u265A\uFE0E")

private fun whyText(reason: String) = when (reason) {
    "checkmate" -> "checkmate"
    "resign" -> "resignation"
    "agreed" -> "draw agreed"
    "stalemate" -> "stalemate"
    "insufficient" -> "insufficient material"
    "fifty" -> "50-move rule"
    "repetition" -> "threefold repetition"
    else -> ""
}

private fun resultText(res: String, reason: String, g: ChessGameData): String {
    val why = whyText(reason)
    val suffix = if (why.isNotEmpty()) " ($why)" else ""
    return when (res) {
        "white" -> "${Profiles.display(g.white)} won as white$suffix"
        "black" -> "${Profiles.display(g.black)} won as black$suffix"
        else -> "draw$suffix"
    }
}

@Composable
private fun ChessScreen(store: Store) {
    val me = store.name.ifBlank { "me" }
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }
    val scope = rememberCoroutineScope()
    val games = remember { mutableStateMapOf<String, ChessGameData>() }
    val shas = remember { HashMap<String, String>() }
    val inflight = remember { HashMap<String, Int>() }      // id → writes still going out (don't treat as deleted)
    val writeLock = remember { Mutex() }
    var openId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    val openNow by rememberUpdatedState(openId)
    BackHandler(enabled = openId != null) { openId = null }

    // Keep every game in step with the repo. The listing is ETag'd, so when nothing changed this is a free 304;
    // a game file is only downloaded when its blob sha changed.
    LaunchedEffect(client, repo) {
        if (client == null || repo == null) { status = "no repo / token configured"; loaded = true; return@LaunchedEffect }
        while (true) {
            try {
                val files = client.listFiles(CHESS_DIR, repo)
                    .filter { !it.isDir && it.path.endsWith(".json") }
                    .sortedBy { it.path }.takeLast(40)
                val present = HashSet<String>()
                for (f in files) {
                    val id = f.path.substringAfterLast('/').removeSuffix(".json")
                    present.add(id)
                    if (shas[id] == f.sha) continue
                    val d = client.readFile(f.path, repo)?.let { parseChess(it) } ?: continue
                    val cur = games[id]
                    if (cur == null || d.rev >= cur.rev) games[id] = d
                    shas[id] = f.sha
                }
                for (id in games.keys.toList()) {
                    if (id !in present && (inflight[id] ?: 0) == 0) { games.remove(id); shas.remove(id) }
                }
                status = ""
            } catch (e: Exception) {
                status = "sync: ${e.message?.take(80)}"
            }
            loaded = true
            delay(if (openNow != null) 2000L else 4000L)
        }
    }

    fun save(id: String) {
        val c = client ?: return
        val r = repo ?: return
        inflight[id] = (inflight[id] ?: 0) + 1
        scope.launch {
            writeLock.withLock {
                var attempt = 0
                while (attempt < 3) {
                    try {
                        val g = games[id] ?: break
                        c.writeFile("$CHESS_DIR/$id.json", g.toJson(), "n: chess", r)
                        status = ""
                        break
                    } catch (e: Exception) {
                        attempt++
                        status = "couldn't save move: ${e.message?.take(80)}"
                        delay(1500)
                    }
                }
            }
            val left = (inflight[id] ?: 1) - 1
            if (left <= 0) inflight.remove(id) else inflight[id] = left
        }
    }

    fun create(pref: String) {
        val white = when (pref) { "white" -> true; "black" -> false; else -> kotlin.random.Random.nextBoolean() }
        val id = "${System.currentTimeMillis()}_${safeName(me)}"
        games[id] = ChessGameData(id, if (white) me else "", if (white) "" else me, emptyList(), "", "", "", 1, System.currentTimeMillis())
        openId = id
        save(id)
    }

    fun join(id: String) {
        val g = games[id] ?: return
        if (g.white == me || g.black == me) { openId = id; return }
        if (g.white.isBlank()) games[id] = g.copy(white = me, rev = g.rev + 1)
        else if (g.black.isBlank()) games[id] = g.copy(black = me, rev = g.rev + 1)
        else { openId = id; return }
        openId = id
        save(id)
    }

    fun update(id: String, change: (ChessGameData) -> ChessGameData) {
        val g = games[id] ?: return
        val n = change(g)
        games[id] = n.copy(rev = g.rev + 1)
        save(id)
    }

    fun move(id: String, uci: String) = update(id) { g ->
        val moves = g.moves + uci
        val r = replayChess(moves)
        val result = when (r.ended) { "" -> ""; "checkmate" -> if (r.winnerWhite == true) "white" else "black"; else -> "draw" }
        g.copy(moves = moves, result = result, reason = r.ended, drawOffer = "")
    }

    fun resign(id: String) = update(id) { g ->
        val iWhite = g.white == me
        g.copy(result = if (iWhite) "black" else "white", reason = "resign", drawOffer = "")
    }

    fun offerDraw(id: String) = update(id) { g -> g.copy(drawOffer = me) }
    fun declineDraw(id: String) = update(id) { g -> g.copy(drawOffer = "") }
    fun acceptDraw(id: String) = update(id) { g -> g.copy(result = "draw", reason = "agreed", drawOffer = "") }

    fun delete(id: String) {
        val c = client ?: return
        val r = repo ?: return
        scope.launch {
            try {
                val f = c.listFiles(CHESS_DIR, r).firstOrNull { it.path.substringAfterLast('/') == "$id.json" }
                if (f != null) c.deleteFile(f.path, f.sha, "n: chess delete", r)
                games.remove(id); shas.remove(id)
                if (openId == id) openId = null
            } catch (e: Exception) { status = "couldn't delete: ${e.message?.take(80)}" }
        }
    }

    val open = openId?.let { games[it] }
    if (open == null) {
        ChessLobby(games, me, loaded, status, onCreate = { create(it) }, onOpen = { openId = it }, onJoin = { join(it) })
    } else {
        ChessGameView(
            g = open, me = me, status = status,
            onMove = { move(open.id, it) },
            onResign = { resign(open.id) },
            onOffer = { offerDraw(open.id) },
            onAccept = { acceptDraw(open.id) },
            onDecline = { declineDraw(open.id) },
            onDelete = { delete(open.id) },
            onBack = { openId = null }
        )
    }
}

@Composable
internal fun LobbyRow(title: String, subtitle: String, action: String, highlight: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp)).background(Raised)
            .border(1.dp, if (highlight) Accent else Line, RoundedCornerShape(10.dp)).clickable { onClick() }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }
        Text(action, color = Accent, fontFamily = TermFont, fontSize = 13.sp)
    }
}

@Composable
private fun ChessLobby(
    games: Map<String, ChessGameData>, me: String, loaded: Boolean, status: String,
    onCreate: (String) -> Unit, onOpen: (String) -> Unit, onJoin: (String) -> Unit
) {
    val all = games.values.sortedByDescending { it.id }
    val active = all.filter { it.result.isBlank() && (it.white == me || it.black == me) }
    val openGames = all.filter { it.result.isBlank() && it.white != me && it.black != me && (it.white.isBlank() || it.black.isBlank()) }
    val finished = all.filter { it.result.isNotBlank() && (it.white == me || it.black == me) }.take(10)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GTitle("start a game")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            GBtn("[play white]") { onCreate("white") }
            GBtn("[play black]") { onCreate("black") }
            GBtn("[random]") { onCreate("random") }
        }
        GHint("This opens a game the other person can join from their own chess screen.")
        if (status.isNotEmpty()) { Spacer(Modifier.height(6.dp)); GHint(status, Warn) }

        GTitle("your games")
        if (!loaded) GHint("loading…")
        else if (active.isEmpty()) GHint("no games in progress")
        else active.forEach { g ->
            val iWhite = g.white == me
            val opp = if (iWhite) g.black else g.white
            val whiteToMove = g.moves.size % 2 == 0
            val myTurn = opp.isNotBlank() && iWhite == whiteToMove
            val sub = if (opp.isBlank()) "you're ${if (iWhite) "white" else "black"} \u00B7 waiting for someone to join"
            else "you're ${if (iWhite) "white" else "black"} \u00B7 move ${g.moves.size / 2 + 1} \u00B7 ${if (myTurn) "your turn" else "their turn"}"
            LobbyRow(
                if (opp.isBlank()) "open game" else "vs ${Profiles.display(opp)}", sub, "[open]",
                highlight = myTurn
            ) { onOpen(g.id) }
        }

        if (openGames.isNotEmpty()) {
            GTitle("open games")
            openGames.forEach { g ->
                val host = if (g.white.isNotBlank()) g.white else g.black
                LobbyRow("${Profiles.display(host)} is waiting", "you'd play ${if (g.white.isBlank()) "white" else "black"}", "[join]") { onJoin(g.id) }
            }
        }

        if (finished.isNotEmpty()) {
            GTitle("finished")
            finished.forEach { g ->
                val opp = if (g.white == me) g.black else g.white
                LobbyRow("vs ${Profiles.display(opp)}", resultText(g.result, g.reason, g), "[view]") { onOpen(g.id) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun PlayerBar(user: String, isWhite: Boolean, toMove: Boolean, captured: List<Int>, plus: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (user.isNotBlank()) Avatar(user, 28.dp)
        else Box(Modifier.size(28.dp).clip(CircleShape).background(Raised), contentAlignment = Alignment.Center) {
            Text("?", color = Dim, fontFamily = TermFont, fontSize = 14.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(
                if (user.isBlank()) "waiting for opponent…" else Profiles.display(user),
                color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1
            )
            Text(
                (if (isWhite) "white" else "black") + (if (toMove) " \u00B7 to move" else ""),
                color = if (toMove) Accent else Dim, fontFamily = TermFont, fontSize = 10.sp
            )
        }
        if (captured.isNotEmpty()) {
            Text(
                captured.joinToString("") { PieceGlyph[it] } + (if (plus > 0) " +$plus" else ""),
                color = Dim, fontFamily = TermFont, fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun ChessSquare(
    size: Dp, piece: Int, light: Boolean, last: Boolean, selected: Boolean, target: Boolean, check: Boolean,
    fileLabel: String, rankLabel: String, onClick: () -> Unit
) {
    val base = if (light) lerp(Color(0xFFD9D9D0), Accent, 0.18f) else lerp(Color(0xFF6F7A70), Accent, 0.35f)
    Box(Modifier.size(size).background(base).clickable { onClick() }, contentAlignment = Alignment.Center) {
        if (last) Box(Modifier.fillMaxSize().background(Color(0xFFFFEB3B).copy(alpha = 0.35f)))
        if (check) Box(Modifier.fillMaxSize().background(Color(0xFFFF3B30).copy(alpha = 0.55f)))
        if (selected) Box(Modifier.fillMaxSize().background(Accent.copy(alpha = 0.55f)))
        if (piece != 0) {
            val t = if (piece < 0) -piece else piece
            val whitePiece = piece > 0
            Text(
                PieceGlyph[t],
                color = if (whitePiece) Color.White else Color(0xFF0D0D0D),
                fontSize = (size.value * 0.74f).sp,
                style = TextStyle(
                    shadow = if (whitePiece) Shadow(Color.Black, Offset.Zero, 7f)
                    else Shadow(Color.White.copy(alpha = 0.7f), Offset.Zero, 4f)
                )
            )
        }
        if (target) {
            if (piece == 0) Box(Modifier.size(size * 0.3f).clip(CircleShape).background(Accent.copy(alpha = 0.6f)))
            else Box(Modifier.fillMaxSize().border(3.dp, Accent.copy(alpha = 0.75f)))
        }
        if (rankLabel.isNotEmpty()) Text(
            rankLabel, color = if (light) Color(0xFF555555) else Color(0xFFDDDDDD), fontSize = 8.sp, fontFamily = TermFont,
            modifier = Modifier.align(Alignment.TopStart).padding(2.dp)
        )
        if (fileLabel.isNotEmpty()) Text(
            fileLabel, color = if (light) Color(0xFF555555) else Color(0xFFDDDDDD), fontSize = 8.sp, fontFamily = TermFont,
            modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp)
        )
    }
}

/** Pieces of the given colour that are no longer on the board (index = piece type 1..5). */
private fun missingPieces(b: IntArray, white: Boolean): List<Int> {
    val start = intArrayOf(0, 8, 2, 2, 2, 1)
    val have = IntArray(6)
    for (v in b) if (v != 0 && (v > 0) == white) { val t = if (v < 0) -v else v; if (t in 1..5) have[t]++ }
    val out = ArrayList<Int>()
    for (t in 5 downTo 1) repeat(maxOf(0, start[t] - have[t])) { out.add(t) }
    return out
}

private fun pieceValue(t: Int) = when (t) { 1 -> 1; 2 -> 3; 3 -> 3; 4 -> 5; 5 -> 9; else -> 0 }

@Composable
private fun ChessGameView(
    g: ChessGameData, me: String, status: String,
    onMove: (String) -> Unit, onResign: () -> Unit, onOffer: () -> Unit, onAccept: () -> Unit, onDecline: () -> Unit,
    onDelete: () -> Unit, onBack: () -> Unit
) {
    val myColor = g.colorOf(me)                      // true white, false black, null = watching
    var flipped by remember(g.id) { mutableStateOf(myColor == false) }
    var selected by remember(g.id) { mutableStateOf(-1) }
    var promo by remember(g.id) { mutableStateOf<IntArray?>(null) }
    var confirmResign by remember(g.id) { mutableStateOf(false) }
    var confirmDelete by remember(g.id) { mutableStateOf(false) }

    val replay = remember(g.moves) { replayChess(g.moves) }
    val legal = remember(replay) { Chess.legal(replay.pos) }
    LaunchedEffect(g.moves.size) { selected = -1; promo = null; confirmResign = false }

    val res = if (g.result.isNotBlank()) g.result else when (replay.ended) {
        "" -> ""
        "checkmate" -> if (replay.winnerWhite == true) "white" else "black"
        else -> "draw"
    }
    val why = if (g.result.isNotBlank()) g.reason else replay.ended
    val over = res.isNotBlank()
    val ready = g.white.isNotBlank() && g.black.isNotBlank()
    val whiteToMove = replay.pos.white
    val myTurn = ready && !over && myColor != null && myColor == whiteToMove
    val opp = if (myColor == false) g.white else g.black          // the "other" side from my point of view (for spectators: black)

    val targets = if (selected >= 0) legal.filter { Chess.fromSq(it) == selected } else emptyList()
    val targetSquares = targets.map { Chess.toSq(it) }.toSet()

    fun tap(sq: Int) {
        if (!myTurn || promo != null) return
        if (selected >= 0 && sq in targetSquares) {
            val cands = targets.filter { Chess.toSq(it) == sq }
            if (cands.any { Chess.promoOf(it) != 0 }) promo = intArrayOf(selected, sq)
            else { onMove(Chess.uci(cands[0])); selected = -1 }
            return
        }
        val piece = replay.pos.b[sq]
        selected = if (piece != 0 && (piece > 0) == (myColor == true) && selected != sq) sq else -1
    }

    val bottomWhite = !flipped
    val bottomUser = if (bottomWhite) g.white else g.black
    val topUser = if (bottomWhite) g.black else g.white
    val capByWhite = missingPieces(replay.pos.b, false)      // black pieces white has taken
    val capByBlack = missingPieces(replay.pos.b, true)
    val matDiff = capByWhite.sumOf { pieceValue(it) } - capByBlack.sumOf { pieceValue(it) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            GBtn("[\u2190 games]", Ink) { onBack() }
            GBtn("[flip board]", Ink) { flipped = !flipped }
        }

        PlayerBar(
            topUser, !bottomWhite, ready && !over && whiteToMove == !bottomWhite,
            if (bottomWhite) capByBlack else capByWhite,
            if (bottomWhite) maxOf(0, -matDiff) else maxOf(0, matDiff)
        )

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val sq = maxWidth / 8
            val kingInCheck = if (replay.check && !over || (replay.check && res == "checkmate")) Chess.kingSquare(replay.pos, replay.pos.white) else -1
            Column(Modifier.size(sq * 8).clip(RoundedCornerShape(6.dp))) {
                for (row in 0 until 8) {
                    val rank = if (flipped) row else 7 - row
                    Row {
                        for (col in 0 until 8) {
                            val file = if (flipped) 7 - col else col
                            val s = rank * 8 + file
                            val piece = replay.pos.b[s]
                            ChessSquare(
                                size = sq, piece = piece, light = (rank + file) % 2 == 1,
                                last = s == replay.lastFrom || s == replay.lastTo,
                                selected = s == selected,
                                target = s in targetSquares,
                                check = s == kingInCheck,
                                fileLabel = if (row == 7) "${'a' + file}" else "",
                                rankLabel = if (col == 0) "${rank + 1}" else "",
                                onClick = { tap(s) }
                            )
                        }
                    }
                }
            }
        }

        PlayerBar(
            bottomUser, bottomWhite, ready && !over && whiteToMove == bottomWhite,
            if (bottomWhite) capByWhite else capByBlack,
            if (bottomWhite) maxOf(0, matDiff) else maxOf(0, -matDiff)
        )

        // ---- promotion picker ----
        val pending = promo
        if (pending != null) {
            Text("promote to:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (p in intArrayOf(5, 4, 3, 2)) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Raised).border(1.dp, Accent, RoundedCornerShape(10.dp))
                            .clickable {
                                val m = legal.firstOrNull { Chess.fromSq(it) == pending[0] && Chess.toSq(it) == pending[1] && Chess.promoOf(it) == p }
                                if (m != null) onMove(Chess.uci(m))
                                promo = null; selected = -1
                            }.padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(PieceGlyph[p], color = if (myColor == true) Color.White else Color(0xFF0D0D0D), fontSize = 30.sp, style = TextStyle(shadow = Shadow(if (myColor == true) Color.Black else Color.White, Offset.Zero, 6f))) }
                }
            }
            GBtn("[cancel]", Ink) { promo = null; selected = -1 }
        }

        // ---- status line ----
        Spacer(Modifier.height(4.dp))
        val statusLine = when {
            !replay.valid -> "\u26A0 this game's move list is damaged"
            over -> resultText(res, why, g)
            !ready -> "waiting for an opponent to join\u2026"
            myColor == null -> "${Profiles.display(if (whiteToMove) g.white else g.black)} to move (you're watching)"
            myTurn -> if (replay.check) "your move \u2014 you're in check!" else "your move"
            else -> "waiting for ${Profiles.display(opp)}\u2026" + (if (replay.check) " (they're in check)" else "")
        }
        Text(
            statusLine,
            color = if (over || myTurn) Accent else if (!replay.valid) Warn else Ink,
            fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
        if (status.isNotEmpty()) GHint(status, Warn)

        // ---- actions ----
        if (!over && ready && myColor != null) {
            Spacer(Modifier.height(6.dp))
            val offerFromOpp = g.drawOffer.isNotBlank() && g.drawOffer != me
            if (offerFromOpp) {
                Text("${Profiles.display(g.drawOffer)} offers a draw", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Row { GBtn("[accept draw]") { onAccept() }; GBtn("[decline]", Ink) { onDecline() } }
            } else if (confirmResign) {
                Text("resign this game?", color = Warn, fontFamily = TermFont, fontSize = 13.sp)
                Row { GBtn("[yes, resign]", Warn) { confirmResign = false; onResign() }; GBtn("[no]", Ink) { confirmResign = false } }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (g.drawOffer == me) GHint("draw offered \u2014 waiting for their answer") else GBtn("[offer draw]", Ink) { onOffer() }
                    GBtn("[resign]", Warn) { confirmResign = true }
                }
            }
        }

        if (over || (!ready && myColor != null)) {
            Spacer(Modifier.height(6.dp))
            if (confirmDelete) {
                Text("delete this game for everyone?", color = Warn, fontFamily = TermFont, fontSize = 13.sp)
                Row { GBtn("[yes, delete]", Warn) { confirmDelete = false; onDelete() }; GBtn("[no]", Ink) { confirmDelete = false } }
            } else GBtn(if (over) "[delete game]" else "[cancel this game]", Ink) { confirmDelete = true }
        }

        // ---- move list ----
        if (replay.sans.isNotEmpty()) {
            GTitle("moves")
            val text = buildString {
                replay.sans.forEachIndexed { i, s ->
                    if (i % 2 == 0) append("${i / 2 + 1}. ")
                    append(s); append("  ")
                }
            }
            Box(Modifier.fillMaxWidth().heightIn(max = 90.dp).clip(RoundedCornerShape(8.dp)).background(Raised).padding(8.dp).verticalScroll(rememberScrollState(), reverseScrolling = true)) {
                Text(text, color = Ink, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
