package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.sqrt

/**
 * A lightweight, fully on-device "does this match a hardcoded face?" gate.
 *
 * How it works: ML Kit's face detector finds a handful of facial landmarks (eyes, nose,
 * mouth corners) in a camera frame. We turn those into a small set of distances between
 * landmarks, normalized by the distance between the eyes so it doesn't matter how close the
 * phone is to your face. That normalized vector is compared against the same vector computed
 * from the reference photo(s) bundled in the app. It's geometry-based, not a trained
 * face-embedding model, so treat it as a "good enough to keep casual snoopers out" lock, not
 * a hardened biometric.
 *
 * To add or change whose face unlocks the app: drop a clear, front-facing photo into
 * res/drawable (e.g. ref_face_2.jpg) and add its resource id to REFERENCE_DRAWABLES below.
 */
object FaceLock {

    // Hardcoded reference face(s). Add more R.drawable.xxx ids here to allow more than one face.
    private val REFERENCE_DRAWABLES = listOf(R.drawable.ref_face_1)

    // Lower = stricter match. This is a heuristic; if it's rejecting the right face, raise it
    // a bit (e.g. 0.22-0.26); if it's accepting the wrong face, lower it.
    private const val MATCH_THRESHOLD = 0.20f

    // A face has to fill at least this fraction of the frame's shorter side to count — keeps
    // a face that just wanders into the background of the shot from being evaluated at all.
    private const val MIN_FACE_FRACTION = 0.15f

    private val landmarkIds = intArrayOf(
        FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE, FaceLandmark.NOSE_BASE,
        FaceLandmark.MOUTH_LEFT, FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM
    )

    private var cachedReferenceVectors: List<FloatArray>? = null

    private val detector: FaceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()
        FaceDetection.getClient(options)
    }

    sealed class Result {
        object Match : Result()
        object NoMatch : Result()
        object NoFaceFound : Result()
        data class Error(val message: String) : Result()
    }

    /** Warms up the reference vectors so the first live frame doesn't stall on decoding them. */
    suspend fun preload(ctx: Context) {
        referenceVectors(ctx)
    }

    /** Runs detection on a single camera frame and compares it against the hardcoded reference(s). */
    suspend fun verifyImage(ctx: Context, image: InputImage): Result {
        return try {
            val faces = detectFaces(image)
            val face = faces
                .filter { largestSideFraction(it, image.width, image.height) >= MIN_FACE_FRACTION }
                .maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
                ?: return Result.NoFaceFound

            val liveVector = faceToVector(face) ?: return Result.NoFaceFound

            val references = referenceVectors(ctx)
            if (references.isEmpty()) return Result.Error("No reference face is bundled in the app.")

            val bestDistance = references.minOf { distance(it, liveVector) }
            if (bestDistance <= MATCH_THRESHOLD) Result.Match else Result.NoMatch
        } catch (e: Exception) {
            Result.Error(e.message ?: "face check failed")
        }
    }

    private fun largestSideFraction(face: Face, imageWidth: Int, imageHeight: Int): Float {
        val shorterSide = minOf(imageWidth, imageHeight).coerceAtLeast(1)
        return face.boundingBox.width().toFloat() / shorterSide
    }

    private suspend fun referenceVectors(ctx: Context): List<FloatArray> {
        cachedReferenceVectors?.let { return it }
        val vectors = REFERENCE_DRAWABLES.mapNotNull { resId ->
            val bmp = decodeDrawableBitmap(ctx, resId) ?: return@mapNotNull null
            val faces = detectFaces(InputImage.fromBitmap(bmp, 0))
            val face = faces.maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
            face?.let { faceToVector(it) }
        }
        cachedReferenceVectors = vectors
        return vectors
    }

    private fun decodeDrawableBitmap(ctx: Context, resId: Int): Bitmap? =
        BitmapFactory.decodeResource(ctx.resources, resId)

    private suspend fun detectFaces(image: InputImage): List<Face> =
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { faces -> if (cont.isActive) cont.resume(faces) }
                .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
        }

    private fun faceToVector(face: Face): FloatArray? {
        val points = landmarkIds.map { id ->
            face.getLandmark(id)?.position ?: return null
        }
        val leftEye = points[0]
        val rightEye = points[1]
        val eyeDist = hypot(leftEye.x - rightEye.x, leftEye.y - rightEye.y)
        if (eyeDist < 1f) return null

        val dims = ArrayList<Float>()
        for (i in points.indices) {
            for (j in i + 1 until points.size) {
                // Skip the eye-to-eye distance itself: it's the normalizer, always ~1.0.
                if (i == 0 && j == 1) continue
                val d = hypot(points[i].x - points[j].x, points[i].y - points[j].y) / eyeDist
                dims.add(d)
            }
        }
        return dims.toFloatArray()
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return Float.MAX_VALUE
        var sum = 0f
        for (i in a.indices) {
            val diff = a[i] - b[i]
            sum += diff * diff
        }
        return sqrt(sum / a.size)
    }

    private fun hypot(dx: Float, dy: Float): Float = sqrt(dx * dx + dy * dy)
}
