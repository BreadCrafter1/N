# N

A tiny Novochron-styled app: text, photo, video, and voice messages with one other person, using a
shared GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving
is polling the same folder.

## Setting the GitHub token
The token used to talk to the repo is no longer written into any source file, so it can't get
swept up in a `git push` and auto-revoked by GitHub's secret scanning.

- **Building locally:** copy `local.properties.example` to `local.properties` (already
  git-ignored) and paste your token in place of `ghp_your_token_here`.
- **Building via the "Build N" GitHub Actions workflow:** add the token as a repo secret instead
  — repo → **Settings → Secrets and variables → Actions → New repository secret**, name it
  `N_GH_TOKEN`, paste the token as the value. Then, in the workflow file's build step (the one
  that runs `./gradlew assembleDebug` or similar), add:
  ```yaml
  env:
    N_GH_TOKEN: ${{ secrets.N_GH_TOKEN }}
  ```
  (This project's workflow file wasn't part of what I edited — add that `env:` block to yours if
  it isn't there already, or ask me to write the whole workflow file if you'd rather start over.)

Either way, if you ever rotate the token, there's no source file to edit — just update
`local.properties` and/or the `N_GH_TOKEN` secret.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Tap `[mic]` to
   record a voice message — the button turns into a running timer and `[stop]`; tap it again (or
   `[cancel]` to discard) to send it. First tap asks for microphone permission.
3. Photos, videos and voice clips can be up to **100 MB** each — that's GitHub's hard per-file limit for
   the Contents API. Big files are streamed from/to disk (never held in memory), show upload progress
   in the status line, and appear in your own chat immediately while they upload.
4. **Tap any photo** to open it full-screen, then tap `[save]` to store the original, full-quality file
   in your gallery (Pictures/N). Android 9 and older will ask for storage permission the first time.

## Speed
- New messages are checked for every second using ETags — when nothing changed, GitHub replies with an
  empty `304` (which doesn't count against your API rate limit).
- New message files are fetched several at a time, and the chat is cached on the phone so it shows
  instantly on launch. Downloaded photos/videos/voice clips are cached too.
- Your own messages appear instantly and are sent in the background; sending skips the extra
  "does this file exist?" round-trip and retries automatically on 409 conflicts.
- Known limit: GitHub only returns the first 1,000 files of a folder, so the chat is capped at roughly
  1,000 messages until you `[clear]` it.

Tap `[repo]` any time to change the repo, token, or name.
