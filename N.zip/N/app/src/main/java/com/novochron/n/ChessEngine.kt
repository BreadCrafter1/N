package com.novochron.n

// ---------------------------------------------------------------------------------------------
// A small, complete chess rules engine (no AI): legal move generation, check / checkmate /
// stalemate, castling, en passant, promotion, and the automatic draws (insufficient material,
// 50-move rule, threefold repetition).
//
// Squares are 0..63 with a1 = 0, b1 = 1 … h1 = 7, a2 = 8 … h8 = 63 (index = rank * 8 + file).
// Pieces: 0 empty, 1 pawn, 2 knight, 3 bishop, 4 rook, 5 queen, 6 king — positive = white, negative = black.
// A move is one Int: from | (to shl 6) | (promotionPiece shl 12).
// ---------------------------------------------------------------------------------------------

class ChessPos(
    val b: IntArray,
    val white: Boolean,     // side to move
    val castle: Int,        // bit 1 = white O-O, 2 = white O-O-O, 4 = black O-O, 8 = black O-O-O
    val ep: Int,            // square a pawn may capture onto en passant, or -1
    val half: Int,          // half-move clock for the 50-move rule
    val full: Int
)

object Chess {
    private val KN_F = intArrayOf(1, 2, -1, -2, 1, 2, -1, -2)
    private val KN_R = intArrayOf(2, 1, 2, 1, -2, -1, -2, -1)
    private val KG_F = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
    private val KG_R = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)
    private val BD_F = intArrayOf(1, 1, -1, -1)
    private val BD_R = intArrayOf(1, -1, 1, -1)
    private val RD_F = intArrayOf(1, -1, 0, 0)
    private val RD_R = intArrayOf(0, 0, 1, -1)
    private val PROMOS = intArrayOf(2, 3, 4, 5)

    fun fromSq(m: Int) = m and 63
    fun toSq(m: Int) = (m shr 6) and 63
    fun promoOf(m: Int) = (m shr 12) and 7
    private fun mv(fr: Int, dest: Int, pr: Int = 0) = fr or (dest shl 6) or (pr shl 12)

    fun start(): ChessPos {
        val b = IntArray(64)
        val back = intArrayOf(4, 2, 3, 5, 6, 3, 2, 4)
        for (f in 0 until 8) {
            b[f] = back[f]; b[8 + f] = 1
            b[48 + f] = -1; b[56 + f] = -back[f]
        }
        return ChessPos(b, true, 15, -1, 0, 1)
    }

    private fun slide(b: IntArray, f: Int, r: Int, df: IntArray, dr: IntArray, a: Int, q: Int, s: Int): Boolean {
        for (i in df.indices) {
            var nf = f + df[i]; var nr = r + dr[i]
            while (nf in 0..7 && nr in 0..7) {
                val v = b[nr * 8 + nf]
                if (v != 0) {
                    if (v == a * s || v == q * s) return true
                    break
                }
                nf += df[i]; nr += dr[i]
            }
        }
        return false
    }

    /** Is [sq] attacked by any piece of the given colour? */
    fun attacked(p: ChessPos, sq: Int, byWhite: Boolean): Boolean {
        val b = p.b; val f = sq % 8; val r = sq / 8
        val s = if (byWhite) 1 else -1
        val pr = if (byWhite) r - 1 else r + 1
        if (pr in 0..7) {
            if (f - 1 >= 0 && b[pr * 8 + f - 1] == s) return true
            if (f + 1 <= 7 && b[pr * 8 + f + 1] == s) return true
        }
        for (i in 0 until 8) {
            var nf = f + KN_F[i]; var nr = r + KN_R[i]
            if (nf in 0..7 && nr in 0..7 && b[nr * 8 + nf] == 2 * s) return true
            nf = f + KG_F[i]; nr = r + KG_R[i]
            if (nf in 0..7 && nr in 0..7 && b[nr * 8 + nf] == 6 * s) return true
        }
        if (slide(b, f, r, BD_F, BD_R, 3, 5, s)) return true
        if (slide(b, f, r, RD_F, RD_R, 4, 5, s)) return true
        return false
    }

    fun kingSquare(p: ChessPos, white: Boolean): Int {
        val k = if (white) 6 else -6
        for (i in 0 until 64) if (p.b[i] == k) return i
        return -1
    }

    fun inCheck(p: ChessPos): Boolean {
        val k = kingSquare(p, p.white)
        return k >= 0 && attacked(p, k, !p.white)
    }

    private fun pseudo(p: ChessPos): ArrayList<Int> {
        val b = p.b; val w = p.white; val s = if (w) 1 else -1
        val out = ArrayList<Int>(48)
        for (sq in 0 until 64) {
            val v = b[sq]
            if (v * s <= 0) continue
            val t = if (v < 0) -v else v
            val f = sq % 8; val r = sq / 8
            when (t) {
                1 -> {
                    val d = if (w) 1 else -1
                    val startRank = if (w) 1 else 6
                    val promoRank = if (w) 7 else 0
                    val nr = r + d
                    if (nr in 0..7) {
                        val to1 = nr * 8 + f
                        if (b[to1] == 0) {
                            if (nr == promoRank) { for (pp in PROMOS) out.add(mv(sq, to1, pp)) }
                            else {
                                out.add(mv(sq, to1))
                                if (r == startRank && b[to1 + 8 * d] == 0) out.add(mv(sq, to1 + 8 * d))
                            }
                        }
                        for (df in intArrayOf(-1, 1)) {
                            val nf = f + df
                            if (nf !in 0..7) continue
                            val to2 = nr * 8 + nf
                            if (b[to2] * s < 0 || to2 == p.ep) {
                                if (nr == promoRank) { for (pp in PROMOS) out.add(mv(sq, to2, pp)) }
                                else out.add(mv(sq, to2))
                            }
                        }
                    }
                }
                2, 6 -> {
                    for (i in 0 until 8) {
                        val nf = f + (if (t == 2) KN_F[i] else KG_F[i])
                        val nr = r + (if (t == 2) KN_R[i] else KG_R[i])
                        if (nf in 0..7 && nr in 0..7) {
                            val to = nr * 8 + nf
                            if (b[to] * s <= 0) out.add(mv(sq, to))
                        }
                    }
                }
                else -> {
                    val useB = t == 3 || t == 5
                    val useR = t == 4 || t == 5
                    for (pass in 0 until 2) {
                        if (pass == 0 && !useB) continue
                        if (pass == 1 && !useR) continue
                        val df = if (pass == 0) BD_F else RD_F
                        val dr = if (pass == 0) BD_R else RD_R
                        for (i in df.indices) {
                            var nf = f + df[i]; var nr = r + dr[i]
                            while (nf in 0..7 && nr in 0..7) {
                                val to = nr * 8 + nf
                                if (b[to] * s > 0) break
                                out.add(mv(sq, to))
                                if (b[to] != 0) break
                                nf += df[i]; nr += dr[i]
                            }
                        }
                    }
                }
            }
        }
        // Castling: rights kept, squares between empty, and the king may not start in, cross or land in check.
        if (w && b[4] == 6) {
            if (p.castle and 1 != 0 && b[7] == 4 && b[5] == 0 && b[6] == 0 &&
                !attacked(p, 4, false) && !attacked(p, 5, false) && !attacked(p, 6, false)) out.add(mv(4, 6))
            if (p.castle and 2 != 0 && b[0] == 4 && b[1] == 0 && b[2] == 0 && b[3] == 0 &&
                !attacked(p, 4, false) && !attacked(p, 3, false) && !attacked(p, 2, false)) out.add(mv(4, 2))
        }
        if (!w && b[60] == -6) {
            if (p.castle and 4 != 0 && b[63] == -4 && b[61] == 0 && b[62] == 0 &&
                !attacked(p, 60, true) && !attacked(p, 61, true) && !attacked(p, 62, true)) out.add(mv(60, 62))
            if (p.castle and 8 != 0 && b[56] == -4 && b[57] == 0 && b[58] == 0 && b[59] == 0 &&
                !attacked(p, 60, true) && !attacked(p, 59, true) && !attacked(p, 58, true)) out.add(mv(60, 58))
        }
        return out
    }

    /** Plays [m] (assumed pseudo-legal) and returns the resulting position. */
    fun make(p: ChessPos, m: Int): ChessPos {
        val fr = fromSq(m); val to = toSq(m); val pp = promoOf(m)
        val b = p.b.copyOf()
        val piece = b[fr]
        val t = if (piece < 0) -piece else piece
        val s = if (piece > 0) 1 else -1
        val captured = b[to]
        if (t == 1 && to == p.ep && captured == 0 && fr % 8 != to % 8) b[to - 8 * s] = 0   // en passant
        b[to] = piece; b[fr] = 0
        if (pp != 0) b[to] = s * pp
        if (t == 6 && (to - fr == 2 || fr - to == 2)) {                                     // castling: hop the rook
            if (to > fr) { b[fr + 1] = b[fr + 3]; b[fr + 3] = 0 } else { b[fr - 1] = b[fr - 4]; b[fr - 4] = 0 }
        }
        var c = p.castle
        if (t == 6) c = if (s > 0) c and 3.inv() else c and 12.inv()
        if (fr == 0 || to == 0) c = c and 2.inv()
        if (fr == 7 || to == 7) c = c and 1.inv()
        if (fr == 56 || to == 56) c = c and 8.inv()
        if (fr == 63 || to == 63) c = c and 4.inv()
        val diff = if (to > fr) to - fr else fr - to
        val ep = if (t == 1 && diff == 16) (fr + to) / 2 else -1
        val half = if (t == 1 || captured != 0) 0 else p.half + 1
        val full = p.full + (if (p.white) 0 else 1)
        return ChessPos(b, !p.white, c, ep, half, full)
    }

    /** Every fully legal move for the side to move. */
    fun legal(p: ChessPos): List<Int> {
        val out = ArrayList<Int>(40)
        for (m in pseudo(p)) {
            val n = make(p, m)
            val k = kingSquare(n, p.white)
            if (k >= 0 && !attacked(n, k, !p.white)) out.add(m)
        }
        return out
    }

    // ---- notation ----

    private fun sqName(sq: Int) = "${'a' + sq % 8}${'1' + sq / 8}"

    /** Coordinate notation as stored in the repo: "e2e4", "e7e8q". */
    fun uci(m: Int): String {
        val pp = promoOf(m)
        return sqName(fromSq(m)) + sqName(toSq(m)) + (if (pp != 0) "  nbrq"[pp].toString() else "")
    }

    /** Finds the legal move matching a stored coordinate string, or -1. */
    fun parse(p: ChessPos, s: String): Int {
        if (s.length < 4) return -1
        val f = (s[0] - 'a') + 8 * (s[1] - '1')
        val t = (s[2] - 'a') + 8 * (s[3] - '1')
        if (f !in 0..63 || t !in 0..63) return -1
        val pp = if (s.length >= 5) when (s[4]) { 'n' -> 2; 'b' -> 3; 'r' -> 4; 'q' -> 5; else -> 0 } else 0
        for (m in legal(p)) if (fromSq(m) == f && toSq(m) == t && promoOf(m) == pp) return m
        return -1
    }

    /** Standard algebraic notation ("Nf3", "exd5", "O-O", "e8=Q+") for showing the move list. */
    fun san(p: ChessPos, m: Int): String {
        val b = p.b; val fr = fromSq(m); val to = toSq(m); val pp = promoOf(m)
        val piece = b[fr]; val t = if (piece < 0) -piece else piece
        val sb = StringBuilder()
        if (t == 6 && (to - fr == 2 || fr - to == 2)) {
            sb.append(if (to > fr) "O-O" else "O-O-O")
        } else {
            val isCapture = b[to] != 0 || (t == 1 && fr % 8 != to % 8)
            if (t == 1) {
                if (isCapture) sb.append('a' + fr % 8)
            } else {
                sb.append("  NBRQK"[t])
                var sameFile = false; var sameRank = false; var other = false
                for (o in legal(p)) {
                    if (o == m || toSq(o) != to || fromSq(o) == fr) continue
                    val op = b[fromSq(o)]
                    if (op != piece) continue
                    other = true
                    if (fromSq(o) % 8 == fr % 8) sameFile = true
                    if (fromSq(o) / 8 == fr / 8) sameRank = true
                }
                if (other) {
                    if (!sameFile) sb.append('a' + fr % 8)
                    else if (!sameRank) sb.append('1' + fr / 8)
                    else sb.append(sqName(fr))
                }
            }
            if (isCapture) sb.append('x')
            sb.append(sqName(to))
            if (pp != 0) { sb.append('='); sb.append("  NBRQ"[pp]) }
        }
        val n = make(p, m)
        if (inCheck(n)) sb.append(if (legal(n).isEmpty()) '#' else '+')
        return sb.toString()
    }

    // ---- game state ----

    fun hasInsufficientMaterial(p: ChessPos): Boolean {
        var minors = 0
        for (v in p.b) {
            val t = if (v < 0) -v else v
            if (t == 1 || t == 4 || t == 5) return false
            if (t == 2 || t == 3) minors++
        }
        return minors <= 1
    }

    fun positionKey(p: ChessPos): String {
        val sb = StringBuilder(72)
        for (v in p.b) sb.append('a' + (v + 6))
        sb.append(if (p.white) 'w' else 'b').append(p.castle).append(':').append(p.ep)
        return sb.toString()
    }
}

/** What has happened to a game so far, worked out by replaying its move list from the start. */
class ChessReplay(
    val pos: ChessPos,
    val valid: Boolean,             // false if a stored move wasn't legal (corrupt file)
    val lastFrom: Int,
    val lastTo: Int,
    val sans: List<String>,
    val ended: String,              // "" while playing, else "checkmate" / "stalemate" / "insufficient" / "fifty" / "repetition"
    val winnerWhite: Boolean?,      // only meaningful for "checkmate"
    val check: Boolean
)

fun replayChess(moves: List<String>): ChessReplay {
    var pos = Chess.start()
    val seen = HashMap<String, Int>()
    seen[Chess.positionKey(pos)] = 1
    val sans = ArrayList<String>()
    var lf = -1; var lt = -1
    var valid = true
    var repetition = false
    for (s in moves) {
        val m = Chess.parse(pos, s)
        if (m < 0) { valid = false; break }
        sans.add(Chess.san(pos, m))
        lf = Chess.fromSq(m); lt = Chess.toSq(m)
        pos = Chess.make(pos, m)
        val k = Chess.positionKey(pos)
        val c = (seen[k] ?: 0) + 1
        seen[k] = c
        if (c >= 3) repetition = true
    }
    val check = Chess.inCheck(pos)
    val noMoves = Chess.legal(pos).isEmpty()
    var ended = ""
    var winnerWhite: Boolean? = null
    when {
        noMoves && check -> { ended = "checkmate"; winnerWhite = !pos.white }
        noMoves -> ended = "stalemate"
        Chess.hasInsufficientMaterial(pos) -> ended = "insufficient"
        pos.half >= 100 -> ended = "fifty"
        repetition -> ended = "repetition"
    }
    return ChessReplay(pos, valid, lf, lt, sans, ended, winnerWhite, check)
}
