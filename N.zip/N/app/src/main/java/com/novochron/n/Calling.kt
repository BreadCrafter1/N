package com.novochron.n

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.projection.MediaProjection
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.unit.Density
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlin.math.roundToInt
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RendererCommon
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.util.UUID
import kotlin.coroutines.resumeWithException

// ---------------------------------------------------------------------------------------------
// Calling, over the same "shared repo as mailbox" trick the chat uses. Up to MAX_PARTICIPANTS
// people can be in one call at a time, connected mesh-style (every phone holds one WebRTC
// PeerConnection to every other phone — workable for up to 7; past ~4 video feeds the app drops each outgoing stream's quality to keep phones cool).
//
// Signaling lives in a Call/ folder:
//   Call/room.json                              - who's in the current call (the "roster")
//   Call/offer-<callId>-<from>-<to>.json         - an SDP offer from one phone to another
//   Call/answer-<callId>-<from>-<to>.json        - the SDP answer back
//   Call/leave-<callId>-<name>.json              - "I'm leaving this call"
// Each SDP already has its ICE candidates baked in (non-trickle ICE), which suits polling far
// better than classic trickle ICE would. When someone joins a call already in progress, they
// send a fresh offer to everyone already in the room; the same offer/answer files are also
// reused later for renegotiation (e.g. adding a screenshare track), since a PeerConnection can
// go through more than one offer/answer round.
//
// Known limits: STUN alone can't get through every kind of NAT (a small fraction of networks
// need a TURN relay instead — add one to iceServers() below if that turns out to matter). With the
// app closed, MessageService (Notifier.kt) watches room.json and posts a ringing notification for an
// incoming call; tapping it opens the app, which then shows the usual accept/decline screen.
// ---------------------------------------------------------------------------------------------

private const val CALL_DIR = "Call"
const val CALL_POLL_MS = 1000L
const val RING_TIMEOUT_MS = 45_000L      // give up ringing after this long
private const val ICE_GATHER_TIMEOUT_MS = 8_000L  // cap on waiting for STUN candidates before sending anyway
const val MAX_CALL_PARTICIPANTS = 7
private const val HEARTBEAT_MS = 30_000L          // someone in the call refreshes room.json this often
const val JOIN_WINDOW_MS = 100_000L               // a room not refreshed for this long is treated as a dead call

/**
 * A snapshot of Call/room.json, kept up to date by [CallManager.poll]. The chat reads it to decide
 * whether a "started a call" card should still offer [join] (the call is live) or show "call ended".
 */
data class LiveRoom(
    val callId: String,
    val video: Boolean,
    val initiator: String,
    val participants: List<String>,
    val ended: Boolean,
    val lastSeenMs: Long,     // newest of the room's start/join time and its heartbeat
)

enum class CallPhase { RINGING_OUT, RINGING_IN, CONNECTING, CONNECTED, ENDED }

/**
 * Mirrors just enough of the live call state to be readable from the Activity, which is where
 * Picture-in-Picture has to be entered from (onUserLeaveHint) — CallManager itself lives deep in
 * the Compose tree (inside ChatBody), too deep for the Activity to reach directly.
 */
object CallPip {
    var active by mutableStateOf(false)   // true while a call is actually connected (worth shrinking to a window)
    var video by mutableStateOf(false)    // decides the window's aspect ratio
    var inPip by mutableStateOf(false)    // set by the Activity once PiP mode is actually entered/exited
}

/** One other person in the call: their camera track (if any) and their screenshare track (if any). */
data class ParticipantState(
    val name: String,
    val videoTrack: VideoTrack? = null,
    val screenTrack: VideoTrack? = null,
    val connected: Boolean = false,
)

data class CallUiState(
    val callId: String,
    val video: Boolean,
    val phase: CallPhase,
    val inviterName: String = "",   // who started the call, shown while it's ringing in
    val note: String = "",
    val muted: Boolean = false,
    val speakerOn: Boolean = false,
    val elapsedSec: Int = 0,
    val participants: List<ParticipantState> = emptyList(),
    val sharingScreen: Boolean = false,
)

/** Turns a display name into something safe to put in a filename. Lossy, but fine for a handful of people. */
fun safeName(name: String): String =
    name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "x" }

private fun roomFile() = "$CALL_DIR/room.json"
private fun offerFile(callId: String, from: String, to: String) = "$CALL_DIR/offer-$callId-${safeName(from)}-${safeName(to)}.json"
private fun answerFile(callId: String, from: String, to: String) = "$CALL_DIR/answer-$callId-${safeName(from)}-${safeName(to)}.json"
private fun leaveFile(callId: String, name: String) = "$CALL_DIR/leave-$callId-${safeName(name)}.json"

/** The WebRTC PeerConnectionFactory + shared EglBase, created once per process and reused across calls. */
private object Rtc {
    @Volatile private var initialized = false
    lateinit var eglBase: EglBase; private set
    lateinit var factory: PeerConnectionFactory; private set

    @Synchronized
    fun ensure(ctx: Context) {
        if (initialized) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        eglBase = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        initialized = true
    }
}

private abstract class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
}

/**
 * This device's own mic + camera, captured once per call and shared across every peer connection
 * in that call (one camera session, not one per person we're talking to).
 */
private class LocalMedia(context: Context) {
    val audioTrack: AudioTrack
    var videoTrack: VideoTrack? = null; private set
    private var capturer: CameraVideoCapturer? = null
    private var surfaceHelper: SurfaceTextureHelper? = null
    val filters = FilterProcessor()

    init {
        Rtc.ensure(context)
        val source = Rtc.factory.createAudioSource(MediaConstraints())
        audioTrack = Rtc.factory.createAudioTrack("n-audio-${UUID.randomUUID()}", source)
    }

    fun startCamera(context: Context) {
        if (videoTrack != null) return
        val enumerator = Camera2Enumerator(context)
        val name = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) } ?: enumerator.deviceNames.firstOrNull()
        val cap = name?.let { enumerator.createCapturer(it, null) } ?: return
        val helper = SurfaceTextureHelper.create("n-capture", Rtc.eglBase.eglBaseContext)
        val source = Rtc.factory.createVideoSource(false)
        source.setVideoProcessor(filters)     // every frame goes through the effects (a no-op while they are all "none")
        cap.initialize(helper, context, source.capturerObserver)
        cap.startCapture(1280, 720, 30)
        videoTrack = Rtc.factory.createVideoTrack("n-video-${UUID.randomUUID()}", source)
        capturer = cap; surfaceHelper = helper
    }

    fun setMuted(muted: Boolean) { audioTrack.setEnabled(!muted) }
    fun switchCamera() { capturer?.switchCamera(null) }

    fun close() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        capturer?.dispose(); surfaceHelper?.dispose(); videoTrack?.dispose(); audioTrack.dispose()
        filters.release()      // frees the face / background models
        capturer = null; surfaceHelper = null; videoTrack = null
    }
}

/** One call's WebRTC plumbing: the peer connection to a single other person. */
private class CallEngine(
    context: Context,
    private val onRemoteVideo: (VideoTrack?) -> Unit,
    private val onIceState: (PeerConnection.IceConnectionState) -> Unit,
) {
    private var pc: PeerConnection? = null
    init { Rtc.ensure(context) }

    private fun iceServers() = listOf(
        // Google's public STUN servers: free, no auth, just tell each phone its public address/port
        // so ICE can find a peer-to-peer path through most home/office NATs.
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
    )

    fun open(audioTrack: AudioTrack, videoTrack: VideoTrack?) {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_ONCE
        }
        pc = Rtc.factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) { onIceState(state) }
            override fun onTrack(transceiver: RtpTransceiver?) {
                (transceiver?.receiver?.track() as? VideoTrack)?.let(onRemoteVideo)
            }
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(p0: IceCandidate?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })
        pc?.addTrack(audioTrack, listOf("n-stream"))
        videoTrack?.let { pc?.addTrack(it, listOf("n-stream")) }
    }

    // With many people each phone encodes its camera once PER peer connection, so the more people, the
    // lower each outgoing stream is capped. 0 bitrate = no cap. Screenshare tracks are left alone.
    private var qBps = 0; private var qScale = 1.0; private var qFps = 30
    fun setQuality(bps: Int, scaleDown: Double, fps: Int) { qBps = bps; qScale = scaleDown; qFps = fps; applyQuality() }
    private fun applyQuality() {
        val peer = pc ?: return
        try {
            for (snd in peer.senders) {
                val t = snd.track() ?: continue
                if (t.kind() != "video" || t.id().startsWith("n-screen-")) continue
                val params = snd.parameters
                for (e in params.encodings) {
                    e.maxBitrateBps = if (qBps > 0) qBps else null
                    e.scaleResolutionDownBy = if (qBps > 0) qScale else 1.0
                    e.maxFramerate = if (qBps > 0) qFps else null
                }
                snd.setParameters(params)
            }
        } catch (_: Exception) {}
    }

    /** Adds an extra video track (the screenshare) to this one peer connection. Needs a fresh offer/answer after. */
    fun addExtraVideoTrack(track: VideoTrack) { pc?.addTrack(track, listOf("n-stream")) }

    /** Removes a previously-added track (by track id) from this peer connection. Also needs renegotiation after. */
    fun removeVideoTrackById(id: String) {
        pc?.senders?.firstOrNull { it.track()?.id() == id }?.let { pc?.removeTrack(it) }
    }

    /** Creates an offer, waits (briefly) for STUN candidates, and returns the SDP with them baked in. */
    suspend fun makeOffer(): SessionDescription = withContext(Dispatchers.Main) {
        val peer = pc ?: error("no peer connection")
        val created = suspendCancellableCoroutine<SessionDescription> { cont ->
            peer.createOffer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 != null) cont.resume(p0, null) else cont.resumeWithException(IllegalStateException("null offer"))
                }
                override fun onCreateFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "createOffer failed")) }
            }, MediaConstraints())
        }
        setLocalAndWaitForIce(created)
    }

    /** Sets the remote offer, creates an answer, waits for STUN candidates, and returns the answer SDP. */
    suspend fun makeAnswer(remoteOffer: SessionDescription): SessionDescription = withContext(Dispatchers.Main) {
        val peer = pc ?: error("no peer connection")
        setRemote(remoteOffer)
        val created = suspendCancellableCoroutine<SessionDescription> { cont ->
            peer.createAnswer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 != null) cont.resume(p0, null) else cont.resumeWithException(IllegalStateException("null answer"))
                }
                override fun onCreateFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "createAnswer failed")) }
            }, MediaConstraints())
        }
        setLocalAndWaitForIce(created)
    }

    suspend fun setRemoteAnswer(sdp: SessionDescription) = withContext(Dispatchers.Main) { setRemote(sdp) }

    private suspend fun setRemote(sdp: SessionDescription) {
        val peer = pc ?: error("no peer connection")
        suspendCancellableCoroutine<Unit> { cont ->
            peer.setRemoteDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() { cont.resume(Unit, null) }
                override fun onSetFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "setRemoteDescription failed")) }
            }, sdp)
        }
    }

    private suspend fun setLocalAndWaitForIce(sdp: SessionDescription): SessionDescription {
        val peer = pc ?: error("no peer connection")
        suspendCancellableCoroutine<Unit> { cont ->
            peer.setLocalDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() { cont.resume(Unit, null) }
                override fun onSetFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "setLocalDescription failed")) }
            }, sdp)
        }
        withTimeoutOrNull(ICE_GATHER_TIMEOUT_MS) {
            while (peer.iceGatheringState() != PeerConnection.IceGatheringState.COMPLETE) delay(150)
        }
        applyQuality()
        return peer.localDescription ?: sdp
    }

    fun close() { pc?.close(); pc?.dispose(); pc = null }
}

/**
 * Drives one call end-to-end for up to [MAX_CALL_PARTICIPANTS] people: placing/receiving/joining
 * it, the SDP handshakes over the shared repo (see the file header above), and the live
 * [CallUiState] the UI renders. One instance lives as long as the chat screen does, polling the
 * repo's Call/ folder the same way messages get polled.
 */
class CallManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val client: GitHubClient?,
    private val repo: RepoRef?,
    private val store: Store,
) {
    private var _ui by mutableStateOf<CallUiState?>(null)
    /** Setting this also mirrors phase/video into [CallPip], which the Activity reads to decide
     *  whether onUserLeaveHint() should shrink the call into a Picture-in-Picture window. */
    var ui: CallUiState?
        get() = _ui
        private set(value) {
            _ui = value
            CallPip.active = value?.phase == CallPhase.CONNECTED
            CallPip.video = value?.video ?: false
        }
    var localVideo by mutableStateOf<VideoTrack?>(null); private set
    /** Video effects currently applied to our camera: a whole-picture look, a face effect, and a background. */
    var fxColor by mutableStateOf(VideoFx.NONE); private set
    var fxFace by mutableStateOf(FaceFx.NONE); private set
    var fxBg by mutableStateOf(BgFx.NONE); private set
    var localScreenTrack by mutableStateOf<VideoTrack?>(null); private set
    /** Latest Call/room.json, or null if there has never been a call in this repo. */
    var liveRoom by mutableStateOf<LiveRoom?>(null); private set
    /** false until the first successful look at Call/ — so the chat doesn't flash "call ended" while it's still loading. */
    var roomChecked by mutableStateOf(false); private set
    /**
     * The chat hooks this to drop "started" / "ended" call cards into the conversation.
     * (event, callId, video, durationSec). Only the phone that starts / finishes a call posts these.
     */
    var onCallEvent: ((String, String, Boolean, Int) -> Unit)? = null
    val eglBaseContext: EglBase.Context get() { Rtc.ensure(context); return Rtc.eglBase.eglBaseContext }

    private fun myName() = store.name.ifBlank { "me" }

    private val audioManager: AudioManager? by lazy { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    private var savedAudioMode = AudioManager.MODE_NORMAL
    private var savedSpeakerOn = false

    private fun applySpeaker(on: Boolean) {
        val am = audioManager ?: return
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = on
    }

    fun toggleSpeaker() {
        val st = ui ?: return
        val on = !st.speakerOn
        applySpeaker(on)
        ui = st.copy(speakerOn = on)
    }

    private fun startAudioRouting(defaultSpeaker: Boolean) {
        val am = audioManager ?: return
        savedAudioMode = am.mode
        savedSpeakerOn = am.isSpeakerphoneOn
        applySpeaker(defaultSpeaker)
    }

    private fun stopAudioRouting() {
        val am = audioManager ?: return
        am.isSpeakerphoneOn = savedSpeakerOn
        am.mode = savedAudioMode
    }

    /** Keeps the mic (and camera, for video) alive and the process at foreground priority for as
     *  long as a call is active, so leaving the app doesn't end it. See CallService for why. */
    private fun startCallService(video: Boolean, sharingScreen: Boolean = false) {
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, CallService::class.java)
                    .putExtra("video", video)
                    .putExtra("sharingScreen", sharingScreen)
            )
        } catch (e: Exception) { DebugLog.add("call: keep-alive service didn't start: ${e.javaClass.simpleName}") }
    }

    /**
     * WebRTC reports back on its own internal threads, but everything here (the engines map, the UI
     * state, closing a peer connection) must only be touched from the main thread. Two of those
     * threads at once was a source of random crashes, worst with several people in the call.
     */
    private fun onMain(block: () -> Unit) { scope.launch { try { block() } catch (e: Exception) { DebugLog.add("call: callback failed: ${e.javaClass.simpleName}") } } }
    private fun stopCallService() { context.stopService(Intent(context, CallService::class.java)) }

    private var localMedia: LocalMedia? = null
    private val engines = mutableMapOf<String, CallEngine>()   // peer name -> their peer connection
    private var timerJob: Job? = null
    private val seenShas = mutableMapOf<String, String>()      // Call/ file path -> last-seen sha
    private var primed = false
    private var myCallId: String? = null
    private var roomInitiator = ""
    private var roomVideo = false
    private var roomTs = 0L
    private var hbJob: Job? = null
    private var lastHb = 0L
    private val droppedPeers = mutableSetOf<String>()         // people I know have left / failed, so they don't count as still in the room
    private val missingSince = mutableMapOf<String, Long>()    // roster members I haven't linked up with yet
    private var leftRoomFor: String? = null                    // guards against posting "ended" twice for one call
    private var roomParticipants: List<String> = emptyList()   // last roster we know of (includes me once joined)
    private val dismissedCallIds = mutableSetOf<String>()      // calls we declined, missed, or already left

    // ---- screenshare capture bits ----
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var screenHelper: SurfaceTextureHelper? = null

    // ---- room file + call cards ----

    /**
     * Updates room.json by merging into whatever is there now (read, add/remove just me, write), instead of
     * overwriting it with my own copy of the roster. With up to 7 people, two phones joining in the same
     * second would otherwise clobber each other's entry. Returns the roster that was written.
     */
    private suspend fun writeRoom(callId: String, initiator: String, video: Boolean, ts: Long, leaving: Boolean = false): List<String> {
        val c = client ?: return roomParticipants; val r = repo ?: return roomParticipants
        val me = myName()
        val current: List<String> = try {
            withContext(Dispatchers.IO) { c.readFile(roomFile(), r) }?.let { txt ->
                val o = JSONObject(txt)
                if (o.optString("callId") == callId && !o.optBoolean("ended", false)) {
                    val a = o.optJSONArray("participants")
                    if (a != null) (0 until a.length()).map { a.getString(it) } else emptyList()
                } else emptyList()
            } ?: emptyList()
        } catch (_: Exception) { roomParticipants }
        val roster = if (leaving) current.filter { it != me && it !in droppedPeers } else (current + me).distinct()
        val ended = leaving && roster.isEmpty()
        val body = JSONObject().apply {
            put("callId", callId); put("initiator", initiator); put("ts", ts); put("hb", System.currentTimeMillis())
            put("video", video); put("participants", JSONArray(roster)); put("ended", ended)
        }
        withContext(Dispatchers.IO) { c.writeFile(roomFile(), body.toString(), if (ended) "n: end call" else "n: call", r) }
        if (!leaving) roomParticipants = roster
        return roster
    }

    /** Is this room a call someone could join right now? */
    fun isJoinable(room: LiveRoom?, now: Long = System.currentTimeMillis()): Boolean {
        if (room == null || room.ended || room.participants.isEmpty()) return false
        if (now - room.lastSeenMs > JOIN_WINDOW_MS) return false
        return room.participants.size < MAX_CALL_PARTICIPANTS || myName() in room.participants
    }

    /**
     * Housekeeping loop while I'm in a call (every 5 s):
     *  1. heartbeat: keep room.json fresh so the "join" card stays live (and dies if everyone crashes);
     *  2. self-heal: if a simultaneous join knocked me off the roster, put myself back;
     *  3. link-up: if the roster has someone I'm not connected to (they joined at the same moment as me,
     *     so neither of us saw the other as "already there"), the one with the alphabetically-smaller
     *     name sends the offer. Waits 15 s first so the normal join handshake isn't duplicated.
     */
    private fun startHeartbeat() {
        hbJob?.cancel()
        lastHb = System.currentTimeMillis()
        hbJob = scope.launch {
            while (true) {
                delay(5_000)
                try { housekeep() }
                catch (e: kotlinx.coroutines.CancellationException) { throw e }
                catch (e: Exception) { DebugLog.add("call: housekeeping error: ${e.javaClass.simpleName}") }
            }
        }
    }

    private suspend fun housekeep() {
        val id = myCallId ?: return
        val me = myName(); val now = System.currentTimeMillis()
        val room = liveRoom

        if (now - lastHb >= HEARTBEAT_MS) {
            val stale = room?.let { now - it.lastSeenMs > HEARTBEAT_MS * 2 } ?: true
            if (roomParticipants.firstOrNull() == me || stale) {
                try { writeRoom(id, roomInitiator, roomVideo, roomTs); lastHb = now } catch (_: Exception) {}
            }
        }
        if (room != null && room.callId == id && !room.ended && me !in room.participants && now - lastHb > 10_000) {
            try { writeRoom(id, roomInitiator, roomVideo, roomTs); lastHb = now } catch (_: Exception) {}
        }
        val phase = ui?.phase
        if (phase == CallPhase.CONNECTING || phase == CallPhase.CONNECTED) {
            missingSince.keys.retainAll(roomParticipants.toSet())
            for (p in roomParticipants.toList()) {
                if (p == me || p in engines || p in droppedPeers) { missingSince.remove(p); continue }
                val since = missingSince.getOrPut(p) { now }
                if (now - since > 15_000 && safeName(me) < safeName(p)) {
                    try { connectTo(p, id, roomVideo) } catch (e: Exception) { DebugLog.add("call: link-up with $p failed: ${e.message?.take(60)}") }
                }
            }
        }
    }

    /**
     * I'm leaving for good. If nobody else is left, the call is over for everyone: close the room and
     * post the "call ended" card. Otherwise I just come off the roster and the call carries on.
     */
    private fun leaveRoom(st: CallUiState) {
        if (leftRoomFor == st.callId) return
        leftRoomFor = st.callId
        val me = myName()
        val video = st.video; val dur = st.elapsedSec; val callId = st.callId
        val initiator = roomInitiator.ifBlank { st.inviterName.ifBlank { me } }
        val ts = if (roomTs > 0) roomTs else System.currentTimeMillis()
        val dropped = droppedPeers.toSet()
        scope.launch {
            val remaining = try { writeRoom(callId, initiator, video, ts, leaving = true) }
            catch (e: Exception) { DebugLog.add("call: couldn't update room: ${e.message?.take(60)}"); roomParticipants.filter { it != me && it !in dropped } }
            if (remaining.isEmpty()) onCallEvent?.invoke("ended", callId, video, dur)
        }
    }

    /** Join the call that's live right now (the [join] button on a call card in the chat). */
    fun joinLive() {
        if (ui != null) return
        val room = liveRoom ?: return
        if (!isJoinable(room)) return
        dismissedCallIds -= room.callId
        leftRoomFor = null
        myCallId = room.callId
        roomParticipants = room.participants
        roomInitiator = room.initiator; roomVideo = room.video
        ui = CallUiState(room.callId, video = room.video, phase = CallPhase.RINGING_IN, inviterName = room.initiator)
        accept()
    }

    fun startCall(video: Boolean) {
        if (ui != null) return
        val c = client ?: return; val r = repo ?: return
        val callId = UUID.randomUUID().toString().take(8)
        myCallId = callId; roomParticipants = listOf(myName())
        startAudioRouting(defaultSpeaker = video)
        ui = CallUiState(callId, video = video, phase = CallPhase.RINGING_OUT, speakerOn = video)
        scope.launch {
            try {
                startCallService(video)
                localMedia = LocalMedia(context).also { if (video) it.startCamera(context) }
                localVideo = localMedia?.videoTrack
                roomInitiator = myName(); roomVideo = video; roomTs = System.currentTimeMillis(); leftRoomFor = null
                writeRoom(callId, myName(), video, roomTs)
                startHeartbeat()
                onCallEvent?.invoke("started", callId, video, 0)     // the "started a call" card in the chat
                DebugLog.add("call: started ($callId)")
            } catch (e: Exception) { DebugLog.add("call: failed to start: ${e.message?.take(60)}"); endLocally() }
        }
        scope.launch {
            delay(RING_TIMEOUT_MS)
            val st = ui
            if (st != null && st.callId == callId && st.participants.isEmpty()) {
                leaveRoom(st)
                ui = st.copy(phase = CallPhase.ENDED, note = "No answer")
                delay(1200); if (ui?.callId == callId) endLocally()
            }
        }
    }

    /** Accept an incoming ring, or join a call already in progress that we're currently shown as ringing for. */
    fun accept() {
        val st = ui ?: return
        val c = client ?: return; val r = repo ?: return
        val myN = myName()
        val existing = roomParticipants.filter { it != myN }
        startAudioRouting(defaultSpeaker = st.video)
        ui = st.copy(phase = CallPhase.CONNECTING, speakerOn = st.video)
        scope.launch {
            try {
                startCallService(st.video)
                localMedia = LocalMedia(context).also { if (st.video) it.startCamera(context) }
                localVideo = localMedia?.videoTrack
                // Offer to everyone already in the call, all at once (one after another would take a while with 6 people).
                coroutineScope {
                    existing.map { peer ->
                        async {
                            try { connectTo(peer, st.callId, st.video) }
                            catch (e: Exception) { DebugLog.add("call: couldn't reach $peer: ${e.message?.take(60)}") }
                        }
                    }.awaitAll()
                }
                leftRoomFor = null
                roomInitiator = st.inviterName; roomVideo = st.video; roomTs = System.currentTimeMillis()
                writeRoom(st.callId, st.inviterName, st.video, roomTs)
                startHeartbeat()
                startTimer()
                if (existing.isEmpty()) ui = ui?.copy(phase = CallPhase.CONNECTED)
            } catch (e: Exception) { DebugLog.add("call: failed to join: ${e.message?.take(60)}"); endLocally() }
        }
    }

    private suspend fun connectTo(peer: String, callId: String, video: Boolean) {
        val c = client ?: return; val r = repo ?: return
        if (engines.containsKey(peer)) return
        val lm = localMedia ?: return
        val eng = CallEngine(context, onRemoteVideo = { track -> onMain { if (peer in engines) onRemoteTrack(peer, track) } }, onIceState = { s -> onMain { if (peer in engines) onIce(peer, s) } })
        eng.open(lm.audioTrack, lm.videoTrack)
        localScreenTrack?.let { eng.addExtraVideoTrack(it) }
        engines[peer] = eng
        updateQuality()
        updateParticipant(peer) { it }
        val offer = eng.makeOffer()
        val body = JSONObject().apply {
            put("callId", callId); put("from", myName()); put("to", peer); put("video", video); put("sdp", offer.description)
        }
        withContext(Dispatchers.IO) { c.writeFile(offerFile(callId, myName(), peer), body.toString(), "n: call offer", r) }
    }

    fun decline() {
        val st = ui ?: return
        dismissedCallIds += st.callId
        endLocally()
    }

    fun hangup() {
        val st = ui
        val c = client; val r = repo
        if (st != null) {
            dismissedCallIds += st.callId
            if (st.phase == CallPhase.RINGING_OUT || st.phase == CallPhase.CONNECTING || st.phase == CallPhase.CONNECTED) leaveRoom(st)
            if (c != null && r != null) {
                scope.launch {
                    try {
                        val body = JSONObject().apply { put("callId", st.callId); put("from", myName()) }
                        withContext(Dispatchers.IO) { c.writeFile(leaveFile(st.callId, myName()), body.toString(), "n: leave call", r) }
                    } catch (_: Exception) {}
                }
            }
        }
        endLocally()
    }

    fun toggleMute() {
        val st = ui ?: return
        val m = !st.muted
        localMedia?.setMuted(m)
        ui = st.copy(muted = m)
    }

    fun switchCamera() { localMedia?.switchCamera() }

    // ---- screenshare ----

    /** [resultData] is the Intent returned by MediaProjectionManager's screen-capture consent dialog. */
    fun startScreenShare(resultData: Intent) {
        if (localScreenTrack != null) return
        val callId = myCallId ?: return
        ContextCompat.startForegroundService(context, Intent(context, ScreenShareService::class.java))
        scope.launch {
            try {
                delay(250) // give the foreground service a beat to call startForeground() first
                Rtc.ensure(context)
                val source = Rtc.factory.createVideoSource(true) // isScreencast
                val helper = SurfaceTextureHelper.create("n-screen-capture", Rtc.eglBase.eglBaseContext)
                val capturer = ScreenCapturerAndroid(resultData, object : MediaProjection.Callback() {
                    override fun onStop() { scope.launch { stopScreenShare() } }
                })
                capturer.initialize(helper, context, source.capturerObserver)
                capturer.startCapture(1280, 720, 30)
                val track = Rtc.factory.createVideoTrack("n-screen-${UUID.randomUUID()}", source)
                screenCapturer = capturer; screenHelper = helper; localScreenTrack = track
                engines.values.toList().forEach { it.addExtraVideoTrack(track) }
                renegotiateAll(callId)
                ui = ui?.copy(sharingScreen = true)
                startCallService(video = ui?.video == true, sharingScreen = true)
                DebugLog.add("screenshare: started")
            } catch (e: Exception) {
                DebugLog.add("screenshare: failed to start: ${e.message?.take(60)}")
                stopScreenShare()
            }
        }
    }

    fun stopScreenShare(ending: Boolean = false) {
        val track = localScreenTrack ?: return
        val callId = myCallId
        engines.values.toList().forEach { eng -> eng.removeVideoTrackById(track.id()) }
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        screenCapturer?.dispose(); screenHelper?.dispose(); track.dispose()
        screenCapturer = null; screenHelper = null; localScreenTrack = null
        context.stopService(Intent(context, ScreenShareService::class.java))
        ui = ui?.copy(sharingScreen = false)
        if (ui != null && !ending) startCallService(video = ui?.video == true, sharingScreen = false)
        if (callId != null) scope.launch { renegotiateAll(callId) }
        DebugLog.add("screenshare: stopped")
    }

    /** Re-runs the offer/answer handshake with everyone already in the call (used after adding/removing a track). */
    private suspend fun renegotiateAll(callId: String) {
        val c = client ?: return; val r = repo ?: return
        coroutineScope { engines.toMap().map { (peer, eng) -> async {
            try {
                val offer = eng.makeOffer()
                val body = JSONObject().apply {
                    put("callId", callId); put("from", myName()); put("to", peer); put("video", true); put("sdp", offer.description)
                }
                withContext(Dispatchers.IO) { c.writeFile(offerFile(callId, myName(), peer), body.toString(), "n: renegotiate", r) }
            } catch (e: Exception) { DebugLog.add("call: renegotiate with $peer failed: ${e.message?.take(60)}") }
        } }.awaitAll() }
    }

    // ---- incoming signaling ----

    private fun onRemoteTrack(peer: String, track: VideoTrack?) {
        // The other side may be Novochron (this app's sibling) rather than another N - Novochron
        // tags its screenshare tracks "novochron-screen-..." instead of "n-screen-...". Recognize
        // both so a screenshare from either app is filed as screenTrack, not mistaken for camera.
        val id = track?.id() ?: ""
        val isScreen = id.startsWith("n-screen-") || id.startsWith("novochron-screen-")
        updateParticipant(peer) { if (isScreen) it.copy(screenTrack = track) else it.copy(videoTrack = track) }
    }

    private fun onIce(peer: String, state: PeerConnection.IceConnectionState) {
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> {
                updateParticipant(peer) { it.copy(connected = true) }
                val st = ui
                if (st != null && st.phase != CallPhase.CONNECTED) { ui = st.copy(phase = CallPhase.CONNECTED, note = ""); startTimer() }
            }
            PeerConnection.IceConnectionState.FAILED -> { DebugLog.add("call: $peer connection failed"); dropPeer(peer, "$peer disconnected") }
            PeerConnection.IceConnectionState.DISCONNECTED -> updateParticipant(peer) { it.copy(connected = false) }
            else -> {}
        }
    }

    private fun updateParticipant(name: String, transform: (ParticipantState) -> ParticipantState) {
        val st = ui ?: return
        val list = st.participants.toMutableList()
        val idx = list.indexOfFirst { it.name == name }
        if (idx >= 0) list[idx] = transform(list[idx]) else list += transform(ParticipantState(name))
        ui = st.copy(participants = list)
    }

    /** Fewer outgoing pixels per stream as the call fills up (each peer connection encodes the camera separately). */
    private fun updateQuality() {
        val n = engines.size
        val (bps, scale, fps) = when {
            n <= 2 -> Triple(0, 1.0, 30)
            n <= 4 -> Triple(600_000, 1.5, 24)
            else -> Triple(300_000, 2.0, 15)
        }
        engines.values.toList().forEach { it.setQuality(bps, scale, fps) }
    }

    private fun dropPeer(name: String, note: String) {
        droppedPeers += name
        engines.remove(name)?.close()
        updateQuality()
        roomParticipants = roomParticipants.filter { it != name }
        val st = ui ?: return
        val remaining = st.participants.filter { it.name != name }
        if (remaining.isEmpty() && (st.phase == CallPhase.CONNECTED || st.phase == CallPhase.CONNECTING)) {
            leaveRoom(st)    // last one standing: closes the room and posts "call ended"
            ui = st.copy(participants = remaining, note = note)
            val cid = st.callId
            scope.launch { delay(1200); if (ui?.callId == cid) endLocally() }
        } else {
            ui = st.copy(participants = remaining, note = note)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch { while (true) { delay(1000); ui = ui?.let { it.copy(elapsedSec = it.elapsedSec + 1) } } }
    }

    /** Effects are applied to what the other person sees, and to our own preview. */
    fun setColorFx(fx: VideoFx) { val lm = localMedia ?: return; lm.filters.mode = fx; fxColor = fx }
    fun setFaceFx(fx: FaceFx) { val lm = localMedia ?: return; lm.filters.face = fx; fxFace = fx }
    fun setBgFx(fx: BgFx) { val lm = localMedia ?: return; lm.filters.bg = fx; fxBg = fx }
    fun clearFx() { setColorFx(VideoFx.NONE); setFaceFx(FaceFx.NONE); setBgFx(BgFx.NONE) }

    private fun endLocally() {
        fxColor = VideoFx.NONE; fxFace = FaceFx.NONE; fxBg = BgFx.NONE
        timerJob?.cancel(); timerJob = null
        hbJob?.cancel(); hbJob = null
        engines.values.toList().forEach { it.close() }; engines.clear()
        if (localScreenTrack != null) stopScreenShare(ending = true)
        localMedia?.close(); localMedia = null
        stopAudioRouting()
        stopCallService()
        localVideo = null; myCallId = null; roomParticipants = emptyList()
        roomInitiator = ""; roomTs = 0L; leftRoomFor = null
        droppedPeers.clear(); missingSince.clear()
        ui = null
    }

    /** Call from a ~1s loop — piggybacks the same repo-polling pattern the chat already uses. */
    suspend fun poll() {
        val c = client ?: return; val r = repo ?: return
        val files = try { c.listFiles(CALL_DIR, r) } catch (e: Exception) { return }

        if (!primed) {
            // Don't replay whatever's already sitting in Call/ from a previous session - except room.json:
            // if someone is ringing right now (e.g. you tapped the incoming-call notification), it
            // should still show up. handleRoom drops it anyway if it's older than the ring timeout.
            for (f in files) if (f.path.substringAfterLast('/') != "room.json") seenShas[f.path] = f.sha
            primed = true
            return
        }
        for (f in files) {
            if (f.isDir) continue
            val prev = seenShas[f.path]
            if (prev == f.sha) continue
            seenShas[f.path] = f.sha
            val leaf = f.path.substringAfterLast('/')
            val body = try { c.readFile(f.path, r) } catch (_: Exception) { null } ?: continue
            when {
                leaf == "room.json" -> handleRoom(body)
                leaf.startsWith("offer-") -> handleOfferFile(body)
                leaf.startsWith("answer-") -> handleAnswerFile(body)
                leaf.startsWith("leave-") -> handleLeaveFile(body)
            }
        }
        roomChecked = true
    }

    private fun handleRoom(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); if (callId.isBlank()) return
        val initiator = o.optString("initiator", "")
        val video = o.optBoolean("video", false)
        val ts = o.optLong("ts", 0L)
        val arr = o.optJSONArray("participants")
        val participants = if (arr != null) (0 until arr.length()).map { arr.getString(it) } else emptyList()
        val ended = o.optBoolean("ended", false)
        val hb = o.optLong("hb", 0L)

        // Always remember the latest room: the chat's "join" cards read it.
        liveRoom = LiveRoom(callId, video, initiator, participants, ended, maxOf(ts, hb))

        if (ended) {
            // The caller gave up (or everyone left). If it was still ringing on my screen, stop it.
            val st = ui
            if (myCallId == callId && st != null && st.phase == CallPhase.RINGING_IN) { dismissedCallIds += callId; endLocally() }
            return
        }
        if (myCallId == callId) { roomParticipants = participants; return }   // just a roster refresh
        if (callId in dismissedCallIds) return
        if (initiator == myName()) return   // my own room write coming back around
        if (ui != null) return              // already busy with a different call
        if (System.currentTimeMillis() - ts > RING_TIMEOUT_MS) { dismissedCallIds += callId; return }
        if (participants.size >= MAX_CALL_PARTICIPANTS) { dismissedCallIds += callId; return }

        myCallId = callId
        roomParticipants = participants
        ui = CallUiState(callId, video = video, phase = CallPhase.RINGING_IN, inviterName = initiator)
        scope.launch {
            delay(RING_TIMEOUT_MS)
            val st = ui
            if (st != null && st.callId == callId && st.phase == CallPhase.RINGING_IN) { dismissedCallIds += callId; endLocally() }
        }
    }

    private fun handleOfferFile(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val from = o.optString("from", ""); val to = o.optString("to", "")
        if (callId.isBlank() || from.isBlank() || to != myName()) return
        if (myCallId != callId) return
        val sdp = o.optString("sdp", ""); if (sdp.isBlank()) return
        val video = o.optBoolean("video", false)
        scope.launch {
            val existingEngine = engines[from]
            if (existingEngine != null) {
                // Renegotiation on an already-open connection (e.g. peer added their screenshare).
                try {
                    val answer = existingEngine.makeAnswer(SessionDescription(SessionDescription.Type.OFFER, sdp))
                    sendAnswer(callId, from, answer)
                } catch (e: Exception) { DebugLog.add("call: renegotiate answer to $from failed: ${e.message?.take(60)}") }
                return@launch
            }
            // First time hearing from this peer: either they're the initiator (I just accepted and
            // haven't heard back yet) or they're joining a call I'm already in.
            val lm = localMedia
            if (myCallId == null || lm == null) return@launch
            try {
                val eng = CallEngine(context, onRemoteVideo = { t -> onMain { if (from in engines) onRemoteTrack(from, t) } }, onIceState = { s -> onMain { if (from in engines) onIce(from, s) } })
                eng.open(lm.audioTrack, lm.videoTrack)
                localScreenTrack?.let { eng.addExtraVideoTrack(it) }
                droppedPeers -= from
                engines[from] = eng
                updateQuality()
                updateParticipant(from) { it }
                if (!roomParticipants.contains(from)) roomParticipants = roomParticipants + from
                val answer = eng.makeAnswer(SessionDescription(SessionDescription.Type.OFFER, sdp))
                sendAnswer(callId, from, answer)
                val st = ui
                if (st != null && st.phase == CallPhase.RINGING_IN) ui = st.copy(phase = CallPhase.CONNECTING)
            } catch (e: Exception) { DebugLog.add("call: failed to answer $from: ${e.message?.take(60)}") }
        }
    }

    private suspend fun sendAnswer(callId: String, to: String, answer: SessionDescription) {
        val c = client ?: return; val r = repo ?: return
        val body = JSONObject().apply {
            put("callId", callId); put("from", myName()); put("to", to); put("sdp", answer.description)
        }
        withContext(Dispatchers.IO) { c.writeFile(answerFile(callId, myName(), to), body.toString(), "n: call answer", r) }
    }

    private fun handleAnswerFile(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val from = o.optString("from", ""); val to = o.optString("to", "")
        if (to != myName() || myCallId != callId) return
        val sdp = o.optString("sdp", ""); if (sdp.isBlank()) return
        val eng = engines[from] ?: return
        scope.launch {
            try { eng.setRemoteAnswer(SessionDescription(SessionDescription.Type.ANSWER, sdp)) }
            catch (e: Exception) { DebugLog.add("call: bad answer from $from: ${e.message?.take(60)}") }
        }
    }

    private fun handleLeaveFile(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val name = o.optString("from", "")
        if (myCallId != callId || name.isBlank() || name == myName()) return
        dropPeer(name, "$name left")
    }

    fun dispose() {
        timerJob?.cancel(); engines.values.forEach { it.close() }; localMedia?.close(); stopCallService()
        CallPip.active = false
    }
}

// ---------------- UI ----------------

// The call screens follow the app theme, exactly like the chat: the shared background (colour, gradient or
// image), the accent / letter colours, and the same round chip buttons with vector icons. Anything that sits
// directly on top of live video goes on a translucent theme-coloured chip so it stays readable in both
// light and dark mode.
private val Scrim: Color get() = Bg.copy(alpha = 0.72f)

@Composable
private fun VideoView(track: VideoTrack?, eglBaseContext: EglBase.Context, modifier: Modifier = Modifier, mirror: Boolean = false) {
    val ctx = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(ctx).apply {
            init(eglBaseContext, null)
            setMirror(mirror)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        }
    }
    // Declared release-first: Compose disposes in reverse order, so the track is unhooked BEFORE the
    // renderer is released. Both calls are wrapped because the call can tear down (and dispose the
    // native track) a moment before the screen notices; touching a disposed track throws.
    DisposableEffect(Unit) { onDispose { try { renderer.release() } catch (_: Exception) {} } }
    DisposableEffect(track) {
        try { track?.addSink(renderer) } catch (_: Exception) {}
        onDispose { try { track?.removeSink(renderer) } catch (_: Exception) {} }
    }
    AndroidView(factory = { renderer }, modifier = modifier)
}

@Composable
private fun CallControl(label: String, color: Color, modifier: Modifier, sizeSp: Int, onClick: () -> Unit) {
    Box(modifier.heightIn(min = 48.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = color, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = sizeSp.sp, maxLines = 1, softWrap = false)
    }
}

private enum class BtnKind { NORMAL, ACTIVE, ACCEPT, DANGER }

/** A round icon button with its name underneath. NORMAL is the same outlined chip as the chat's icon buttons;
 *  ACTIVE / ACCEPT fill with the accent colour; DANGER (decline / end) fills with the warning colour. */
@Composable
private fun CallRoundBtn(
    ic: Ic, label: String, modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.NORMAL, size: Dp = 52.dp, onClick: () -> Unit
) {
    val fill = when (kind) {
        BtnKind.NORMAL -> Raised
        BtnKind.ACTIVE, BtnKind.ACCEPT -> Accent
        BtnKind.DANGER -> Warn
    }
    val glyph = when (kind) {
        BtnKind.NORMAL -> IconTint
        BtnKind.ACTIVE, BtnKind.ACCEPT -> Bg
        BtnKind.DANGER -> Color.White
    }
    Column(
        modifier.heightIn(min = 48.dp).clip(RoundedCornerShape(14.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(size).clip(CircleShape).background(fill)
                .then(if (kind == BtnKind.NORMAL) Modifier.border(1.dp, IconTint.copy(alpha = 0.45f), CircleShape) else Modifier),
            contentAlignment = Alignment.Center
        ) { IconGlyph(ic, glyph, size * 0.46f) }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Ink, fontFamily = TermFont, fontSize = 10.sp, maxLines = 1, softWrap = false)
    }
}

/** The wide red button that ends (or cancels) a call. */
@Composable
private fun EndCallPill(label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Warn)
            .clickable(role = Role.Button, onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        IconGlyph(Ic.CallEnd, Color.White, 24.dp)
        Spacer(Modifier.width(8.dp))
        Text(label, color = Color.White, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** One tappable effect: big emoji with its name underneath, outlined in the accent colour when it is on. */
@Composable
private fun FxChip(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.width(68.dp).clip(shape)
            .background(if (selected) Accent.copy(alpha = 0.16f) else Color.Transparent)
            .border(1.5.dp, if (selected) Accent else Line, shape)
            .clickable(onClick = onClick).padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 24.sp)
        Text(label, color = if (selected) Accent else Ink, fontFamily = TermFont, fontSize = 10.sp, maxLines = 1, softWrap = false)
    }
}

/** The effects picker shown above the call buttons: filters / faces / backgrounds, Messenger-style. Each row is independent, so they combine. */
@Composable
private fun FxPanel(
    colorFx: VideoFx, faceFx: FaceFx, bgFx: BgFx,
    onColorFx: (VideoFx) -> Unit, onFaceFx: (FaceFx) -> Unit, onBgFx: (BgFx) -> Unit, onClear: () -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(shape)
            .background(Bg.copy(alpha = 0.86f)).border(1.dp, Line, shape).padding(vertical = 4.dp)
    ) {
        Row(Modifier.fillMaxWidth()) {
            CallControl("filters", if (tab == 0) Accent else Dim, Modifier.weight(1f), 12) { tab = 0 }
            CallControl("faces", if (tab == 1) Accent else Dim, Modifier.weight(1f), 12) { tab = 1 }
            CallControl("backgrounds", if (tab == 2) Accent else Dim, Modifier.weight(1f), 12) { tab = 2 }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when (tab) {
                0 -> VideoFx.values().forEach { FxChip(it.icon, it.label, it == colorFx) { onColorFx(it) } }
                1 -> FaceFx.values().forEach { FxChip(it.icon, it.label, it == faceFx) { onFaceFx(it) } }
                else -> BgFx.values().forEach { FxChip(it.icon, it.label, it == bgFx) { onBgFx(it) } }
            }
        }
        if (tab == 1) Text(
            "needs your face in view", color = Dim, fontFamily = TermFont, fontSize = 10.sp,
            modifier = Modifier.padding(start = 12.dp, bottom = 2.dp)
        )
        if (colorFx != VideoFx.NONE || faceFx != FaceFx.NONE || bgFx != BgFx.NONE) {
            CallControl("[clear all]", Warn, Modifier.fillMaxWidth().heightIn(min = 36.dp), 12, onClear)
        }
    }
}

@Composable
private fun CallButton(label: String, color: Color, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label, color = color, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

/** Compact view shown while the call is shrunk into a Picture-in-Picture window: just the video
 *  (remote if there is one, else my own preview) or, for a voice call, the name and timer. No
 *  buttons — the PiP window is too small to tap reliably; tapping it re-opens the full app. */
@Composable
fun CallPipView(state: CallUiState, localVideo: VideoTrack?, eglBaseContext: EglBase.Context) {
    Box(Modifier.fillMaxSize()) {
        ThemedBackground()
        val remote = state.participants.firstNotNullOfOrNull { it.videoTrack }
        val track = remote ?: localVideo.takeIf { state.video }
        if (track != null) {
            VideoView(track, eglBaseContext, Modifier.fillMaxSize(), mirror = track === localVideo)
        } else {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                val names = (listOf("me") + state.participants.map { Profiles.display(it.name) }).joinToString(", ")
                Text(names, color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text("%d:%02d".format(state.elapsedSec / 60, state.elapsedSec % 60), color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
    }
}

/** Full-screen call UI: ringing (either direction), connecting, and the live call itself — for up to 7 people. */
@Composable
fun CallOverlay(
    state: CallUiState,
    localVideo: VideoTrack?,
    localScreenTrack: VideoTrack?,
    eglBaseContext: EglBase.Context,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onHangup: () -> Unit,
    onToggleMute: () -> Unit,
    onSwitchCamera: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onStartScreenShare: () -> Unit,
    onStopScreenShare: () -> Unit,
    onMinimize: () -> Unit,
    colorFx: VideoFx = VideoFx.NONE,
    faceFx: FaceFx = FaceFx.NONE,
    bgFx: BgFx = BgFx.NONE,
    onColorFx: (VideoFx) -> Unit = {},
    onFaceFx: (FaceFx) -> Unit = {},
    onBgFx: (BgFx) -> Unit = {},
    onClearFx: () -> Unit = {},
) {
    val view = LocalView.current
    var showFx by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }

    Dialog(
        // Back while connected just tucks the call away (it keeps running); ending it is always the explicit end button.
        onDismissRequest = {
            when (state.phase) {
                CallPhase.CONNECTED -> onMinimize()
                CallPhase.RINGING_IN -> {}
                else -> onHangup()
            }
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize()) {
            // Same shared background as the chat (and it syncs between phones), instead of plain black.
            ThemedBackground()
            val live = state.phase == CallPhase.CONNECTING || state.phase == CallPhase.CONNECTED
            // A screenshare (mine or someone else's) takes over the main area when present.
            val remoteScreen = state.participants.firstNotNullOfOrNull { it.screenTrack }
            val screenToShow = remoteScreen ?: localScreenTrack.takeIf { state.sharingScreen }

            if (live && screenToShow != null) {
                VideoView(screenToShow, eglBaseContext, Modifier.fillMaxSize())
                // Camera thumbnails (everyone's, including mine) in a strip along the top.
                Row(
                    Modifier.align(Alignment.TopCenter).padding(top = 64.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (state.video) VideoView(localVideo, eglBaseContext, mirror = true, modifier = Modifier.size(70.dp, 96.dp).clip(RoundedCornerShape(8.dp)))
                    if (state.video) state.participants.forEach { p ->
                        VideoView(p.videoTrack, eglBaseContext, modifier = Modifier.size(70.dp, 96.dp).clip(RoundedCornerShape(8.dp)))
                    }
                }
            } else if (live && state.video) {
                // Camera tiles for everyone else, split evenly; my own preview floats top-right.
                // Everyone else in a grid: side by side for 1-2 people, two columns once it's more (up to 6 tiles).
                val others = state.participants
                if (others.isEmpty()) {
                    Box(Modifier.fillMaxSize())
                } else {
                    val cols = if (others.size <= 2) others.size else 2
                    Column(Modifier.fillMaxSize()) {
                        others.chunked(cols).forEach { rowList ->
                            Row(Modifier.weight(1f).fillMaxWidth()) {
                                rowList.forEach { p ->
                                    Box(Modifier.weight(1f).fillMaxHeight()) {
                                        VideoView(p.videoTrack, eglBaseContext, modifier = Modifier.fillMaxSize())
                                        Text(
                                            Profiles.display(p.name), color = Ink, fontFamily = TermFont, fontSize = 12.sp,
                                            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                                                .clip(RoundedCornerShape(6.dp)).background(Scrim)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                repeat(cols - rowList.size) { Box(Modifier.weight(1f).fillMaxHeight()) }
                            }
                        }
                    }
                }
                VideoView(
                    localVideo, eglBaseContext, mirror = true,
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).size(90.dp, 120.dp).clip(RoundedCornerShape(8.dp))
                )
            }

            if (state.phase != CallPhase.RINGING_IN && state.phase != CallPhase.ENDED) {
                Box(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(8.dp)) {
                    IconBtn(Ic.Minimize, "hide call") { onMinimize() }
                }
            }
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (!(live && state.video)) {
                    // Show the other person's picture when it is clear who it is (1:1 call, or who is ringing me).
                    val who = when {
                        state.phase == CallPhase.RINGING_IN -> state.inviterName
                        state.participants.size == 1 -> state.participants[0].name
                        else -> ""
                    }
                    if (who.isNotBlank()) {
                        Avatar(who, 96.dp)
                        Spacer(Modifier.height(16.dp))
                    }
                    val names = when (state.phase) {
                        CallPhase.RINGING_IN -> Profiles.display(state.inviterName)
                        else -> (listOf("me") + state.participants.map { Profiles.display(it.name) }).joinToString(", ")
                    }
                    Text(names, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when (state.phase) {
                            CallPhase.RINGING_OUT -> "calling…"
                            CallPhase.RINGING_IN -> if (state.video) "incoming video call…" else "incoming call…"
                            CallPhase.CONNECTING -> "connecting…"
                            CallPhase.CONNECTED -> "%d:%02d".format(state.elapsedSec / 60, state.elapsedSec % 60)
                            CallPhase.ENDED -> state.note.ifBlank { "call ended" }
                        },
                        color = Dim, fontFamily = TermFont, fontSize = 14.sp
                    )
                    if (state.note.isNotBlank() && state.phase != CallPhase.ENDED) {
                        Spacer(Modifier.height(4.dp))
                        Text(state.note, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                    }
                }
            }
            // Bottom controls: round icon buttons in equal-width columns that always fit the screen, with the
            // end/cancel button on its own full-width row that never moves. Font scaling is locked to 1x
            // here so a phone's "large text" setting or a narrow screen can't push a button off-screen.
            CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, fontScale = 1f)) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .navigationBarsPadding().padding(start = 12.dp, end = 12.dp, bottom = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (state.phase) {
                        CallPhase.RINGING_IN -> Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                            CallRoundBtn(Ic.CallEnd, "decline", kind = BtnKind.DANGER, size = 68.dp, onClick = onDecline)
                            CallRoundBtn(if (state.video) Ic.Video else Ic.Call, "accept", kind = BtnKind.ACCEPT, size = 68.dp, onClick = onAccept)
                        }
                        CallPhase.RINGING_OUT, CallPhase.CONNECTING -> EndCallPill("cancel", onHangup)
                        CallPhase.CONNECTED -> {
                            if (state.video && showFx) FxPanel(colorFx, faceFx, bgFx, onColorFx, onFaceFx, onBgFx, onClearFx)
                            val activeFx = listOf(colorFx != VideoFx.NONE, faceFx != FaceFx.NONE, bgFx != BgFx.NONE).count { it }
                            val panel = RoundedCornerShape(26.dp)
                            Column(
                                Modifier.fillMaxWidth().clip(panel).background(Scrim).border(1.dp, Line, panel)
                                    .padding(horizontal = 6.dp, vertical = 10.dp)
                            ) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    CallRoundBtn(
                                        if (state.muted) Ic.MicOff else Ic.Mic, if (state.muted) "unmute" else "mute", Modifier.weight(1f),
                                        kind = if (state.muted) BtnKind.ACTIVE else BtnKind.NORMAL, onClick = onToggleMute
                                    )
                                    CallRoundBtn(
                                        Ic.Speaker, "speaker", Modifier.weight(1f),
                                        kind = if (state.speakerOn) BtnKind.ACTIVE else BtnKind.NORMAL, onClick = onToggleSpeaker
                                    )
                                    if (state.video) CallRoundBtn(Ic.Flip, "flip", Modifier.weight(1f), onClick = onSwitchCamera)
                                    CallRoundBtn(
                                        Ic.ScreenShare, if (state.sharingScreen) "stop" else "share", Modifier.weight(1f),
                                        kind = if (state.sharingScreen) BtnKind.ACTIVE else BtnKind.NORMAL,
                                        onClick = if (state.sharingScreen) onStopScreenShare else onStartScreenShare
                                    )
                                    if (state.video) CallRoundBtn(
                                        Ic.Effects, if (activeFx == 0) "effects" else "$activeFx on", Modifier.weight(1f),
                                        kind = if (activeFx > 0 || showFx) BtnKind.ACTIVE else BtnKind.NORMAL,
                                        onClick = { showFx = !showFx }
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                EndCallPill("end call", onHangup)
                            }
                        }
                        CallPhase.ENDED -> {}
                    }
                }
            }
        }
    }
}



/**
 * The call, minimized: a small draggable window floating over the chat (video for video calls,
 * names + timer for voice calls) with mute / end icons. Tap the window to expand back to full screen.
 * Rendered as a non-focusable Popup, so the chat underneath stays fully usable — type, scroll, send.
 */
@Composable
fun CallMiniWindow(
    state: CallUiState,
    localVideo: VideoTrack?,
    eglBaseContext: EglBase.Context,
    onExpand: () -> Unit,
    onToggleMute: () -> Unit,
    onHangup: () -> Unit,
) {
    val density = LocalDensity.current
    val cfg = LocalConfiguration.current
    val winW = 124.dp
    val winH = if (state.video) 196.dp else 92.dp
    val maxLeft = with(density) { (cfg.screenWidthDp.dp - winW - 36.dp).roundToPx() }      // how far it can be dragged left
    val maxDown = with(density) { (cfg.screenHeightDp.dp - winH - 80.dp).roundToPx() }     // ...and down
    var off by remember { mutableStateOf(IntOffset(0, with(density) { 8.dp.roundToPx() })) }
    val shape = RoundedCornerShape(12.dp)

    Popup(
        alignment = Alignment.TopEnd,
        offset = off,
        properties = PopupProperties(focusable = false)
    ) {
        Column(
            Modifier.width(winW).clip(shape).background(Bg.copy(alpha = 0.94f)).border(1.dp, Line, shape)
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        off = IntOffset(
                            (off.x + drag.x.roundToInt()).coerceIn(-maxLeft, 0),
                            (off.y + drag.y.roundToInt()).coerceIn(0, maxDown.coerceAtLeast(0))
                        )
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onTap = { onExpand() }) }
        ) {
            Box(Modifier.fillMaxWidth().height(if (state.video) 152.dp else 56.dp)) {
                val remote = state.participants.firstNotNullOfOrNull { it.videoTrack }
                val track = if (state.video) (remote ?: localVideo) else null
                if (track != null) {
                    VideoView(track, eglBaseContext, Modifier.fillMaxSize(), mirror = track === localVideo)
                }
                Column(
                    Modifier.align(if (track != null) Alignment.BottomStart else Alignment.Center).padding(6.dp),
                    horizontalAlignment = if (track != null) Alignment.Start else Alignment.CenterHorizontally
                ) {
                    val names = if (state.participants.isEmpty()) Profiles.display(state.inviterName).ifBlank { "call" }
                        else state.participants.joinToString(", ") { Profiles.display(it.name) }
                    // Over live video the text sits on a themed chip; on a plain panel it needs none.
                    val chip = if (track != null) Modifier.clip(RoundedCornerShape(5.dp)).background(Scrim).padding(horizontal = 5.dp, vertical = 1.dp) else Modifier
                    Text(names, color = Ink, fontFamily = TermFont, fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = chip)
                    Text(
                        when (state.phase) {
                            CallPhase.RINGING_OUT -> "calling…"
                            CallPhase.CONNECTING -> "connecting…"
                            CallPhase.CONNECTED -> "%d:%02d".format(state.elapsedSec / 60, state.elapsedSec % 60)
                            else -> ""
                        },
                        color = Dim, fontFamily = TermFont, fontSize = 11.sp, modifier = chip
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                if (state.phase == CallPhase.CONNECTED) {
                    IconBtn(
                        if (state.muted) Ic.MicOff else Ic.Mic, if (state.muted) "unmute" else "mute",
                        tint = if (state.muted) Accent else IconTint, box = 38.dp, glyph = 20.dp, filled = false, onClick = onToggleMute
                    )
                }
                IconBtn(Ic.CallEnd, if (state.phase == CallPhase.CONNECTED) "end call" else "cancel call", tint = Warn, box = 38.dp, glyph = 22.dp, filled = false, onClick = onHangup)
            }
        }
    }
}
