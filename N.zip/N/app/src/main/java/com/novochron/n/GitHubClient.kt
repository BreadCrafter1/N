package com.novochron.n

import android.util.Base64
import android.util.Base64OutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

data class RepoRef(val owner: String, val name: String) {
    val full: String get() = "$owner/$name"
    companion object {
        fun parse(text: String): RepoRef? {
            val cleaned = text.trim()
                .removePrefix("https://github.com/")
                .removePrefix("http://github.com/")
                .removePrefix("github.com/")
                .removeSuffix(".git")
                .removeSuffix("/")
            val parts = cleaned.split("/").filter { it.isNotBlank() }
            return if (parts.size >= 2) RepoRef(parts[0], parts[1]) else null
        }
    }
}

data class RepoFile(val path: String, val isDir: Boolean, val sha: String = "")

class GitHubApiException(val code: Int, val body: String) : IOException("GitHub API HTTP $code: $body")

private const val JSON_ACCEPT = "application/vnd.github+json"
// Raw media type: the response body IS the file (no JSON/base64 wrapper), and it works for files
// up to 100 MB — the default JSON response can't carry anything over 1 MB.
private const val RAW_ACCEPT = "application/vnd.github.raw+json"

/**
 * Thin GitHub REST client, just enough to use a repo as a shared mailbox: list a folder, read a
 * file, and commit (create) a file. Auth is a plain personal access token.
 *
 * Speed notes:
 *  - Folder listings use ETags. When nothing changed GitHub answers "304 Not Modified" with no body
 *    (and 304s don't count against the API rate limit), so polling is cheap enough to do every second.
 *  - Files are read with the raw media type (no base64 decode, no 1 MB cap) and media is streamed to
 *    disk instead of held in memory.
 *  - Uploads are streamed from disk (base64-encoded on the fly) so even very large files don't need
 *    to fit in RAM, and new files skip the "does it already exist?" lookup.
 *  - Writes are retried on 409 conflicts (two commits racing for the same branch).
 */
class GitHubClient(private val token: String, private val branch: String = "main") {

    private class CachedListing(val etag: String, val files: List<RepoFile>)
    private val listingCache = ConcurrentHashMap<String, CachedListing>()

    private class Response(val code: Int, val body: String, val etag: String?)

    suspend fun listFiles(path: String, repo: RepoRef): List<RepoFile> = withContext(Dispatchers.IO) {
        val url = contentsUrl(path, repo)
        val cached = listingCache[url]
        val res = try {
            request("GET", url, JSON_ACCEPT, etag = cached?.etag)
        } catch (e: GitHubApiException) {
            if (e.code == 404) { listingCache.remove(url); return@withContext emptyList() } else throw e
        }
        if (res.code == 304 && cached != null) return@withContext cached.files

        val body = res.body
        val files = if (body.trimStart().startsWith("[")) {
            val arr = JSONArray(body)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RepoFile(o.getString("path"), o.getString("type") == "dir", o.optString("sha", ""))
            }
        } else {
            val o = JSONObject(body)
            listOf(RepoFile(o.getString("path"), false, o.optString("sha", "")))
        }
        res.etag?.let { listingCache[url] = CachedListing(it, files) }
        files
    }

    /** Decoded text content, or null if the file doesn't exist. */
    suspend fun readFile(path: String, repo: RepoRef): String? = withContext(Dispatchers.IO) {
        try {
            request("GET", contentsUrl(path, repo), RAW_ACCEPT).body
        } catch (e: GitHubApiException) {
            if (e.code == 404) null else throw e
        }
    }

    /** Streams a file (photo/video/voice, up to 100 MB) straight to [dest]. False if it doesn't exist. */
    suspend fun downloadFile(path: String, repo: RepoRef, dest: File): Boolean = withContext(Dispatchers.IO) {
        val conn = open("GET", contentsUrl(path, repo), RAW_ACCEPT)
        conn.readTimeout = 60_000
        val code = conn.responseCode
        if (code == 404) { readBody(conn, code); return@withContext false }
        if (code !in 200..299) throw GitHubApiException(code, readBody(conn, code))
        dest.parentFile?.mkdirs()
        val tmp = File(dest.path + ".part")
        try {
            conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out, 64 * 1024) } }
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }
        } catch (e: Exception) {
            tmp.delete(); throw e
        }
        true
    }

    /** Creates a new small text file (message JSON). Path must not already exist. */
    suspend fun commitFile(path: String, content: String, message: String, repo: RepoRef): Unit =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("message", message)
                put("content", Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                put("branch", branch)
            }
            retryOnConflict { request("PUT", contentsUrl(path, repo, withRef = false), JSON_ACCEPT, body = body) }
            Unit
        }

    /**
     * Creates a new file from [source], streaming it from disk and base64-encoding on the fly, so the
     * whole file (and its ~33% larger base64 form) never sits in memory. [onProgress] gets 0..100.
     */
    suspend fun commitFileStream(
        path: String, source: File, message: String, repo: RepoRef, onProgress: ((Int) -> Unit)? = null
    ): Unit = withContext(Dispatchers.IO) {
        retryOnConflict { uploadOnce(path, source, message, repo, onProgress) }
    }

    private fun uploadOnce(path: String, source: File, message: String, repo: RepoRef, onProgress: ((Int) -> Unit)?) {
        val prefix = ("{\"message\":" + JSONObject.quote(message) + ",\"branch\":" + JSONObject.quote(branch) + ",\"content\":\"")
            .toByteArray(Charsets.UTF_8)
        val suffix = "\"}".toByteArray(Charsets.UTF_8)
        val len = source.length()
        val total = prefix.size + ((len + 2) / 3) * 4 + suffix.size   // exact size of the base64 body

        val conn = open("PUT", contentsUrl(path, repo, withRef = false), JSON_ACCEPT)
        conn.readTimeout = 180_000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setFixedLengthStreamingMode(total)

        val out = conn.outputStream
        out.write(prefix)
        val b64 = Base64OutputStream(out, Base64.NO_WRAP or Base64.NO_CLOSE)
        source.inputStream().use { input ->
            val buf = ByteArray(64 * 1024)
            var sent = 0L
            var lastPct = -1
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                b64.write(buf, 0, n)
                sent += n
                if (onProgress != null && len > 0) {
                    val pct = (sent * 100 / len).toInt()
                    if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                }
            }
        }
        b64.close()          // flushes the final base64 padding; NO_CLOSE keeps `out` open
        out.write(suffix)
        out.flush()

        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299) throw GitHubApiException(code, text)
    }

    /** Deletes one existing file in one commit. [sha] is the file's current blob sha (from [listFiles]). */
    suspend fun deleteFile(path: String, sha: String, message: String, repo: RepoRef): Unit =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("message", message)
                put("sha", sha)
                put("branch", branch)
            }
            retryOnConflict { request("DELETE", contentsUrl(path, repo, withRef = false), JSON_ACCEPT, body = body) }
            Unit
        }

    /**
     * Recursively deletes every file under [path] (walking into subfolders like Msg/media), one
     * commit per file. Used by "clear chat history" to wipe the whole Msg/ tree in the shared repo.
     */
    suspend fun deleteAll(path: String, repo: RepoRef, message: String): Unit = withContext(Dispatchers.IO) {
        for (f in listFiles(path, repo)) {
            if (f.isDir) deleteAll(f.path, repo, message) else deleteFile(f.path, f.sha, message, repo)
        }
    }

    // ---------------- plain HTTP helpers ----------------

    private suspend fun <T> retryOnConflict(block: () -> T): T {
        var attempt = 0
        while (true) {
            try { return block() } catch (e: GitHubApiException) {
                if (e.code != 409 || ++attempt >= 4) throw e
                delay(300L * attempt)
            }
        }
    }

    private fun contentsUrl(path: String, repo: RepoRef, withRef: Boolean = true): String {
        val clean = encodePath(path.trim('/'))
        val base = "https://api.github.com/repos/${repo.full}/contents/$clean"
        return if (withRef) "$base?ref=$branch" else base
    }

    private fun open(method: String, url: String, accept: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 10_000
        conn.readTimeout = 30_000
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", accept)
        conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        return conn
    }

    private fun request(method: String, url: String, accept: String, etag: String? = null, body: JSONObject? = null): Response {
        val conn = open(method, url, accept)
        if (etag != null) conn.setRequestProperty("If-None-Match", etag)
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val text = readBody(conn, code)
        if (code !in 200..299 && code != 304) throw GitHubApiException(code, text)
        return Response(code, text, conn.getHeaderField("ETag"))
    }

    private fun readBody(conn: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    private fun encodePath(path: String): String =
        path.split("/").joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
}
