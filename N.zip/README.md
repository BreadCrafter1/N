# N

A tiny Novochron-styled app: text, photo, and video messages with one other person, using a shared
GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving is
polling the same folder.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Everything shows
   up for the other person the next time their app polls (every few seconds while it's open).
3. Keep photos/videos under ~1 MB — GitHub's Contents API can't hand back the base64 body of a
   larger file, so anything bigger can be sent but won't display back in the app.

Tap `[repo]` any time to change the repo, token, or name.
