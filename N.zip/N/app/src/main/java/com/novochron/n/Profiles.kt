package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// Profiles: a nickname and a picture per person. The username (the name in Settings that messages
// are matched by) never changes; the nickname is only what's *shown*. Profiles live in the repo at
// Config/profiles/<user>.json (+ <user>-<ts>.jpg for the picture) so both phones see each other's.
// ---------------------------------------------------------------------------------------------

data class Profile(val user: String, val nick: String, val avatar: String, val updated: Long, val bubble: String = "")

object Profiles {
    const val DIR = "Config/profiles"
    val map = mutableStateMapOf<String, Profile>()
    val avatars = mutableStateMapOf<String, ImageBitmap>()
    private val shas = HashMap<String, String>()

    /** What to show for [user]: their nickname if they set one, otherwise their username. */
    fun display(user: String): String = map[user]?.nick?.takeIf { it.isNotBlank() } ?: user

    /** How [user]'s sent messages look (their chosen bubble style); classic when they never picked one. */
    fun bubbleStyle(user: String): BubbleStyle = BubbleStyle.fromKey(map[user]?.bubble ?: "")

    fun load(store: Store) {
        try {
            val arr = JSONArray(store.profilesJson.ifBlank { "[]" })
            for (i in 0 until arr.length()) parse(arr.getJSONObject(i))?.let { map[it.user] = it }
        } catch (_: Exception) {}
    }

    private fun save(store: Store) {
        val arr = JSONArray()
        map.values.forEach { arr.put(toJson(it)) }
        store.profilesJson = arr.toString()
    }

    private fun toJson(p: Profile) = JSONObject().apply {
        put("user", p.user); put("nick", p.nick); put("avatar", p.avatar); put("updated", p.updated); put("bubble", p.bubble)
    }

    private fun parse(o: JSONObject): Profile? {
        val u = o.optString("user", ""); if (u.isBlank()) return null
        return Profile(u, o.optString("nick", ""), o.optString("avatar", ""), o.optLong("updated", 0L), o.optString("bubble", ""))
    }

    private fun avatarFile(ctx: Context, path: String) = File(ctx.cacheDir, "n/avatars/" + path.substringAfterLast('/'))

    suspend fun loadAvatar(ctx: Context, client: GitHubClient?, repo: RepoRef?, p: Profile) {
        if (p.avatar.isBlank()) { avatars.remove(p.user); return }
        try {
            val f = avatarFile(ctx, p.avatar)
            if (!f.exists() || f.length() == 0L) {
                if (client == null || repo == null) return
                f.parentFile?.mkdirs()
                if (!client.downloadFile(p.avatar, repo, f)) return
            }
            val bmp = withContext(Dispatchers.IO) { decodeSampled(f, 256) }
            if (bmp != null) avatars[p.user] = bmp.asImageBitmap()
        } catch (e: Exception) { DebugLog.add("profile: avatar load failed: ${e.message?.take(60)}") }
    }

    /** Pulls in anyone's new nickname/picture from the repo. Cheap: the folder listing is ETag-cached. */
    suspend fun syncOnce(ctx: Context, store: Store, client: GitHubClient, repo: RepoRef, withAvatars: Boolean) {
        val files = client.listFiles(DIR, repo).filter { !it.isDir && it.path.endsWith(".json") }
        var changed = false
        for (f in files) {
            if (shas[f.path] == f.sha) continue
            val p = client.readFile(f.path, repo)?.let { try { parse(JSONObject(it)) } catch (_: Exception) { null } } ?: continue
            shas[f.path] = f.sha
            val cur = map[p.user]
            if (cur == null || p.updated >= cur.updated) {
                map[p.user] = p; changed = true
                if (withAvatars) loadAvatar(ctx, client, repo, p)
            }
        }
        if (changed) save(store)
    }

    /** Runs while the app is unlocked: shows cached pictures right away, then keeps profiles in step with the repo. */
    suspend fun loop(ctx: Context, store: Store, client: GitHubClient?, repo: RepoRef?) {
        // Profiles are per repo too: forget the previous repo's people before loading this one's.
        map.clear(); avatars.clear(); shas.clear()
        load(store)
        map.values.toList().forEach { loadAvatar(ctx, client, repo, it) }
        if (client == null || repo == null) return
        while (true) {
            try { syncOnce(ctx, store, client, repo, true) } catch (e: Exception) { DebugLog.add("profile sync: ${e.message?.take(60)}") }
            delay(20_000)
        }
    }

    /** Saves [nick] (and a new or removed picture) to the repo. Returns null on success or an error message. */
    suspend fun publish(
        ctx: Context, store: Store, client: GitHubClient?, repo: RepoRef?,
        nick: String, newAvatar: File?, removeAvatar: Boolean
    ): String? {
        if (client == null || repo == null) return "No repo/token configured."
        val me = store.name.ifBlank { "me" }
        val now = System.currentTimeMillis()
        val old = map[me]?.avatar ?: ""
        return try {
            var avatarPath = if (removeAvatar) "" else old
            if (newAvatar != null) {
                avatarPath = "$DIR/${safeName(me)}-$now.jpg"
                client.commitFileStream(avatarPath, newAvatar, "n: profile picture", repo)
                val cached = avatarFile(ctx, avatarPath)
                cached.parentFile?.mkdirs()
                newAvatar.copyTo(cached, overwrite = true)
            }
            val p = Profile(me, nick.trim().take(30), avatarPath, now, map[me]?.bubble ?: "")
            client.writeFile("$DIR/${safeName(me)}.json", toJson(p).toString(2), "n: profile", repo)
            map[me] = p; save(store)
            loadAvatar(ctx, client, repo, p)
            if (old.isNotBlank() && old != avatarPath) {
                try {
                    client.listFiles(DIR, repo).firstOrNull { it.path == old }
                        ?.let { client.deleteFile(it.path, it.sha, "n: remove old picture", repo) }
                } catch (_: Exception) {}
            }
            null
        } catch (e: Exception) {
            DebugLog.add("profile publish failed: ${e.message?.take(60)}")
            if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error"
        }
    }

    /**
     * Saves my chosen message-bubble style. It shows on this phone straight away, then goes to the repo
     * (inside my profile file) so the other phone picks it up. Returns null on success or an error message.
     */
    suspend fun publishBubble(store: Store, client: GitHubClient?, repo: RepoRef?, key: String): String? {
        val me = store.name.ifBlank { "me" }
        val cur = map[me]
        val p = Profile(me, cur?.nick ?: "", cur?.avatar ?: "", System.currentTimeMillis(), key)
        map[me] = p; save(store)
        if (client == null || repo == null) return "No repo/token configured."
        return try {
            client.writeFile("$DIR/${safeName(me)}.json", toJson(p).toString(2), "n: message style", repo)
            null
        } catch (e: Exception) {
            DebugLog.add("bubble style publish failed: ${e.message?.take(60)}")
            if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error"
        }
    }

    /** Centre-crops the picked image to a 256px square JPEG (honouring rotation). Null if unreadable. */
    suspend fun prepareAvatar(ctx: Context, uri: Uri): File? = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return@withContext null
            var sample = 1
            while (min(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
            var bmp: Bitmap = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@withContext null
            val rotation = try {
                ctx.contentResolver.openInputStream(uri)?.use { s ->
                    when (android.media.ExifInterface(s).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (_: Exception) { 0f }
            if (rotation != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
            val side = min(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(square, 256, 256, true)
            val f = File(ctx.cacheDir, "n/avatars/upload-${System.currentTimeMillis()}.jpg")
            f.parentFile?.mkdirs()
            FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            f
        } catch (_: Exception) { null }
    }
}

/** A round profile picture, or the first letter of their name on a plain circle when they have none. */
@Composable
fun Avatar(user: String, size: Dp) {
    val bmp = Profiles.avatars[user]
    Box(Modifier.size(size).clip(CircleShape).background(Raised), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Text(
            Profiles.display(user).take(1).uppercase(), color = Accent, fontFamily = TermFont,
            fontWeight = FontWeight.Bold, fontSize = (size.value * 0.5f).sp
        )
    }
}
