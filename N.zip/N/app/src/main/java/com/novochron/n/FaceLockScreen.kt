package com.novochron.n

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/**
 * Gate shown before the chat/repo is reachable. No button to press: as soon as camera access
 * is granted, it scans every live preview frame against FaceLock's hardcoded reference face(s)
 * and calls onUnlocked() automatically once it sees two matching frames in a row (a simple
 * debounce so one lucky/unlucky frame can't flip the result).
 */
@OptIn(ExperimentalGetImage::class)
@Composable
fun FaceLockScreen(onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var status by remember { mutableStateOf(if (hasPermission) "Scanning…" else "Requesting camera access…") }
    var unlocking by remember { mutableStateOf(false) }
    var consecutiveMatches by remember { mutableStateOf(0) }

    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
        status = if (granted) "Scanning…" else "Camera permission is required to unlock."
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) permissionLauncher.launch(Manifest.permission.CAMERA)
    }
    LaunchedEffect(hasPermission) {
        if (hasPermission) FaceLock.preload(ctx)
    }
    DisposableEffect(Unit) {
        onDispose {
            cameraProvider?.unbindAll()
            analysisExecutor.shutdown()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermission) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    val previewView = PreviewView(context)
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

                    cameraProviderFuture.addListener({
                        val provider = cameraProviderFuture.get()
                        cameraProvider = provider

                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }
                        val analysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        analysis.setAnalyzer(analysisExecutor) { imageProxy ->
                            val mediaImage = imageProxy.image
                            if (unlocking || mediaImage == null) {
                                imageProxy.close()
                            } else {
                                val input = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                scope.launch {
                                    val result = withContext(Dispatchers.Default) { FaceLock.verifyImage(ctx, input) }
                                    imageProxy.close()
                                    when (result) {
                                        is FaceLock.Result.Match -> {
                                            consecutiveMatches += 1
                                            status = "Matched (Δ${"%.3f".format(result.distance)}) — unlocking…"
                                            if (consecutiveMatches >= 3 && !unlocking) {
                                                unlocking = true
                                                provider.unbindAll()
                                                onUnlocked()
                                            }
                                        }
                                        is FaceLock.Result.NoMatch -> {
                                            consecutiveMatches = 0
                                            status = "Not recognized (Δ${"%.3f".format(result.distance)})"
                                        }
                                        is FaceLock.Result.NoFaceFound -> {
                                            consecutiveMatches = 0
                                            status = "Center your face in frame…"
                                        }
                                        is FaceLock.Result.Error -> {
                                            consecutiveMatches = 0
                                            status = "Face check error: ${result.message}"
                                        }
                                    }
                                }
                            }
                        }

                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(
                                lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis
                            )
                        } catch (e: Exception) {
                            status = "Couldn't start the camera: ${e.message}"
                        }
                    }, ContextCompat.getMainExecutor(context))

                    previewView
                }
            )
            // Dim overlay so the terminal look still reads through the live preview.
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
        }

        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(8.dp))
                Text("N", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                Spacer(Modifier.height(6.dp))
                Text("locked", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(status, color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Hands-free — just look at the camera. On-device only, nothing leaves your phone.",
                    color = Dim, fontFamily = TermFont, fontSize = 10.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Calibrating: the Δ number is how far off the current face is. Note your own " +
                        "lowest Δ and a stranger's lowest Δ, then set MATCH_THRESHOLD in FaceLock.kt " +
                        "to something between the two (closer to your number). Remove this line once it's tuned.",
                    color = Dim, fontFamily = TermFont, fontSize = 9.sp
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
