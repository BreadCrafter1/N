package com.novochron.n

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.projection.MediaProjection
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RendererCommon
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.ScreenCapturerAndroid
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack
import java.util.UUID
import kotlin.coroutines.resumeWithException

// ---------------------------------------------------------------------------------------------
// Calling, over the same "shared repo as mailbox" trick the chat uses. Up to MAX_PARTICIPANTS
// people can be in one call at a time, connected mesh-style (every phone holds one WebRTC
// PeerConnection to every other phone — fine at 3 people, would not scale much past that).
//
// Signaling lives in a Call/ folder:
//   Call/room.json                              - who's in the current call (the "roster")
//   Call/offer-<callId>-<from>-<to>.json         - an SDP offer from one phone to another
//   Call/answer-<callId>-<from>-<to>.json        - the SDP answer back
//   Call/leave-<callId>-<name>.json              - "I'm leaving this call"
// Each SDP already has its ICE candidates baked in (non-trickle ICE), which suits polling far
// better than classic trickle ICE would. When someone joins a call already in progress, they
// send a fresh offer to everyone already in the room; the same offer/answer files are also
// reused later for renegotiation (e.g. adding a screenshare track), since a PeerConnection can
// go through more than one offer/answer round.
//
// Known limits: STUN alone can't get through every kind of NAT (a small fraction of networks
// need a TURN relay instead — add one to iceServers() below if that turns out to matter). Calls
// only work while the app is open in the foreground, since there's no push notification to wake
// it up for an incoming call.
// ---------------------------------------------------------------------------------------------

private const val CALL_DIR = "Call"
const val CALL_POLL_MS = 1000L
private const val RING_TIMEOUT_MS = 45_000L      // give up ringing after this long
private const val ICE_GATHER_TIMEOUT_MS = 8_000L  // cap on waiting for STUN candidates before sending anyway
const val MAX_CALL_PARTICIPANTS = 3

enum class CallPhase { RINGING_OUT, RINGING_IN, CONNECTING, CONNECTED, ENDED }

/**
 * Mirrors just enough of the live call state to be readable from the Activity, which is where
 * Picture-in-Picture has to be entered from (onUserLeaveHint) — CallManager itself lives deep in
 * the Compose tree (inside ChatBody), too deep for the Activity to reach directly.
 */
object CallPip {
    var active by mutableStateOf(false)   // true while a call is actually connected (worth shrinking to a window)
    var video by mutableStateOf(false)    // decides the window's aspect ratio
    var inPip by mutableStateOf(false)    // set by the Activity once PiP mode is actually entered/exited
}

/** One other person in the call: their camera track (if any) and their screenshare track (if any). */
data class ParticipantState(
    val name: String,
    val videoTrack: VideoTrack? = null,
    val screenTrack: VideoTrack? = null,
    val connected: Boolean = false,
)

data class CallUiState(
    val callId: String,
    val video: Boolean,
    val phase: CallPhase,
    val inviterName: String = "",   // who started the call, shown while it's ringing in
    val note: String = "",
    val muted: Boolean = false,
    val speakerOn: Boolean = false,
    val elapsedSec: Int = 0,
    val participants: List<ParticipantState> = emptyList(),
    val sharingScreen: Boolean = false,
)

/** Turns a display name into something safe to put in a filename. Lossy, but fine for 3 people. */
private fun safeName(name: String): String =
    name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "x" }

private fun roomFile() = "$CALL_DIR/room.json"
private fun offerFile(callId: String, from: String, to: String) = "$CALL_DIR/offer-$callId-${safeName(from)}-${safeName(to)}.json"
private fun answerFile(callId: String, from: String, to: String) = "$CALL_DIR/answer-$callId-${safeName(from)}-${safeName(to)}.json"
private fun leaveFile(callId: String, name: String) = "$CALL_DIR/leave-$callId-${safeName(name)}.json"

/** The WebRTC PeerConnectionFactory + shared EglBase, created once per process and reused across calls. */
private object Rtc {
    @Volatile private var initialized = false
    lateinit var eglBase: EglBase; private set
    lateinit var factory: PeerConnectionFactory; private set

    @Synchronized
    fun ensure(ctx: Context) {
        if (initialized) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        eglBase = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase.eglBaseContext))
            .createPeerConnectionFactory()
        initialized = true
    }
}

private abstract class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
}

/**
 * This device's own mic + camera, captured once per call and shared across every peer connection
 * in that call (one camera session, not one per person we're talking to).
 */
private class LocalMedia(context: Context) {
    val audioTrack: AudioTrack
    var videoTrack: VideoTrack? = null; private set
    private var capturer: CameraVideoCapturer? = null
    private var surfaceHelper: SurfaceTextureHelper? = null

    init {
        Rtc.ensure(context)
        val source = Rtc.factory.createAudioSource(MediaConstraints())
        audioTrack = Rtc.factory.createAudioTrack("n-audio-${UUID.randomUUID()}", source)
    }

    fun startCamera(context: Context) {
        if (videoTrack != null) return
        val enumerator = Camera2Enumerator(context)
        val name = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) } ?: enumerator.deviceNames.firstOrNull()
        val cap = name?.let { enumerator.createCapturer(it, null) } ?: return
        val helper = SurfaceTextureHelper.create("n-capture", Rtc.eglBase.eglBaseContext)
        val source = Rtc.factory.createVideoSource(false)
        cap.initialize(helper, context, source.capturerObserver)
        cap.startCapture(1280, 720, 30)
        videoTrack = Rtc.factory.createVideoTrack("n-video-${UUID.randomUUID()}", source)
        capturer = cap; surfaceHelper = helper
    }

    fun setMuted(muted: Boolean) { audioTrack.setEnabled(!muted) }
    fun switchCamera() { capturer?.switchCamera(null) }

    fun close() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        capturer?.dispose(); surfaceHelper?.dispose(); videoTrack?.dispose(); audioTrack.dispose()
        capturer = null; surfaceHelper = null; videoTrack = null
    }
}

/** One call's WebRTC plumbing: the peer connection to a single other person. */
private class CallEngine(
    context: Context,
    private val onRemoteVideo: (VideoTrack?) -> Unit,
    private val onIceState: (PeerConnection.IceConnectionState) -> Unit,
) {
    private var pc: PeerConnection? = null
    init { Rtc.ensure(context) }

    private fun iceServers() = listOf(
        // Google's public STUN servers: free, no auth, just tell each phone its public address/port
        // so ICE can find a peer-to-peer path through most home/office NATs.
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
    )

    fun open(audioTrack: AudioTrack, videoTrack: VideoTrack?) {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_ONCE
        }
        pc = Rtc.factory.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) { onIceState(state) }
            override fun onTrack(transceiver: RtpTransceiver?) {
                (transceiver?.receiver?.track() as? VideoTrack)?.let(onRemoteVideo)
            }
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(p0: IceCandidate?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })
        pc?.addTrack(audioTrack, listOf("n-stream"))
        videoTrack?.let { pc?.addTrack(it, listOf("n-stream")) }
    }

    /** Adds an extra video track (the screenshare) to this one peer connection. Needs a fresh offer/answer after. */
    fun addExtraVideoTrack(track: VideoTrack) { pc?.addTrack(track, listOf("n-stream")) }

    /** Removes a previously-added track (by track id) from this peer connection. Also needs renegotiation after. */
    fun removeVideoTrackById(id: String) {
        pc?.senders?.firstOrNull { it.track()?.id() == id }?.let { pc?.removeTrack(it) }
    }

    /** Creates an offer, waits (briefly) for STUN candidates, and returns the SDP with them baked in. */
    suspend fun makeOffer(): SessionDescription = withContext(Dispatchers.Main) {
        val peer = pc ?: error("no peer connection")
        val created = suspendCancellableCoroutine<SessionDescription> { cont ->
            peer.createOffer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 != null) cont.resume(p0, null) else cont.resumeWithException(IllegalStateException("null offer"))
                }
                override fun onCreateFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "createOffer failed")) }
            }, MediaConstraints())
        }
        setLocalAndWaitForIce(created)
    }

    /** Sets the remote offer, creates an answer, waits for STUN candidates, and returns the answer SDP. */
    suspend fun makeAnswer(remoteOffer: SessionDescription): SessionDescription = withContext(Dispatchers.Main) {
        val peer = pc ?: error("no peer connection")
        setRemote(remoteOffer)
        val created = suspendCancellableCoroutine<SessionDescription> { cont ->
            peer.createAnswer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 != null) cont.resume(p0, null) else cont.resumeWithException(IllegalStateException("null answer"))
                }
                override fun onCreateFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "createAnswer failed")) }
            }, MediaConstraints())
        }
        setLocalAndWaitForIce(created)
    }

    suspend fun setRemoteAnswer(sdp: SessionDescription) = withContext(Dispatchers.Main) { setRemote(sdp) }

    private suspend fun setRemote(sdp: SessionDescription) {
        val peer = pc ?: error("no peer connection")
        suspendCancellableCoroutine<Unit> { cont ->
            peer.setRemoteDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() { cont.resume(Unit, null) }
                override fun onSetFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "setRemoteDescription failed")) }
            }, sdp)
        }
    }

    private suspend fun setLocalAndWaitForIce(sdp: SessionDescription): SessionDescription {
        val peer = pc ?: error("no peer connection")
        suspendCancellableCoroutine<Unit> { cont ->
            peer.setLocalDescription(object : SimpleSdpObserver() {
                override fun onSetSuccess() { cont.resume(Unit, null) }
                override fun onSetFailure(p0: String?) { cont.resumeWithException(IllegalStateException(p0 ?: "setLocalDescription failed")) }
            }, sdp)
        }
        withTimeoutOrNull(ICE_GATHER_TIMEOUT_MS) {
            while (peer.iceGatheringState() != PeerConnection.IceGatheringState.COMPLETE) delay(150)
        }
        return peer.localDescription ?: sdp
    }

    fun close() { pc?.close(); pc?.dispose(); pc = null }
}

/**
 * Drives one call end-to-end for up to [MAX_CALL_PARTICIPANTS] people: placing/receiving/joining
 * it, the SDP handshakes over the shared repo (see the file header above), and the live
 * [CallUiState] the UI renders. One instance lives as long as the chat screen does, polling the
 * repo's Call/ folder the same way messages get polled.
 */
class CallManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val client: GitHubClient?,
    private val repo: RepoRef?,
    private val store: Store,
) {
    private var _ui by mutableStateOf<CallUiState?>(null)
    /** Setting this also mirrors phase/video into [CallPip], which the Activity reads to decide
     *  whether onUserLeaveHint() should shrink the call into a Picture-in-Picture window. */
    var ui: CallUiState?
        get() = _ui
        private set(value) {
            _ui = value
            CallPip.active = value?.phase == CallPhase.CONNECTED
            CallPip.video = value?.video ?: false
        }
    var localVideo by mutableStateOf<VideoTrack?>(null); private set
    var localScreenTrack by mutableStateOf<VideoTrack?>(null); private set
    val eglBaseContext: EglBase.Context get() { Rtc.ensure(context); return Rtc.eglBase.eglBaseContext }

    private fun myName() = store.name.ifBlank { "me" }

    private val audioManager: AudioManager? by lazy { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    private var savedAudioMode = AudioManager.MODE_NORMAL
    private var savedSpeakerOn = false

    private fun applySpeaker(on: Boolean) {
        val am = audioManager ?: return
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = on
    }

    fun toggleSpeaker() {
        val st = ui ?: return
        val on = !st.speakerOn
        applySpeaker(on)
        ui = st.copy(speakerOn = on)
    }

    private fun startAudioRouting(defaultSpeaker: Boolean) {
        val am = audioManager ?: return
        savedAudioMode = am.mode
        savedSpeakerOn = am.isSpeakerphoneOn
        applySpeaker(defaultSpeaker)
    }

    private fun stopAudioRouting() {
        val am = audioManager ?: return
        am.isSpeakerphoneOn = savedSpeakerOn
        am.mode = savedAudioMode
    }

    /** Keeps the mic (and camera, for video) alive and the process at foreground priority for as
     *  long as a call is active, so leaving the app doesn't end it. See CallService for why. */
    private fun startCallService(video: Boolean) {
        ContextCompat.startForegroundService(context, Intent(context, CallService::class.java).putExtra("video", video))
    }
    private fun stopCallService() { context.stopService(Intent(context, CallService::class.java)) }

    private var localMedia: LocalMedia? = null
    private val engines = mutableMapOf<String, CallEngine>()   // peer name -> their peer connection
    private var timerJob: Job? = null
    private val seenShas = mutableMapOf<String, String>()      // Call/ file path -> last-seen sha
    private var primed = false
    private var myCallId: String? = null
    private var roomParticipants: List<String> = emptyList()   // last roster we know of (includes me once joined)
    private val dismissedCallIds = mutableSetOf<String>()      // calls we declined, missed, or already left

    // ---- screenshare capture bits ----
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var screenHelper: SurfaceTextureHelper? = null

    fun startCall(video: Boolean) {
        if (ui != null) return
        val c = client ?: return; val r = repo ?: return
        val callId = UUID.randomUUID().toString().take(8)
        myCallId = callId; roomParticipants = listOf(myName())
        startAudioRouting(defaultSpeaker = video)
        ui = CallUiState(callId, video = video, phase = CallPhase.RINGING_OUT, speakerOn = video)
        scope.launch {
            try {
                startCallService(video)
                localMedia = LocalMedia(context).also { if (video) it.startCamera(context) }
                localVideo = localMedia?.videoTrack
                val body = JSONObject().apply {
                    put("callId", callId); put("initiator", myName()); put("ts", System.currentTimeMillis())
                    put("video", video); put("participants", JSONArray(listOf(myName())))
                }
                withContext(Dispatchers.IO) { c.writeFile(roomFile(), body.toString(), "n: start call", r) }
                DebugLog.add("call: started ($callId)")
            } catch (e: Exception) { DebugLog.add("call: failed to start: ${e.message?.take(60)}"); endLocally() }
        }
        scope.launch {
            delay(RING_TIMEOUT_MS)
            val st = ui
            if (st != null && st.callId == callId && st.participants.isEmpty()) {
                ui = st.copy(phase = CallPhase.ENDED, note = "No answer")
                delay(1200); endLocally()
            }
        }
    }

    /** Accept an incoming ring, or join a call already in progress that we're currently shown as ringing for. */
    fun accept() {
        val st = ui ?: return
        val c = client ?: return; val r = repo ?: return
        val myN = myName()
        val existing = roomParticipants.filter { it != myN }
        startAudioRouting(defaultSpeaker = st.video)
        ui = st.copy(phase = CallPhase.CONNECTING, speakerOn = st.video)
        scope.launch {
            try {
                startCallService(st.video)
                localMedia = LocalMedia(context).also { if (st.video) it.startCamera(context) }
                localVideo = localMedia?.videoTrack
                for (peer in existing) connectTo(peer, st.callId, st.video)
                val newRoster = (roomParticipants + myN).distinct()
                roomParticipants = newRoster
                val body = JSONObject().apply {
                    put("callId", st.callId); put("initiator", st.inviterName); put("ts", System.currentTimeMillis())
                    put("video", st.video); put("participants", JSONArray(newRoster))
                }
                withContext(Dispatchers.IO) { c.writeFile(roomFile(), body.toString(), "n: join call", r) }
                startTimer()
                if (existing.isEmpty()) ui = ui?.copy(phase = CallPhase.CONNECTED)
            } catch (e: Exception) { DebugLog.add("call: failed to join: ${e.message?.take(60)}"); endLocally() }
        }
    }

    private suspend fun connectTo(peer: String, callId: String, video: Boolean) {
        val c = client ?: return; val r = repo ?: return
        if (engines.containsKey(peer)) return
        val lm = localMedia ?: return
        val eng = CallEngine(context, onRemoteVideo = { track -> onRemoteTrack(peer, track) }, onIceState = { s -> onIce(peer, s) })
        eng.open(lm.audioTrack, lm.videoTrack)
        localScreenTrack?.let { eng.addExtraVideoTrack(it) }
        engines[peer] = eng
        updateParticipant(peer) { it }
        val offer = eng.makeOffer()
        val body = JSONObject().apply {
            put("callId", callId); put("from", myName()); put("to", peer); put("video", video); put("sdp", offer.description)
        }
        withContext(Dispatchers.IO) { c.writeFile(offerFile(callId, myName(), peer), body.toString(), "n: call offer", r) }
    }

    fun decline() {
        val st = ui ?: return
        dismissedCallIds += st.callId
        endLocally()
    }

    fun hangup() {
        val st = ui
        val c = client; val r = repo
        if (st != null) {
            dismissedCallIds += st.callId
            if (c != null && r != null) {
                scope.launch {
                    try {
                        val body = JSONObject().apply { put("callId", st.callId); put("from", myName()) }
                        withContext(Dispatchers.IO) { c.writeFile(leaveFile(st.callId, myName()), body.toString(), "n: leave call", r) }
                    } catch (_: Exception) {}
                }
            }
        }
        endLocally()
    }

    fun toggleMute() {
        val st = ui ?: return
        val m = !st.muted
        localMedia?.setMuted(m)
        ui = st.copy(muted = m)
    }

    fun switchCamera() { localMedia?.switchCamera() }

    // ---- screenshare ----

    /** [resultData] is the Intent returned by MediaProjectionManager's screen-capture consent dialog. */
    fun startScreenShare(resultData: Intent) {
        if (localScreenTrack != null) return
        val callId = myCallId ?: return
        ContextCompat.startForegroundService(context, Intent(context, ScreenShareService::class.java))
        scope.launch {
            try {
                delay(250) // give the foreground service a beat to call startForeground() first
                Rtc.ensure(context)
                val source = Rtc.factory.createVideoSource(true) // isScreencast
                val helper = SurfaceTextureHelper.create("n-screen-capture", Rtc.eglBase.eglBaseContext)
                val capturer = ScreenCapturerAndroid(resultData, object : MediaProjection.Callback() {
                    override fun onStop() { scope.launch { stopScreenShare() } }
                })
                capturer.initialize(helper, context, source.capturerObserver)
                capturer.startCapture(1280, 720, 30)
                val track = Rtc.factory.createVideoTrack("n-screen-${UUID.randomUUID()}", source)
                screenCapturer = capturer; screenHelper = helper; localScreenTrack = track
                engines.values.forEach { it.addExtraVideoTrack(track) }
                renegotiateAll(callId)
                ui = ui?.copy(sharingScreen = true)
                DebugLog.add("screenshare: started")
            } catch (e: Exception) {
                DebugLog.add("screenshare: failed to start: ${e.message?.take(60)}")
                stopScreenShare()
            }
        }
    }

    fun stopScreenShare() {
        val track = localScreenTrack ?: return
        val callId = myCallId
        engines.values.forEach { eng -> eng.removeVideoTrackById(track.id()) }
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        screenCapturer?.dispose(); screenHelper?.dispose(); track.dispose()
        screenCapturer = null; screenHelper = null; localScreenTrack = null
        context.stopService(Intent(context, ScreenShareService::class.java))
        ui = ui?.copy(sharingScreen = false)
        if (callId != null) scope.launch { renegotiateAll(callId) }
        DebugLog.add("screenshare: stopped")
    }

    /** Re-runs the offer/answer handshake with everyone already in the call (used after adding/removing a track). */
    private suspend fun renegotiateAll(callId: String) {
        val c = client ?: return; val r = repo ?: return
        for ((peer, eng) in engines.toMap()) {
            try {
                val offer = eng.makeOffer()
                val body = JSONObject().apply {
                    put("callId", callId); put("from", myName()); put("to", peer); put("video", true); put("sdp", offer.description)
                }
                withContext(Dispatchers.IO) { c.writeFile(offerFile(callId, myName(), peer), body.toString(), "n: renegotiate", r) }
            } catch (e: Exception) { DebugLog.add("call: renegotiate with $peer failed: ${e.message?.take(60)}") }
        }
    }

    // ---- incoming signaling ----

    private fun onRemoteTrack(peer: String, track: VideoTrack?) {
        val isScreen = track?.id()?.startsWith("n-screen-") == true
        updateParticipant(peer) { if (isScreen) it.copy(screenTrack = track) else it.copy(videoTrack = track) }
    }

    private fun onIce(peer: String, state: PeerConnection.IceConnectionState) {
        when (state) {
            PeerConnection.IceConnectionState.CONNECTED, PeerConnection.IceConnectionState.COMPLETED -> {
                updateParticipant(peer) { it.copy(connected = true) }
                val st = ui
                if (st != null && st.phase != CallPhase.CONNECTED) { ui = st.copy(phase = CallPhase.CONNECTED, note = ""); startTimer() }
            }
            PeerConnection.IceConnectionState.FAILED -> { DebugLog.add("call: $peer connection failed"); dropPeer(peer, "$peer disconnected") }
            PeerConnection.IceConnectionState.DISCONNECTED -> updateParticipant(peer) { it.copy(connected = false) }
            else -> {}
        }
    }

    private fun updateParticipant(name: String, transform: (ParticipantState) -> ParticipantState) {
        val st = ui ?: return
        val list = st.participants.toMutableList()
        val idx = list.indexOfFirst { it.name == name }
        if (idx >= 0) list[idx] = transform(list[idx]) else list += transform(ParticipantState(name))
        ui = st.copy(participants = list)
    }

    private fun dropPeer(name: String, note: String) {
        engines.remove(name)?.close()
        roomParticipants = roomParticipants.filter { it != name }
        val st = ui ?: return
        val remaining = st.participants.filter { it.name != name }
        if (remaining.isEmpty() && (st.phase == CallPhase.CONNECTED || st.phase == CallPhase.CONNECTING)) {
            ui = st.copy(participants = remaining, note = note)
            scope.launch { delay(1200); endLocally() }
        } else {
            ui = st.copy(participants = remaining, note = note)
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch { while (true) { delay(1000); ui = ui?.let { it.copy(elapsedSec = it.elapsedSec + 1) } } }
    }

    private fun endLocally() {
        timerJob?.cancel(); timerJob = null
        engines.values.forEach { it.close() }; engines.clear()
        if (localScreenTrack != null) stopScreenShare()
        localMedia?.close(); localMedia = null
        stopAudioRouting()
        stopCallService()
        localVideo = null; myCallId = null; roomParticipants = emptyList()
        ui = null
    }

    /** Call from a ~1s loop — piggybacks the same repo-polling pattern the chat already uses. */
    suspend fun poll() {
        val c = client ?: return; val r = repo ?: return
        val files = try { c.listFiles(CALL_DIR, r) } catch (e: Exception) { return }

        if (!primed) {
            // Don't replay whatever's already sitting in Call/ from a previous session.
            for (f in files) seenShas[f.path] = f.sha
            primed = true
            return
        }
        for (f in files) {
            if (f.isDir) continue
            val prev = seenShas[f.path]
            if (prev == f.sha) continue
            seenShas[f.path] = f.sha
            val leaf = f.path.substringAfterLast('/')
            val body = try { c.readFile(f.path, r) } catch (_: Exception) { null } ?: continue
            when {
                leaf == "room.json" -> handleRoom(body)
                leaf.startsWith("offer-") -> handleOfferFile(body)
                leaf.startsWith("answer-") -> handleAnswerFile(body)
                leaf.startsWith("leave-") -> handleLeaveFile(body)
            }
        }
    }

    private fun handleRoom(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); if (callId.isBlank()) return
        val initiator = o.optString("initiator", "")
        val video = o.optBoolean("video", false)
        val ts = o.optLong("ts", 0L)
        val arr = o.optJSONArray("participants")
        val participants = if (arr != null) (0 until arr.length()).map { arr.getString(it) } else emptyList()

        if (myCallId == callId) { roomParticipants = participants; return }   // just a roster refresh
        if (callId in dismissedCallIds) return
        if (initiator == myName()) return   // my own room write coming back around
        if (ui != null) return              // already busy with a different call
        if (System.currentTimeMillis() - ts > RING_TIMEOUT_MS) { dismissedCallIds += callId; return }
        if (participants.size >= MAX_CALL_PARTICIPANTS) { dismissedCallIds += callId; return }

        myCallId = callId
        roomParticipants = participants
        ui = CallUiState(callId, video = video, phase = CallPhase.RINGING_IN, inviterName = initiator)
        scope.launch {
            delay(RING_TIMEOUT_MS)
            val st = ui
            if (st != null && st.callId == callId && st.phase == CallPhase.RINGING_IN) { dismissedCallIds += callId; endLocally() }
        }
    }

    private fun handleOfferFile(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val from = o.optString("from", ""); val to = o.optString("to", "")
        if (callId.isBlank() || from.isBlank() || to != myName()) return
        if (myCallId != callId) return
        val sdp = o.optString("sdp", ""); if (sdp.isBlank()) return
        val video = o.optBoolean("video", false)
        scope.launch {
            val existingEngine = engines[from]
            if (existingEngine != null) {
                // Renegotiation on an already-open connection (e.g. peer added their screenshare).
                try {
                    val answer = existingEngine.makeAnswer(SessionDescription(SessionDescription.Type.OFFER, sdp))
                    sendAnswer(callId, from, answer)
                } catch (e: Exception) { DebugLog.add("call: renegotiate answer to $from failed: ${e.message?.take(60)}") }
                return@launch
            }
            // First time hearing from this peer: either they're the initiator (I just accepted and
            // haven't heard back yet) or they're joining a call I'm already in.
            val lm = localMedia
            if (myCallId == null || lm == null) return@launch
            try {
                val eng = CallEngine(context, onRemoteVideo = { t -> onRemoteTrack(from, t) }, onIceState = { s -> onIce(from, s) })
                eng.open(lm.audioTrack, lm.videoTrack)
                localScreenTrack?.let { eng.addExtraVideoTrack(it) }
                engines[from] = eng
                updateParticipant(from) { it }
                if (!roomParticipants.contains(from)) roomParticipants = roomParticipants + from
                val answer = eng.makeAnswer(SessionDescription(SessionDescription.Type.OFFER, sdp))
                sendAnswer(callId, from, answer)
                val st = ui
                if (st != null && st.phase == CallPhase.RINGING_IN) ui = st.copy(phase = CallPhase.CONNECTING)
            } catch (e: Exception) { DebugLog.add("call: failed to answer $from: ${e.message?.take(60)}") }
        }
    }

    private suspend fun sendAnswer(callId: String, to: String, answer: SessionDescription) {
        val c = client ?: return; val r = repo ?: return
        val body = JSONObject().apply {
            put("callId", callId); put("from", myName()); put("to", to); put("sdp", answer.description)
        }
        withContext(Dispatchers.IO) { c.writeFile(answerFile(callId, myName(), to), body.toString(), "n: call answer", r) }
    }

    private fun handleAnswerFile(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val from = o.optString("from", ""); val to = o.optString("to", "")
        if (to != myName() || myCallId != callId) return
        val sdp = o.optString("sdp", ""); if (sdp.isBlank()) return
        val eng = engines[from] ?: return
        scope.launch {
            try { eng.setRemoteAnswer(SessionDescription(SessionDescription.Type.ANSWER, sdp)) }
            catch (e: Exception) { DebugLog.add("call: bad answer from $from: ${e.message?.take(60)}") }
        }
    }

    private fun handleLeaveFile(body: String) {
        val o = try { JSONObject(body) } catch (_: Exception) { return }
        val callId = o.optString("callId", ""); val name = o.optString("from", "")
        if (myCallId != callId || name.isBlank() || name == myName()) return
        dropPeer(name, "$name left")
    }

    fun dispose() {
        timerJob?.cancel(); engines.values.forEach { it.close() }; localMedia?.close(); stopCallService()
        CallPip.active = false
    }
}

// ---------------- UI ----------------

@Composable
private fun VideoView(track: VideoTrack?, eglBaseContext: EglBase.Context, modifier: Modifier = Modifier, mirror: Boolean = false) {
    val ctx = LocalContext.current
    val renderer = remember {
        SurfaceViewRenderer(ctx).apply {
            init(eglBaseContext, null)
            setMirror(mirror)
            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
        }
    }
    DisposableEffect(track) {
        track?.addSink(renderer)
        onDispose { track?.removeSink(renderer) }
    }
    DisposableEffect(Unit) { onDispose { renderer.release() } }
    AndroidView(factory = { renderer }, modifier = modifier)
}

@Composable
private fun CallButton(label: String, color: Color, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text(label, color = color, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

/** Compact view shown while the call is shrunk into a Picture-in-Picture window: just the video
 *  (remote if there is one, else my own preview) or, for a voice call, the name and timer. No
 *  buttons — the PiP window is too small to tap reliably; tapping it re-opens the full app. */
@Composable
fun CallPipView(state: CallUiState, localVideo: VideoTrack?, eglBaseContext: EglBase.Context) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        val remote = state.participants.firstNotNullOfOrNull { it.videoTrack }
        val track = remote ?: localVideo.takeIf { state.video }
        if (track != null) {
            VideoView(track, eglBaseContext, Modifier.fillMaxSize(), mirror = track === localVideo)
        } else {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                val names = (listOf("me") + state.participants.map { it.name }).joinToString(", ")
                Text(names, color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text("%d:%02d".format(state.elapsedSec / 60, state.elapsedSec % 60), color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
    }
}

/** Full-screen call UI: ringing (either direction), connecting, and the live call itself — for up to 3 people. */
@Composable
fun CallOverlay(
    state: CallUiState,
    localVideo: VideoTrack?,
    localScreenTrack: VideoTrack?,
    eglBaseContext: EglBase.Context,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
    onHangup: () -> Unit,
    onToggleMute: () -> Unit,
    onSwitchCamera: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onStartScreenShare: () -> Unit,
    onStopScreenShare: () -> Unit,
) {
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }

    Dialog(
        onDismissRequest = { if (state.phase != CallPhase.RINGING_IN) onHangup() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val live = state.phase == CallPhase.CONNECTING || state.phase == CallPhase.CONNECTED
            // A screenshare (mine or someone else's) takes over the main area when present.
            val remoteScreen = state.participants.firstNotNullOfOrNull { it.screenTrack }
            val screenToShow = remoteScreen ?: localScreenTrack.takeIf { state.sharingScreen }

            if (live && screenToShow != null) {
                VideoView(screenToShow, eglBaseContext, Modifier.fillMaxSize())
                // Camera thumbnails (everyone's, including mine) in a strip along the top.
                Row(
                    Modifier.align(Alignment.TopCenter).padding(top = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (state.video) VideoView(localVideo, eglBaseContext, mirror = true, modifier = Modifier.size(70.dp, 96.dp).clip(RoundedCornerShape(8.dp)))
                    if (state.video) state.participants.forEach { p ->
                        VideoView(p.videoTrack, eglBaseContext, modifier = Modifier.size(70.dp, 96.dp).clip(RoundedCornerShape(8.dp)))
                    }
                }
            } else if (live && state.video) {
                // Camera tiles for everyone else, split evenly; my own preview floats top-right.
                Row(Modifier.fillMaxSize()) {
                    val others = state.participants
                    if (others.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxHeight())
                    } else {
                        others.forEach { p ->
                            Box(Modifier.weight(1f).fillMaxHeight()) {
                                VideoView(p.videoTrack, eglBaseContext, modifier = Modifier.fillMaxSize())
                                Text(
                                    p.name, color = Ink, fontFamily = TermFont, fontSize = 12.sp,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)
                                )
                            }
                        }
                    }
                }
                VideoView(
                    localVideo, eglBaseContext, mirror = true,
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).size(90.dp, 120.dp).clip(RoundedCornerShape(8.dp))
                )
            }

            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (!(live && state.video)) {
                    val names = when (state.phase) {
                        CallPhase.RINGING_IN -> state.inviterName
                        else -> (listOf("me") + state.participants.map { it.name }).joinToString(", ")
                    }
                    Text(names, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when (state.phase) {
                            CallPhase.RINGING_OUT -> "calling…"
                            CallPhase.RINGING_IN -> if (state.video) "incoming video call…" else "incoming call…"
                            CallPhase.CONNECTING -> "connecting…"
                            CallPhase.CONNECTED -> "%d:%02d".format(state.elapsedSec / 60, state.elapsedSec % 60)
                            CallPhase.ENDED -> state.note.ifBlank { "call ended" }
                        },
                        color = Dim, fontFamily = TermFont, fontSize = 14.sp
                    )
                    if (state.note.isNotBlank() && state.phase != CallPhase.ENDED) {
                        Spacer(Modifier.height(4.dp))
                        Text(state.note, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                    }
                }
            }
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                when (state.phase) {
                    CallPhase.RINGING_IN -> { CallButton("[decline]", Warn, onDecline); CallButton("[accept]", Accent, onAccept) }
                    CallPhase.RINGING_OUT, CallPhase.CONNECTING -> CallButton("[cancel]", Warn, onHangup)
                    CallPhase.CONNECTED -> {
                        CallButton(if (state.muted) "[unmute]" else "[mute]", Ink, onToggleMute)
                        CallButton(if (state.speakerOn) "[speaker: on]" else "[speaker]", if (state.speakerOn) Accent else Ink, onToggleSpeaker)
                        if (state.video) CallButton("[flip]", Ink, onSwitchCamera)
                        CallButton(
                            if (state.sharingScreen) "[stop share]" else "[share]",
                            if (state.sharingScreen) Accent else Ink,
                            if (state.sharingScreen) onStopScreenShare else onStartScreenShare
                        )
                        CallButton("[end]", Warn, onHangup)
                    }
                    CallPhase.ENDED -> {}
                }
            }
        }
    }
}

