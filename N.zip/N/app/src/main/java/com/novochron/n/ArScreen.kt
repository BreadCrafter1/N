package com.novochron.n

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.roundToInt

// How far out signs are still shown — keeps the view from filling up with things across town.
private const val AR_VISIBLE_RADIUS_M = 5.0
// New signs are dropped a little way ahead of you (in the direction you're facing when you write
// one), not exactly on top of you — a sign sitting right at your own coordinates has no stable
// bearing to point at. Kept comfortably inside AR_VISIBLE_RADIUS_M so a freshly placed sign is
// still visible to you right after you place it.
private const val AR_PLACE_AHEAD_M = 4.0
private const val AR_POLL_MS = 4000L
private const val DEFAULT_FOV_H = 62.0
private const val DEFAULT_FOV_V = 45.0
// How many degrees past the frame edge a sign takes to fade to fully invisible. Signs stay
// mounted the whole time they're within AR_VISIBLE_RADIUS_M — this only controls the fade curve,
// not whether they're loaded.
private const val AR_EDGE_FADE_DEG = 18.0
// Exponential-smoothing factor for the raw accelerometer/magnetometer readings, 0..1 — lower is
// smoother but laggier. 0.15 is enough to kill visible shake without making the overlay feel sluggish.
private const val SENSOR_SMOOTHING = 0.15f
// How far off a viewer can stand from a sign's locked facing direction before its back — dimmer,
// mirror-imaged by the 3D flip itself — starts reading as clearly "the back" rather than "the front".
private const val AR_BACK_DIM = 0.55f
// Perspective-style size falloff: full size right up close, shrinking as you back away, maxing
// out its effect by this distance — past it, size stays pinned at AR_SIZE_MIN_SCALE rather than
// continuing to shrink (the opacity fade over AR_VISIBLE_RADIUS_M below still handles signs that
// are genuinely far away).
private const val AR_SIZE_MAX_DISTANCE_M = 5.0
private const val AR_SIZE_MAX_SCALE = 1.4f
private const val AR_SIZE_MIN_SCALE = 0.5f
// GPS accuracy (meters) good enough to stop sampling early when placing a sign.
private const val AR_GOOD_ACCURACY_M = 6f
// Max time spent sampling GPS fixes when placing a sign, picking the best (most accurate) one seen.
// Indoors, GPS often never reaches AR_GOOD_ACCURACY_M — walls/roof block or reflect the satellite
// signal — so this window also bounds how long we'll wait hoping for a better fix before settling
// for whatever's best so far.
private const val AR_FIX_TIMEOUT_MS = 8000L
// Above this accuracy, a fix is "rough": still usable, but the person should see the number and
// decide, not have it silently locked in. Typical clear-sky outdoor GPS is a few meters; indoors
// or under heavy cover it routinely lands well past this.
private const val AR_ACCURACY_WARN_M = 12f
// Throttling for the continuous "just keep here up to date while viewing" location stream — loose
// on purpose, since this is for tracking roughly where you are, not for locking a new sign in place.
private const val AR_VIEW_LOCATION_MIN_MS = 4000L
private const val AR_VIEW_LOCATION_MIN_M = 3f

/**
 * The AR screen: camera preview underneath, floating words on top, positioned purely from compass
 * heading + device tilt + GPS — no ARCore, no plane detection, no persistent 6DOF anchors. A sign
 * is just a (lat, lon, text) triple synced through the same GitHub repo N already uses for chat,
 * so both people see the same signs in the same real-world places. Because there's no true anchor,
 * a sign's on-screen position is recomputed every frame from your current heading/tilt/location —
 * it doesn't drift or jitter like markerless SLAM AR, but it also won't survive you looking away
 * and back with perfect pixel stability the way ARCore's anchors would.
 */
@Composable
fun ArScreen(store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    // ---- permissions: camera to look through, fine location to place/see signs accurately ----
    var camGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var locGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        res[Manifest.permission.CAMERA]?.let { camGranted = it }
        res[Manifest.permission.ACCESS_FINE_LOCATION]?.let { locGranted = it }
    }
    LaunchedEffect(Unit) {
        val need = buildList {
            if (!camGranted) add(Manifest.permission.CAMERA)
            if (!locGranted) add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    // ---- orientation: compass heading (azimuth) + tilt (pitch), from Android's ROTATION_VECTOR
    // sensor — a proper gyro+accel+magnetometer fusion done at the OS level, noticeably smoother
    // and more responsive than a manual accel+mag fusion. getRotationMatrixFromVector()/
    // getOrientation() assume the phone is lying flat, screen up (like a map app) — held upright
    // like a camera, that reference frame is ~90° off, which is why an unmapped pitch reads near
    // 90° even when you're looking straight ahead. remapCoordinateSystem re-bases it onto "phone
    // held vertically, camera pointing at the horizon" instead, which is the standard fix for
    // compass-camera overlays like this one. On top of that we still smooth the resulting azimuth/
    // pitch with exponential smoothing (azimuth smoothed the short way around the 0/360 wrap) so
    // signs ease between updates instead of visibly jumping frame to frame. ----
    var azimuthDeg by remember { mutableStateOf(0f) }
    var pitchDeg by remember { mutableStateOf(0f) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotationSensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val rotationMatrix = FloatArray(9)
        val remappedMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        var smoothedAzimuth = 0f
        var smoothedPitch = 0f
        var smoothingInitialized = false
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (e.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
                SensorManager.getRotationMatrixFromVector(rotationMatrix, e.values)
                SensorManager.remapCoordinateSystem(
                    rotationMatrix, SensorManager.AXIS_X, SensorManager.AXIS_Z, remappedMatrix
                )
                SensorManager.getOrientation(remappedMatrix, orientation)
                val rawAzimuth = ((Math.toDegrees(orientation[0].toDouble()) + 360) % 360).toFloat()
                val rawPitch = Math.toDegrees(orientation[1].toDouble()).toFloat()

                if (!smoothingInitialized) {
                    smoothedAzimuth = rawAzimuth
                    smoothedPitch = rawPitch
                    smoothingInitialized = true
                } else {
                    // Shortest-path smoothing for azimuth so it eases the short way around
                    // (e.g. 359° -> 1°) instead of sweeping the long way through 180°.
                    val azimuthStep = angleDiff(rawAzimuth.toDouble(), smoothedAzimuth.toDouble())
                    smoothedAzimuth = ((smoothedAzimuth + SENSOR_SMOOTHING * azimuthStep).toFloat() + 360f) % 360f
                    smoothedPitch += SENSOR_SMOOTHING * (rawPitch - smoothedPitch)
                }
                azimuthDeg = smoothedAzimuth
                pitchDeg = smoothedPitch
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (rotationSensor != null) {
            sm.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        onDispose { sm.unregisterListener(listener) }
    }

    // ---- location: a light continuous stream while the screen is open, throttled by time and
    // distance (see AR_VIEW_LOCATION_MIN_MS/M below), so a sign's computed distance/bearing/facing
    // — and therefore whether it and its photo are still shown — track where you actually are as
    // you walk around, not just wherever you last happened to get a fix. requestFreshFix() below
    // is a separate, more demanding sampling pass used only at the moment of placing a new sign,
    // since that's the one place a precise fix actually matters (it's what the sign gets locked
    // to permanently). ----
    var here by remember { mutableStateOf<Location?>(null) }
    var acquiringFix by remember { mutableStateOf(false) }
    // Accuracy (meters) of the fix currently sitting in `here` while placing a sign — surfaced in
    // the placing UI so a rough fix (typically indoors) is visible and confirmed, not silently
    // locked in.
    var fixAccuracy by remember { mutableStateOf<Float?>(null) }
    val fixListener = remember { mutableStateOf<LocationListener?>(null) }
    val lm = remember { ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager }

    fun stopFixRequest() {
        fixListener.value?.let { try { lm.removeUpdates(it) } catch (_: Exception) {} }
        fixListener.value = null
        acquiringFix = false
    }

    /**
     * Turns GPS on and keeps sampling — a phone's very first fix after waking the radio is often
     * rough — taking whichever reading has the best accuracy, for up to AR_FIX_TIMEOUT_MS or until
     * one is already good enough, then switches location back off. A precise fix here matters more
     * than for just looking around: it's the point a sign gets permanently locked to.
     */
    fun requestFreshFix() {
        if (!locGranted) return
        stopFixRequest()
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        val provider = providers.firstOrNull() ?: return
        acquiringFix = true
        var best: Location? = null
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                if (best == null || loc.accuracy < best!!.accuracy) best = loc
                here = best
                fixAccuracy = best?.accuracy
                if ((best?.accuracy ?: Float.MAX_VALUE) <= AR_GOOD_ACCURACY_M) stopFixRequest()
            }
        }
        fixListener.value = listener
        try {
            @Suppress("DEPRECATION")
            lm.requestLocationUpdates(provider, 400L, 0f, listener, Looper.getMainLooper())
        } catch (_: Exception) { stopFixRequest(); return }
        scope.launch { delay(AR_FIX_TIMEOUT_MS); stopFixRequest() }
    }

    // Passive seed on open: whatever the OS already has cached, without switching GPS on — fills
    // in "here" immediately, before the continuous stream below has produced its first update.
    LaunchedEffect(locGranted) {
        if (!locGranted) return@LaunchedEffect
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                val last = lm.getLastKnownLocation(p)
                if (last != null && (here == null || last.time > (here?.time ?: 0L))) here = last
            } catch (_: Exception) {}
        }
    }

    // The continuous stream itself: on for as long as the screen is open, off the moment it isn't.
    DisposableEffect(locGranted) {
        if (!locGranted) return@DisposableEffect onDispose {}
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                // While requestFreshFix() is actively sampling for a new sign, let that flow own
                // "here" — this coarser stream shouldn't second-guess it mid-placement.
                if (!acquiringFix) here = loc
            }
        }
        for (p in providers) {
            try {
                @Suppress("DEPRECATION")
                lm.requestLocationUpdates(p, AR_VIEW_LOCATION_MIN_MS, AR_VIEW_LOCATION_MIN_M, listener, Looper.getMainLooper())
            } catch (_: Exception) {}
        }
        onDispose { try { lm.removeUpdates(listener) } catch (_: Exception) {} }
    }
    DisposableEffect(Unit) { onDispose { stopFixRequest() } }

    // ---- field of view of the back camera, from its actual sensor size + focal length, so signs
    // land where they should instead of assuming a made-up lens angle ----
    val fov = remember {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cm.cameraIdList.firstOrNull()
            val ch = id?.let { cm.getCameraCharacteristics(it) }
            val f = ch?.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val size = ch?.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            if (f != null && f > 0f && size != null) {
                // The sensor is mounted landscape; in our portrait preview its height maps to the
                // image's horizontal extent and its width to the vertical extent.
                val horiz = Math.toDegrees(2 * atan((size.height / (2 * f)).toDouble()))
                val vert = Math.toDegrees(2 * atan((size.width / (2 * f)).toDouble()))
                horiz to vert
            } else DEFAULT_FOV_H to DEFAULT_FOV_V
        } catch (_: Exception) { DEFAULT_FOV_H to DEFAULT_FOV_V }
    }

    // ---- signs: cached on-device, synced through the shared repo's AR/ folder ----
    var signs by remember { mutableStateOf(listOf<ArSign>()) }
    val known = remember { mutableSetOf<String>() }
    LaunchedEffect(store.repo, store.branch) {
        val cached = withContext(Dispatchers.IO) { loadArCache(ctx, store.repo, store.branch) }
        signs = cached; known.addAll(cached.map { it.path })
        val r = repo; val c = client
        if (r == null || c == null) return@LaunchedEffect
        while (true) {
            try {
                val paths = listArSignPaths(c, r)
                val listedSet = paths.toHashSet()
                val gone = signs.filter { it.path !in listedSet }.map { it.path }
                if (gone.isNotEmpty()) { signs = signs.filter { it.path in listedSet }; known.removeAll(gone.toSet()) }
                val fresh = paths.filter { it !in known }
                for (p in fresh) {
                    val s = fetchArSign(c, r, p)
                    known += p
                    if (s != null) signs = signs + s
                }
                if (fresh.isNotEmpty() || gone.isNotEmpty()) {
                    withContext(Dispatchers.IO) { saveArCache(ctx, store.repo, store.branch, signs) }
                }
            } catch (_: Exception) { /* best-effort — just try again next tick */ }
            delay(AR_POLL_MS)
        }
    }

    // ---- placing a new sign: words, a photo, or both ----
    var placing by remember { mutableStateOf(false) }
    var placeText by remember { mutableStateOf("") }
    var placeStatus by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }
    var pendingPhoto by remember { mutableStateOf<File?>(null) }
    var pendingPhotoThumb by remember { mutableStateOf<Bitmap?>(null) }

    fun clearPending() {
        pendingPhoto?.delete()
        pendingPhoto = null; pendingPhotoThumb = null
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ext = arPhotoExt(ctx.contentResolver.getType(uri).orEmpty())
            val dest = File(File(ctx.cacheDir, "n/ar_pending").apply { mkdirs() }, "${System.currentTimeMillis()}.$ext")
            val ok = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { input ->
                        dest.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                    } != null
                } catch (e: Exception) { false }
            }
            if (ok && dest.exists() && dest.length() > 0) {
                clearPending()
                pendingPhoto = dest
                pendingPhotoThumb = withContext(Dispatchers.IO) { decodeArSampled(dest, 300) }
            } else {
                dest.delete()
                placeStatus = "Couldn't read that photo."
            }
        }
    }

    var roughFixAcknowledged by remember { mutableStateOf(false) }

    fun place() {
        val text = placeText.trim()
        val photo = pendingPhoto
        val loc = here; val r = repo; val c = client
        if (text.isEmpty() && photo == null) return
        if (loc == null) { placeStatus = "Still finding your location…"; return }
        if (r == null || c == null) { placeStatus = "Not configured."; return }
        // A sign is locked to this fix forever — if it's rough (common indoors, where GPS can be
        // tens of meters off), make sure that's a choice, not something that happens silently.
        if (!roughFixAcknowledged && loc.accuracy > AR_ACCURACY_WARN_M) {
            placeStatus = "Weak GPS here (±${loc.accuracy.roundToInt()}m) — it may land off by that much. Tap [drop it] again to place anyway, or move somewhere with better signal (near a window, or outside)."
            roughFixAcknowledged = true
            return
        }
        roughFixAcknowledged = false
        stopFixRequest()   // got what we needed to save it — switch location back off
        val (lat, lon) = destinationPoint(loc.latitude, loc.longitude, azimuthDeg.toDouble(), AR_PLACE_AHEAD_M)
        // Locks the sign's height to wherever you're standing (GPS altitude, when the fix has one),
        // and its facing direction to the direction you were pointing when you wrote it — so it
        // reads straight-on from about where you're standing now, and looks turned away/edge-on
        // from other angles, like a real sign or photo would.
        val alt = if (loc.hasAltitude()) loc.altitude else Double.NaN
        val faceBearing = (azimuthDeg.toDouble() + 180.0) % 360.0
        val me = store.name.ifBlank { "me" }
        placing = false; placeText = ""; placeStatus = ""; pendingPhoto = null; pendingPhotoThumb = null
        scope.launch {
            try {
                var mediaPath = ""
                if (photo != null) {
                    val ts = System.currentTimeMillis()
                    mediaPath = "AR/media/$ts.${photo.extension.ifBlank { "jpg" }}"
                    withContext(Dispatchers.IO) { c.commitFileStream(mediaPath, photo, "n: ar photo", r) }
                }
                withContext(Dispatchers.IO) { commitArSign(c, r, me, text, lat, lon, alt, faceBearing, mediaPath) }
            } catch (e: Exception) {
                placeStatus = "Couldn't place it: ${e.message?.take(60) ?: "unknown error"}"
            } finally {
                photo?.delete()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!camGranted) {
            Text(
                "Camera permission is needed for AR.", color = Ink, fontFamily = TermFont, fontSize = 14.sp,
                textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val previewView = PreviewView(c)
                    val providerFuture = ProcessCameraProvider.getInstance(c)
                    providerFuture.addListener({
                        try {
                            val provider = providerFuture.get()
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                        } catch (_: Exception) {}
                    }, ContextCompat.getMainExecutor(c))
                    previewView
                }
            )

            // ---- the AR itself: floating words/photos, no background, positioned by real-world
            // bearing. Signs stay mounted (and their photos stay downloaded/decoded) for as long as
            // they're in range, even while off to the side — only their opacity changes as they
            // enter/leave the camera's field of view. That's what keeps them from re-loading and
            // popping in each time you swing the camera back onto one. ----
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val widthPx = with(density) { maxWidth.toPx() }
                val heightPx = with(density) { maxHeight.toPx() }
                val loc = here
                if (loc != null) {
                    for (s in signs) {
                        if (s.lat.isNaN() || s.lon.isNaN()) continue
                        val dist = distanceMeters(loc.latitude, loc.longitude, s.lat, s.lon)
                        if (dist > AR_VISIBLE_RADIUS_M || dist < 0.5) continue
                        key(s.path) {
                            val bearing = bearingDegrees(loc.latitude, loc.longitude, s.lat, s.lon)
                            val hDiff = angleDiff(bearing, azimuthDeg.toDouble())

                            // Elevation is locked to the sign's actual GPS altitude versus wherever
                            // you're standing now, not just however you happen to be tilting the
                            // phone — so a sign uphill or upstairs from you stays up there. Falls
                            // back to "sits at the horizon" when either altitude is missing (phone
                            // GPS altitude is often unavailable, especially from a network fix, and
                            // is noisier than horizontal position even when it is available).
                            val elevAngleDeg = if (!s.alt.isNaN() && loc.hasAltitude()) {
                                Math.toDegrees(atan2(s.alt - loc.altitude, dist))
                            } else 0.0
                            val vDiff = elevAngleDeg - pitchDeg.toDouble()

                            // Facing: locked to the direction its creator was pointing when they
                            // wrote it, so it reads straight-on from about where they stood and
                            // skews away like a real plane as you move around it — genuinely 3D:
                            // past ~90° you're looking at its back rather than it fading away, so
                            // you can walk all the way around one. Compose's rotationY does a true
                            // camera-projected flip, so the back reads as a mirror image of the
                            // front, the way the back of a real printed card or photo would if you
                            // could see through it — dimmed a bit further out so it still reads as
                            // "the back". Signs from before facing existed have no stored bearing
                            // and stay simple always-facing-you billboards (front only).
                            val faceOffDeg = if (!s.faceBearing.isNaN()) {
                                angleDiff((bearing + 180.0) % 360.0, s.faceBearing)
                            } else 0.0
                            val tiltDeg = faceOffDeg.toFloat()
                            val backFactor = if (abs(faceOffDeg) <= 90.0) 1.0 else
                                1.0 - (abs(faceOffDeg) - 90.0) / 90.0 * (1.0 - AR_BACK_DIM)

                            val hEdge = fov.first / 2; val vEdge = fov.second / 2
                            // Fades out over the last few degrees before the frame edge instead of
                            // popping at a hard cutoff, and never un-mounts within AR_VISIBLE_RADIUS_M —
                            // so a sign already has its photo loaded and waiting by the time it's
                            // actually back in frame.
                            val hFactor = (1.0 - ((abs(hDiff) - hEdge) / AR_EDGE_FADE_DEG)).coerceIn(0.0, 1.0)
                            val vFactor = (1.0 - ((abs(vDiff) - vEdge) / AR_EDGE_FADE_DEG)).coerceIn(0.0, 1.0)
                            val closeness = 1.0 - (dist / AR_VISIBLE_RADIUS_M).coerceIn(0.0, 1.0)
                            val nearness = 1.0 - (dist / AR_SIZE_MAX_DISTANCE_M).coerceIn(0.0, 1.0)
                            val scale = (AR_SIZE_MIN_SCALE + (AR_SIZE_MAX_SCALE - AR_SIZE_MIN_SCALE) * nearness).toFloat()
                            val alpha = ((0.3 + 0.7 * closeness) * hFactor * vFactor * backFactor).toFloat()
                            val x = widthPx / 2 + (hDiff / hEdge) * (widthPx / 2)
                            val y = heightPx / 2 - (vDiff / vEdge) * (heightPx / 2)

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                                    .graphicsLayer {
                                        this.alpha = alpha
                                        this.rotationY = tiltDeg
                                        // A longer camera distance keeps the flip from warping too
                                        // hard as it swings past ~90°, so the "edge-on" moment reads
                                        // as a thin sliver instead of a stretched-out smear.
                                        this.cameraDistance = 8f * density.density * 4f
                                    }
                            ) {
                                if (s.mediaPath.isNotBlank()) {
                                    var bmp by remember(s.path) { mutableStateOf<Bitmap?>(null) }
                                    LaunchedEffect(s.path) {
                                        val c = client; val r = repo
                                        if (c == null || r == null) return@LaunchedEffect
                                        val dest = arMediaCacheFile(ctx, s.mediaPath)
                                        val ready = dest.exists() && dest.length() > 0
                                        val ok = ready || try {
                                            withContext(Dispatchers.IO) { c.downloadFile(s.mediaPath, r, dest) }
                                        } catch (_: Exception) { false }
                                        if (ok) bmp = withContext(Dispatchers.IO) { decodeArSampled(dest, 480) }
                                    }
                                    bmp?.let { b ->
                                        Image(
                                            b.asImageBitmap(), contentDescription = null,
                                            modifier = Modifier.widthIn(max = (180 * scale).dp)
                                        )
                                    }
                                }
                                if (s.text.isNotBlank()) {
                                    Text(
                                        s.text, color = Accent, fontFamily = TermFont,
                                        fontWeight = FontWeight.Bold, fontSize = (22 * scale).sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---- chrome ----
        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
            TextButton(onClick = { showInfo = !showInfo }) { Text("[i]", color = Dim, fontFamily = TermFont, fontSize = 14.sp) }
        }

        if (showInfo) {
            val loc = here
            Column(Modifier.align(Alignment.TopStart).padding(top = 56.dp, start = 12.dp)) {
                Text("heading ${azimuthDeg.roundToInt()}° · pitch ${pitchDeg.roundToInt()}°", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Text(
                    if (loc != null) "fix: ${"%.5f".format(loc.latitude)}, ${"%.5f".format(loc.longitude)} (±${loc.accuracy.roundToInt()}m)"
                    else "no location fix yet",
                    color = Dim, fontFamily = TermFont, fontSize = 11.sp
                )
                Text(
                    if (loc != null && loc.hasAltitude()) {
                        val vAcc = if (loc.hasVerticalAccuracy()) " (±${loc.verticalAccuracyMeters.roundToInt()}m)" else " (accuracy unknown)"
                        "alt: ${"%.1f".format(loc.altitude)}m$vAcc"
                    } else "no altitude in this fix",
                    color = Dim, fontFamily = TermFont, fontSize = 11.sp
                )
                Text("fov ${fov.first.roundToInt()}°×${fov.second.roundToInt()}° · ${signs.size} sign(s) known", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
        }

        // Center reticle — something to aim with, since new signs drop a bit ahead of where you're facing.
        Box(
            Modifier.align(Alignment.Center).size(10.dp)
                .background(Color.White.copy(alpha = 0.55f), shape = CircleShape)
        )

        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (placeStatus.isNotEmpty()) {
                Text(placeStatus, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
            }
            TextButton(
                onClick = { placing = true; roughFixAcknowledged = false; requestFreshFix() },
                enabled = camGranted && locGranted,
                modifier = Modifier.alpha(0f) // invisible, but the tap target stays exactly here
            ) {
                Text("[write a sign]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        if (placing) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f))) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Words and/or a photo to leave floating here:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                    if (acquiringFix) {
                        Spacer(Modifier.height(4.dp))
                        Text("finding your location…", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                    }
                    fixAccuracy?.let { acc ->
                        Spacer(Modifier.height(2.dp))
                        Text(
                            "GPS accuracy: ±${acc.roundToInt()}m",
                            color = if (acc > AR_ACCURACY_WARN_M) Warn else Dim,
                            fontFamily = TermFont, fontSize = 11.sp
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    pendingPhotoThumb?.let { thumb ->
                        Image(
                            thumb.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.widthIn(max = 140.dp).padding(bottom = 4.dp)
                        )
                        TextButton(onClick = { clearPending() }) {
                            Text("[remove photo]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                    TextField(
                        value = placeText, onValueChange = { placeText = it }, singleLine = true,
                        placeholder = { Text("hi", color = Dim, fontFamily = TermFont) },
                        textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 16.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { place() }),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                            focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        if (pendingPhotoThumb == null) {
                            TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }) {
                                Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 15.sp)
                            }
                        }
                        TextButton(onClick = { place() }, enabled = placeText.isNotBlank() || pendingPhoto != null) {
                            Text("[drop it]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        TextButton(onClick = { placing = false; placeText = ""; clearPending(); stopFixRequest(); roughFixAcknowledged = false }) {
                            Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

/** Decodes at reduced size so a big photo doesn't blow up memory just to float it on screen. */
private fun decodeArSampled(file: File, maxDim: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}
