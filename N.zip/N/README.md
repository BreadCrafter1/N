# Constellation

A tiny Novochron-styled app: text, photo, video, and voice messages with one other person, using a
shared GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving
is polling the same folder.

## Setting the GitHub token
The token used to talk to the repo is no longer written into any source file, so it can't get
swept up in a `git push` and auto-revoked by GitHub's secret scanning.

- **Building locally:** copy `local.properties.example` to `local.properties` (already
  git-ignored) and paste your token in place of `ghp_your_token_here`.
- **Building via the "Build N" GitHub Actions workflow:** add the token as a repo secret instead
  — repo → **Settings → Secrets and variables → Actions → New repository secret**, name it
  `N_GH_TOKEN`, paste the token as the value. Then, in the workflow file's build step (the one
  that runs `./gradlew assembleDebug` or similar), add:
  ```yaml
  env:
    N_GH_TOKEN: ${{ secrets.N_GH_TOKEN }}
  ```
  (This project's workflow file wasn't part of what I edited — add that `env:` block to yours if
  it isn't there already, or ask me to write the whole workflow file if you'd rather start over.)

Either way, if you ever rotate the token, there's no source file to edit — just update
`local.properties` and/or the `N_GH_TOKEN` secret.

## Fix: "There was a problem parsing the package"
This happened because every CI build was signed with a throwaway, machine-generated debug
keystore, so each build's signature differed from the last one on your phone — Android shows
that generic parsing error for a signature mismatch on install-over-install, even though the
APK itself is fine. `app/debug.keystore` is now checked into the repo and every build (local or
CI) signs with it, so this won't happen again.

**One-time step:** since your currently-installed copy was signed with the old throwaway key,
this next build still won't install over it. Uninstall the app once, then install the new build
as usual — after that, updates will install cleanly over each other.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Voice gate + debug panel
- On every launch the app shows a pitch-black screen with the mic open. It stays that way until the secret word is spoken; then the chat appears. Nothing is remembered between launches.
- The secret word is **not in the app**. It lives in the shared repo at `Config/secret.txt` and is fetched at launch. If it can't be fetched (offline, file missing), the gate stays shut.
- **First-time setup:** tap the invisible spot at the top-left corner **5 times quickly** to open the debug panel, type `Operation`, and hit `[save]`. That creates `Config/secret.txt` in the repo. Change the word the same way any time.
- Your name is set once on first launch (there's no `[name]` button anymore). To change it later, open the debug panel and use `[save name]`. Messages you sent under the old name will show up on the other side, since they're matched by name.
- **Repo voice keys:** besides the main secret word, you can add as many extra voice words as you like, each tied to a different repo. Say one at the gate and N opens straight onto that repo (chat, calls, theme, profiles — everything) instead of the home repo. Add/edit/remove them in the debug panel under **Repo voice keys** (`[+ add key]`, `[remove]`, `[save keys]`); they're saved in the home repo at `Config/voicekeys.json`. The main word still opens the home repo. Two keys can't share a word, and if you say something containing more than one key word, the longest wins. `[test voice]` shows which key (if any) your voice matched.
- A voice-key repo lasts only for that session — locking or relaunching goes back to the home repo. Background notifications always follow the home repo. The GitHub token baked into the build must have access to every repo you add.
- The debug panel also has `[lock now]` (re-locks the app) and shows repo/branch/version/token status.
- Speech recognition uses the phone's built-in recognizer (Google's on most phones), so the mic permission must be granted and the device needs a speech service.

## Calling
- `[call]` / `[video call]` at the top start a voice or video call. It rings everyone else who has
  the app open on the shared repo; whoever's around can `[accept]`, and a third person can join an
  already-active call the same way — up to 3 people total. There's no push notification, so calls
  only work while everyone involved has the chat open.
- Signaling (who's calling whom, the offer/answer handshakes) goes through the same shared repo as
  everything else, in a `Call/` folder — no separate server. Each phone opens a direct WebRTC
  connection to every other phone in the call (mesh style — fine for 3 people, not meant to scale
  past that), with Google's public STUN servers helping each side find its way through NAT. On
  [accept], you're asked for microphone (and camera, for a video call) permission if you haven't
  granted it yet.
- During a call: `[mute]`, `[flip]` (front/back camera, video calls only), `[share]` (screenshare,
  see below), and `[end]`. An unanswered call gives up after 45 seconds.
- STUN alone can't always punch through every network (a minority of carrier/corporate NATs need a
  TURN relay instead) — if calls reliably fail to connect on a particular network, that's the likely
  cause, and a TURN server would need to be added to fix it.

## Screenshare
- `[share]` during a call asks Android's own system permission dialog to confirm sharing *your*
  screen — the same dialog every screen-recording/casting app uses. It only ever captures the
  screen of the phone that tapped it; there's no way to use this to see anyone else's screen.
- Once granted, everyone else in the call sees your screen full-size, with everyone's camera
  feeds shown as small thumbnails along the top. `[stop share]` ends it and switches back to the
  normal camera view.
- Because of an Android 14+ requirement, sharing briefly starts a small foreground service (you'll
  see a persistent "your screen is being shared" notification the whole time it's on — Android
  requires this and it can't be hidden, which is intentional: it means screen sharing can never
  happen silently on your own phone).

## Settings (top-right `[settings]`)
- **Appearance:** `[dark]` / `[light]` mode, an accent colour (buttons and labels) and a letter colour.
  Pick a swatch or type a `#RRGGBB` hex. These are saved **on this phone only**, so each of you can
  have your own look. `[reset colours]` puts them back to default.
- **Background (synced):** pick a preset colour/gradient, type your own colours, or `[pick image]`
  from the gallery. It's committed to the shared repo as `Config/theme.json` (images go to
  `Config/bg-<timestamp>.jpg`, shrunk to max 1600px), and every phone checks for a newer one every
  ~15 seconds, so changing it on one phone changes it on the other. The newest change wins. The
  "readability shade" slider darkens (dark mode) or lightens (light mode) an image so text stays
  legible. Replacing the background deletes the previous image file from the repo.
- The voice-gate screen always stays pitch black, regardless of theme.

## Minimizing a call
During a call, `[hide]` (top-left of the call screen) or the Back button tucks the call into a small
draggable window floating over the chat. The call keeps running — you can read and send messages,
send photos, scroll history, etc. The window has `[mute]` and `[end]`; tap the window itself to go back
full-screen. Leaving the app with the Home button still shrinks it to Picture-in-Picture as before.
Incoming calls always ring full-screen. (Back while *connected* now minimizes instead of hanging up;
use `[end]` to hang up.)

## Notifications
`[settings] → notifications → on` (asks for the notification permission on Android 13+). There's no
push server in this design, so N runs a small foreground service that checks the current month's
`Msg/` folder every ~6 seconds while the app isn't on screen, and posts a normal notification for each
new message from the other person. Details:
- You'll see a quiet, low-priority "Listening for new messages" entry in the shade — Android requires
  that for any always-running service.
- Nothing is sent while the app is open, and enabling it doesn't dump old history — it only alerts on
  messages that arrive after it's switched on.
- By default notifications say only "New message from X"; `[show text]` includes the message text.
  Lock-screen visibility is set to private either way.
- Tapping a notification opens the app (which starts at the voice gate, as always).
- After a reboot, open N once to restart the listener. If alerts stop on your phone, set N's battery
  usage to "unrestricted" — some manufacturers kill background services aggressively.
- **Auto-start:** with notifications on, the listener starts again by itself after a reboot or after N is
  updated (a boot receiver + `RECEIVE_BOOT_COMPLETED`). It runs as a `specialUse` foreground service (no
  time limit, and allowed to start at boot even on Android 15). Keep `targetSdk` in mind if you raise it.
- **Permissions:** Settings → notifications shows a ✓/✗ for "show notifications" and "run in background
  unrestricted", with buttons that take you straight to the right system screen.
- **The "listening" entry:** Android only lets an app stay awake in the background if it shows one. It is
  silent with no status-bar icon, and `[hide 'listening' entry]` opens its channel settings so you can switch
  it off — the listener keeps running and real messages still alert. Message alerts only appear when
  someone actually messages you, never while the app is open.
- **Incoming calls:** while the app is closed the same listener watches `Call/room.json` and, if someone else
  starts a call, posts a ringing notification (ringtone + vibration, repeats until dealt with, wakes the screen,
  disappears when the caller hangs up or after 45s). Tap it to open N, which goes through the voice gate and then
  shows the usual accept/decline screen (a still-live ring is picked up on launch). You can't answer straight
  from the notification, because the call itself needs the app running. "Hide text" also hides who is calling.
  On Android 14+ the screen-wake part may need allowing in system settings (it is a separate permission).

## Stickers & GIFs
`[stickers & gifs]` (next to the call buttons) opens a picker.
- **Emoji stickers:** tap one and it's sent as a big emoji with no bubble.
- **Our stickers:** `[+ add]` saves any image (shrunk to 512px PNG, transparency kept) into the repo's
  `Stickers/` folder, so both phones share one collection. Sending one uploads nothing — the message
  just points at the file. Long-press a sticker to remove it for both of you.
- **GIFs:** `[pick a gif from gallery]` works out of the box. GIFs animate in the chat on Android 9+
  (older phones show the first frame). GIF *search* uses GIPHY and needs a free API key from
  developers.giphy.com: put `giphyKey=...` in `local.properties`, or for GitHub Actions add a repo secret
  `N_GIPHY_KEY` and pass it to the build step's `env:` next to `N_GH_TOKEN`. Without a key the search box is
  simply hidden. Like your GitHub token, the key ends up inside the APK.
- Every GIF/sticker upload is a file in your repo, so it fills up faster than text does.

## Voice changer
After you stop recording, the input row turns into a voice picker: `original`, `deep`, `chipmunk`, `robot`,
`echo`, `radio`. `[▶ preview]` plays it to you first, `[send]` sends it, `[discard]` throws it away. Effects
are applied on your phone and the result is sent as a `.wav` (bigger than the normal `.m4a`; a minute is ~2.6 MB),
so the other person needs nothing special. `original` sends the untouched recording as before. Recordings are made at 48 kHz mono, 256 kbps AAC (falling back to lower settings only if a phone refuses).

## Video call filters
While connected on a video call, `[filter: none]` (above the buttons) cycles through: mono, sepia, warm,
cool, negative, vignette, pixel. The filter is applied to your camera before it's sent, so the other
person sees it and so does your own preview. Not included: background blur and face masks/AR (they
need on-device face/person tracking on every frame, which is a much heavier addition).

## Profile (nickname + picture)
`[settings] → profile`: `[change picture]` (centre-cropped to a 256px circle), and a nickname that is shown instead of
your username in chat bubbles, reply quotes, call screens and notifications. The username itself is untouched (it is how
messages are matched to you), and is still shown under your nickname in settings. Saved to the repo as
`Config/profiles/<user>.json` + `<user>-<time>.jpg`, so the other phone sees your nickname and picture (and you see theirs).

## Deleting a message
Long-press one of your own messages → `delete` → confirm. The message file (and the photo/video/voice
file it uploaded) is removed from the repo, so it disappears on the other phone within a moment. You can only
delete your own messages (matched by name), and shared stickers are never removed. Note it's a repo commit,
so the message still exists in the repo's git history for anyone who looks there.

## Replying
Swipe a message sideways (or long-press it and pick `reply`) to reply to it — yours or theirs. A bar appears above the input showing who/what you're replying to; `[x]` cancels. Works for text, photo, video, and voice. The quote shows at the top of the reply bubble, and tapping it scrolls to the original.

## More debug tools
The debug panel also has: device/mic/speech-service info and cache sizes, `[ping github]` (latency, API rate limit, repo access), `[test message]` (sends a "[debug] test message" into the chat), `[clear cache]` (wipes the local chat and media cache), `[test voice]` (shows what the recognizer hears and whether it matches the word typed in the field), and a live event log with `[copy log]`. The log never records the secret word or what was said at the gate.

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Tap `[mic]` to
   record a voice message — the button turns into a running timer and `[stop]`; tap it again (or
   `[cancel]` to discard) to send it. First tap asks for microphone permission.
3. Photos, videos and voice clips can be up to **100 MB** each — that's GitHub's hard per-file limit for
   the Contents API. Big files are streamed from/to disk (never held in memory), show upload progress
   in the status line, and appear in your own chat immediately while they upload.
4. **Tap any photo** to open it full-screen, then tap `[save]` to store the original, full-quality file
   in your gallery (Pictures/N). Android 9 and older will ask for storage permission the first time.

## Speed
- New messages are checked for every second using ETags — when nothing changed, GitHub replies with an
  empty `304` (which doesn't count against your API rate limit).
- New message files are fetched several at a time, and the chat is cached on the phone so it shows
  instantly on launch. Downloaded photos/videos/voice clips are cached too.
- Your own messages appear instantly and are sent in the background; sending skips the extra
  "does this file exist?" round-trip and retries automatically on 409 conflicts.

## Message history (month buckets)
- Messages are filed into one subfolder per calendar month — `Msg/2026-09/...`, `Msg/2026-10/...` —
  instead of one flat folder. GitHub's Contents API only returns a folder's first 1,000 entries, so
  without this, a long-lived chat would eventually go "blind" to its own oldest messages. Splitting
  by month means each folder gets its own fresh 1,000-message budget, so this would only bite if one
  side sent over 1,000 messages in a single calendar month.
- The app only polls the *current* month's folder every second. Older months are loaded on demand:
  scroll to the top of the chat and tap **[load earlier messages]** to pull in the previous month,
  one month at a time. Nothing is ever deleted or needs manual `[clear]`ing to keep working.
- Buckets are keyed in UTC, so both phones agree on which folder a message near a month boundary
  belongs to, regardless of either person's local timezone.
- Media (photos/videos/voice) still lives in one flat `Msg/media/` folder — it's never listed, only
  fetched by the exact path a message file points to, so it isn't subject to the 1,000-entry cap.


