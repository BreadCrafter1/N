# Constellation

A tiny Novochron-styled app: text, photo, video, and voice messages with one other person, using a
shared GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving
is polling the same folder.

## Setting the GitHub token
The token used to talk to the repo is no longer written into any source file, so it can't get
swept up in a `git push` and auto-revoked by GitHub's secret scanning.

- **Building locally:** copy `local.properties.example` to `local.properties` (already
  git-ignored) and paste your token in place of `ghp_your_token_here`.
- **Building via the "Build N" GitHub Actions workflow:** add the token as a repo secret instead
  — repo → **Settings → Secrets and variables → Actions → New repository secret**, name it
  `N_GH_TOKEN`, paste the token as the value. Then, in the workflow file's build step (the one
  that runs `./gradlew assembleDebug` or similar), add:
  ```yaml
  env:
    N_GH_TOKEN: ${{ secrets.N_GH_TOKEN }}
  ```
  (This project's workflow file wasn't part of what I edited — add that `env:` block to yours if
  it isn't there already, or ask me to write the whole workflow file if you'd rather start over.)

Either way, if you ever rotate the token, there's no source file to edit — just update
`local.properties` and/or the `N_GH_TOKEN` secret.

## Fix: "There was a problem parsing the package"
This happened because every CI build was signed with a throwaway, machine-generated debug
keystore, so each build's signature differed from the last one on your phone — Android shows
that generic parsing error for a signature mismatch on install-over-install, even though the
APK itself is fine. `app/debug.keystore` is now checked into the repo and every build (local or
CI) signs with it, so this won't happen again.

**One-time step:** since your currently-installed copy was signed with the old throwaway key,
this next build still won't install over it. Uninstall the app once, then install the new build
as usual — after that, updates will install cleanly over each other.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Voice gate + debug panel
- On every launch the app shows a pitch-black screen with the mic open. It stays that way until the secret word is spoken; then the chat appears. Nothing is remembered between launches.
- The secret word is **not in the app**. It lives in the shared repo at `Config/secret.txt` and is fetched at launch. If it can't be fetched (offline, file missing), the gate stays shut.
- **First-time setup:** tap the invisible spot at the top-left corner **5 times quickly** to open the debug panel, type `Operation`, and hit `[save]`. That creates `Config/secret.txt` in the repo. Change the word the same way any time.
- Your name is set once on first launch (there's no `[name]` button anymore). To change it later, open the debug panel and use `[save name]`. Messages you sent under the old name will show up on the other side, since they're matched by name.
- **Repo voice keys:** besides the main secret word, you can add as many extra voice words as you like, each tied to a different repo. Say one at the gate and N opens straight onto that repo (chat, calls, theme, profiles — everything) instead of the home repo. Add/edit/remove them in the debug panel under **Repo voice keys** (`[+ add key]`, `[remove]`, `[save keys]`); they're saved in the home repo at `Config/voicekeys.json`. The main word still opens the home repo. Two keys can't share a word, and if you say something containing more than one key word, the longest wins. `[test voice]` shows which key (if any) your voice matched.
- A voice-key repo lasts only for that session — locking or relaunching goes back to the home repo. Background notifications always follow the home repo. The GitHub token baked into the build must have access to every repo you add.
- The debug panel also has `[lock now]` (re-locks the app) and shows repo/branch/version/token status.
- Speech recognition uses the phone's built-in recognizer (Google's on most phones), so the mic permission must be granted and the device needs a speech service.

## Calling
- `[call]` / `[video call]` at the top start a voice or video call. It rings everyone else who has
  the app open on the shared repo; whoever's around can `[accept]`, and a third person can join an
  already-active call the same way — up to 7 people total. There's no push notification, so calls
  only work while everyone involved has the chat open.
- Signaling (who's calling whom, the offer/answer handshakes) goes through the same shared repo as
  everything else, in a `Call/` folder — no separate server. Each phone opens a direct WebRTC
  connection to every other phone in the call (mesh style — built for up to 7 people), with Google's public STUN servers helping each side find its way through NAT. On
  [accept], you're asked for microphone (and camera, for a video call) permission if you haven't
  granted it yet.
- During a call: round icon buttons for mute, speaker, flip (front/back camera, video calls only), share
  (screenshare, see below) and effects (video calls), plus a wide red `end call` button. An unanswered call
  gives up after 45 seconds.
- The call screens follow your theme, like the chat: the shared background (colour / gradient / image — it
  syncs between phones), your accent and letter colours, light/dark mode, and the same round chip buttons
  with vector icons. Over live video, buttons and names sit on translucent chips so they stay readable. Voice
  calls and ringing show the other person's profile picture.
- STUN alone can't always punch through every network (a minority of carrier/corporate NATs need a
  TURN relay instead) — if calls reliably fail to connect on a particular network, that's the likely
  cause, and a TURN server would need to be added to fix it.

## Call cards in the chat (join / call ended)
Like Messenger, a call leaves a card in the conversation:
- When someone starts a call, a card appears: **"X started a video call"** with a **[join]** button and a
  live count ("calling…" / "2 in the call"). Tap `join` to hop into the call even if you missed the ring or
  declined it; you're asked for mic/camera permission like any other call. The button is disabled if you're
  already in another call or the call is full (7 people).
- When the call is over the same card flips to **"Video call ended · 5:12"** (or **"Missed video call"** /
  **"No answer"** if nobody picked up). While you're in the call it reads "You're in this call" with `[return]`.
- Who posts what: the phone that starts the call posts the "started" card; whoever is the last to leave
  posts "ended" (with the duration). They're ordinary message files (`"type": "CALL"`), so they're stored in
  the month folders and cached like any message — just without read receipts, reactions or reply.
- `Call/room.json` now has two extra fields: `ended` (set when the last person leaves, which also stops a still-ringing
  notification) and `hb`, a heartbeat that someone in the call refreshes every ~30 s. A card only offers `join`
  while the heartbeat is fresh (< 100 s), so if everyone's phone dies mid-call the card stops offering `join`
  by itself and shows "ended".
- Both phones need this build. An older build just ignores call cards (it can't parse the new type), and
  call cards don't trigger message notifications.

## Big calls (up to 7 people)
- **Grid:** in a video call everyone else is tiled in a grid (side by side for 1-2 people, two columns for 3-6), with
  your own preview floating in the corner. During a screenshare the camera thumbnails become a swipeable strip.
- **Mesh cost:** every phone holds one direct connection to each other phone, so in a 7-person call you send your
  audio/video 6 times. To keep that workable, outgoing video is automatically capped as the call fills: full quality up
  to 3 people, ~600 kbps / 24 fps at 4-5 people, ~300 kbps / 15 fps at 6-7. Voice calls aren't affected. Expect phones to
  run warm and the picture to be soft in a 7-person *video* call; voice-only is comfortable.
- **Joining together:** room.json is now merged instead of overwritten, and every 5 s each phone checks that it's on the
  roster and linked to everyone listed. If two people join in the same second and miss each other, the one with the
  alphabetically-smaller name connects to the other after ~15 s.
- **Needs:** every phone must be on this build; unreliable networks/NATs (STUN only, no TURN) get more likely to hit at
  least one failed link with more people.

## Crash fixes during calls
Random crashes while calling were traced to a handful of causes, all fixed:
- WebRTC reports connection changes on its own threads, and the app touched shared call state and closed peer connections
  straight from those threads (worst with several people). Everything is now handed back to the main thread first.
- When a call ended, the video views could still try to detach from a video track that was already freed, which throws.
  Those calls are now guarded and unhooked in the right order.
- The call's keep-alive service declared "camera"/"microphone" even if that permission wasn't granted, which Android
  answers with a crash. It now only claims what's granted and, if Android refuses anyway, the call continues without it.
  A video call also now stops with a clear message if camera permission is denied.
- A delayed "end call" timer from a finished call could close a *new* call started within ~1 s; it's now tied to its own call.
- The 5-second call housekeeping loop and ending a call with screenshare on no longer start/stop services in a way
  Android can punish.
- **Crash log:** if the app still dies, the exception and top stack frames are saved and shown in the debug panel's event
  log on the next launch (tap the top-left corner 5x, then `[copy log]`). Send me that and I can pin down anything left.

## Screenshare
- `[share]` during a call asks Android's own system permission dialog to confirm sharing *your*
  screen — the same dialog every screen-recording/casting app uses. It only ever captures the
  screen of the phone that tapped it; there's no way to use this to see anyone else's screen.
- Once granted, everyone else in the call sees your screen full-size, with everyone's camera
  feeds shown as small thumbnails along the top. `[stop share]` ends it and switches back to the
  normal camera view.
- Because of an Android 14+ requirement, sharing briefly starts a small foreground service (you'll
  see a persistent "your screen is being shared" notification the whole time it's on — Android
  requires this and it can't be hidden, which is intentional: it means screen sharing can never
  happen silently on your own phone).

## Chat layout (icons)
All the old `[text]` buttons in the chat screen are now icons, and the message box takes the freed-up width.
- **Header:** title on the left; voice call, video call, games and settings icons on the right. (Anywhere this README
  says `[call]`, `[video call]`, `[games]` or `[settings]`, that's now the matching icon.)
- **Bottom bar:** `+` · message box (fills the row) · send / mic. The right-hand button is **send** while you've typed
  something and the **mic** when the box is empty. `+` opens a small tray with photo, video and stickers & gifs, and
  closes again after you pick one.
- **Recording:** the bar turns into ✕ (cancel) · red dot with the running timer · ■ (stop and send).
- **Icon colour:** grey by default (light grey in dark mode, dark grey in light mode). If you pick an accent colour in
  settings, the icons use that instead.
- **Compact mode while typing:** when the keyboard is up, the title/icon header is hidden, the chat is kept scrolled to the
  newest message, and the message box grows up to 4–6 lines so you can see everything you typed. The whole chat now also
  sits above the keyboard (it didn't before, so the box could end up hidden behind it). Enter still sends.
- The row of call / sticker buttons that used to sit above the messages is gone, so the message list is taller too.
- Icons are drawn in code (`Icons.kt`), tinted with your accent colour, so there's no new library. Each one sits on a
  translucent dark/light disc (the four header icons share a single pill) with a thin accent outline, so it stays visible on any wallpaper, accent colour or theme.

## Minigames (top-right `[games]`, next to `[settings]`)
- **Chess (2 players):** `[play white]` / `[play black]` / `[random]` opens a game. The other person sees it under
  *open games* on their own chess screen and taps `[join]`. Full rules: check, checkmate, stalemate, castling, en passant,
  promotion (you pick the piece), and automatic draws (insufficient material, 50-move rule, threefold repetition). Tap a
  piece to see its legal moves, tap a highlighted square to move. You can `[offer draw]`, `[resign]`, `[flip board]`, and
  see captured pieces and the move list. Several games can run at once, and finished games can be viewed or deleted.
- **How it syncs:** each game is one small file, `Games/chess/<id>.json`, in the repo in use (so a voice-key repo has its
  own games). It holds both player names and the move list; both phones replay the moves to get the same board. Only the
  player whose turn it is writes a move, so there are no conflicts. Phones check every ~2 s while a game is open (~4 s in
  the lobby), using the same ETag trick as the chat, so idle polling costs nothing against the API limit. Like the chat,
  there's no push — the other player sees your move while they have the chess screen open.
- **Tic Tac Toe (2 players):** same flow as chess — `[play X]` / `[play O]` / `[random]`, the other person `[join]`s from
  their own screen. X moves first; wins are highlighted, and `[rematch — swap sides]` starts a new game with the other
  person already seated. Games are stored as `Games/ttt/<id>.json`; phones check every ~1.5 s while a game is open.
- **Sudoku (singleplayer):** a fresh, uniquely-solvable puzzle generated on the phone — `[easy]` / `[medium]` / `[hard]`.
  Number pad with remaining counts, pencil `[notes]`, `[erase]`, `[hint]`, timer, and a mistake counter (wrong digits show in
  red). The current puzzle is saved on the phone and resumes next time.
- New games can be added later in `Games.kt` (`GamesMenu`).

## Settings (top-right `[settings]`)
- **Appearance:** `[dark]` / `[light]` mode, an accent colour (buttons and labels) and a letter colour.
  Pick a swatch or type a `#RRGGBB` hex. These are saved **on this phone only**, so each of you can
  have your own look. `[reset colours]` puts them back to default.
- **Background (synced, per repo):** the background belongs to the repo it was set in — the home repo and each
  voice-key repo have their own, and switching repos never carries one over. Pick a preset colour/gradient, type your own colours, or `[pick image]`
  from the gallery. It's committed to the shared repo as `Config/theme.json` (images go to
  `Config/bg-<timestamp>.jpg`, shrunk to max 1600px), and every phone checks for a newer one every
  ~15 seconds, so changing it on one phone changes it on the other. The newest change wins. The
  "readability shade" slider darkens (dark mode) or lightens (light mode) an image so text stays
  legible. Replacing the background deletes the previous image file from the repo.
- The voice-gate screen always stays pitch black, regardless of theme.

## Minimizing a call
During a call, the hide button (the down-arrow chip at the top-left of the call screen) or the Back button tucks the call into a small
draggable window floating over the chat. The call keeps running — you can read and send messages,
send photos, scroll history, etc. The window has mute and end-call icons; tap the window itself to go back
full-screen. Leaving the app with the Home button still shrinks it to Picture-in-Picture as before.
Incoming calls always ring full-screen. (Back while *connected* now minimizes instead of hanging up;
use the red end-call button to hang up.)

## Notifications
`[settings] → notifications → on` (asks for the notification permission on Android 13+). There's no
push server in this design, so N runs a small foreground service that checks the current month's
`Msg/` folder every ~6 seconds while the app isn't on screen, and posts a normal notification for each
new message from the other person. Details:
- You'll see a quiet, low-priority "Listening for new messages" entry in the shade — Android requires
  that for any always-running service.
- Nothing is sent while the app is open, and enabling it doesn't dump old history — it only alerts on
  messages that arrive after it's switched on.
- By default notifications say only "New message from X"; `[show text]` includes the message text.
  Lock-screen visibility is set to private either way.
- Tapping a notification opens the app (which starts at the voice gate, as always).
- After a reboot, open N once to restart the listener. If alerts stop on your phone, set N's battery
  usage to "unrestricted" — some manufacturers kill background services aggressively.
- **Auto-start:** with notifications on, the listener starts again by itself after a reboot or after N is
  updated (a boot receiver + `RECEIVE_BOOT_COMPLETED`). It runs as a `specialUse` foreground service (no
  time limit, and allowed to start at boot even on Android 15). Keep `targetSdk` in mind if you raise it.
- **Permissions:** Settings → notifications shows a ✓/✗ for "show notifications" and "run in background
  unrestricted", with buttons that take you straight to the right system screen.
- **The "listening" entry:** Android only lets an app stay awake in the background if it shows one. It is
  silent with no status-bar icon, and `[hide 'listening' entry]` opens its channel settings so you can switch
  it off — the listener keeps running and real messages still alert. Message alerts only appear when
  someone actually messages you, never while the app is open.
- **Incoming calls:** while the app is closed the same listener watches `Call/room.json` and, if someone else
  starts a call, posts a ringing notification (ringtone + vibration, repeats until dealt with, wakes the screen,
  disappears when the caller hangs up or after 45s). Tap it to open N, which goes through the voice gate and then
  shows the usual accept/decline screen (a still-live ring is picked up on launch). You can't answer straight
  from the notification, because the call itself needs the app running. "Hide text" also hides who is calling.
  On Android 14+ the screen-wake part may need allowing in system settings (it is a separate permission).

## Stickers & GIFs
`[stickers & gifs]` (next to the call buttons) opens a picker.
- **Emoji stickers:** tap one and it's sent as a big emoji with no bubble.
- **Our stickers:** `[+ add]` saves any image (shrunk to 512px PNG, transparency kept) into the repo's
  `Stickers/` folder, so both phones share one collection. Sending one uploads nothing — the message
  just points at the file. Long-press a sticker to remove it for both of you.
- **GIFs:** `[pick a gif from gallery]` works out of the box. GIFs animate in the chat on Android 9+
  (older phones show the first frame). GIF *search* uses GIPHY and needs a free API key from
  developers.giphy.com: put `giphyKey=...` in `local.properties`, or for GitHub Actions add a repo secret
  `N_GIPHY_KEY` and pass it to the build step's `env:` next to `N_GH_TOKEN`. Without a key the search box is
  simply hidden. Like your GitHub token, the key ends up inside the APK.
- Every GIF/sticker upload is a file in your repo, so it fills up faster than text does.

## Voice changer
After you stop recording, the input row turns into a voice picker: `original`, `deep`, `chipmunk`, `robot`,
`echo`, `radio`. `[▶ preview]` plays it to you first, `[send]` sends it, `[discard]` throws it away. Effects
are applied on your phone and the result is sent as a `.wav` (bigger than the normal `.m4a`; a minute is ~2.6 MB),
so the other person needs nothing special. `original` sends the untouched recording as before. Recordings are made at 48 kHz mono, 256 kbps AAC (falling back to lower settings only if a phone refuses).

## Video call effects
While connected on a video call, the sparkle `effects` button (in the call buttons) opens a picker with three tabs. They work
independently, so you can combine one from each (e.g. `vivid` + `cat` + `sunset`). Pick `none` in a tab, or
`[clear all]`, to turn things off. Everything is applied to your camera before it's sent, so the other
person sees it and so does your own preview.

- **filters** – whole-picture looks: mono, sepia, warm, cool, negative, vignette, pixel, noir, vivid, fade, dream,
  poster, thermal, matrix, sketch; and lens warps: mirror, swirl, fisheye, wavy.
- **faces** – stickers that follow your face and tilt with your head: dog, cat, bunny, clown, shades, stache, crown,
  devil, angel, hearts, party, alien. And silly faces that stretch or squish you: big eyes, big nose, big mouth, squish,
  chubby, goofy. Tracks the biggest face in view; if you leave the frame the effect disappears and comes back with you.
- **backgrounds** – `blur`, or a picture behind you: sunset, space, ocean, forest, neon, library, candy, hearts, stars,
  pizza, green screen. Your outline is found by an on-device "selfie segmentation" model.

How it works: ML Kit's face detector and selfie segmenter (both *bundled* in the app, so offline and no Google Play
services) look at a small 320px copy of the picture ~15 times a second on a background thread. The camera thread
never waits for them; it uses the latest result and does the cheap per-pixel work (warp / cut-out / draw stickers)
on every frame. Backgrounds are painted in code (no image files), cached, and blended in using the cut-out mask.
Order of operations: face warp → background → colour filter → stickers → lens warp.

Notes: while a face effect or background is on, the picture is sent at 640px on the long side (instead of 1280×720)
to keep the phone cool and the frame rate up. Expect the first half-second after switching one on to show the plain
picture while the model warms up. Adds ~10 MB to the APK for the two models. Edge quality of backgrounds is
"video call" good, not studio good: busy backgrounds and fast movement can show a halo.

## Profile (nickname + picture)
`[settings] → profile`: `[change picture]` (centre-cropped to a 256px circle), and a nickname that is shown instead of
your username in chat bubbles, reply quotes, call screens and notifications. The username itself is untouched (it is how
messages are matched to you), and is still shown under your nickname in settings. Saved to the repo as
`Config/profiles/<user>.json` + `<user>-<time>.jpg`, so the other phone sees your nickname and picture (and you see theirs).

## Message style (bubble themes)
`[settings] → message style`: pick how *your* sent messages look, TikTok-chat-theme style. Each style has its own
colour, corner roundness and a faint tiled pattern of little emoji; `bunny`, `kitty` and `bear` also put ears on
top of the bubble (the bunny is plain white with white ears and dark text, no pattern) (they lean to the side your messages sit on). Styles: `classic` (the original look, follows your
accent colour), `bunny`, `kitty`, `bear`, `hearts`, `stars`, `blossom`, `ghost`, `frog`. Your pick is saved in your
profile (`Config/profiles/<user>.json`, a `bubble` field), so the other phone sees your messages in your style, and you
see theirs in theirs. Colours adapt to light/dark mode and sit nicely over a background image. Bare stickers
(no box) are left alone. Adding a style = one more entry in the `BubbleStyle` enum in `BubbleStyle.kt`.

## Accounts (username + password)
After the voice gate you sign in. Pick a username: if it already has an account you enter its password; if nobody has
used it, you create the account (choose a password, 6+ characters) and the name is yours. Names match ignoring
case, so `Bob` and `bob` are one account, and you sign in with the exact spelling the account was created with.
- **Existing users:** a username already in use on a phone from before this update has no account file yet, so the
  first launch after updating asks that phone to set a password for it. Whoever sets the password first owns the
  name — so each person should update and set theirs soon.
- **Storage:** one file per username at `Config/accounts/<name>.json` in the repo: a random salt and a
  PBKDF2-SHA256 hash (150,000 rounds) of the password, never the password itself. Accounts are **global, not per repo**: they always live in the home repo, and the same login works in every voice-key repo (themes and profiles stay per repo). New names are claimed with a create-only commit, so two people grabbing the same name at once can't both win.
- **Staying signed in:** a successful sign-in is remembered on the phone (once, for all repos). It stays valid until the password
  is changed from another phone, you `[log out]`, or the name is changed in the debug panel.
- **Settings → account:** `[change password]` and `[log out]`. Five wrong passwords in a row lock the screen for 30
  seconds. There is **no password reset**: if somebody forgets theirs, delete their file from `Config/accounts/` in the repo
  and they can claim the name again.
- **Honest limits:** there is no server, so the check runs in the app, and the app carries the repo token. Someone who
  extracts the token from the APK can read the hashes (so pick a long password) or edit the repo directly, and messages
  themselves are still plain files. This stops people impersonating a username inside the app; it is not server-grade security.

## Deleting a message
Long-press one of your own messages → `delete` → confirm. The message file (and the photo/video/voice
file it uploaded) is removed from the repo, so it disappears on the other phone within a moment. You can only
delete your own messages (matched by name), and shared stickers are never removed. Note it's a repo commit,
so the message still exists in the repo's git history for anyone who looks there.

## Replying
Swipe a message sideways (or long-press it and pick `reply`) to reply to it — yours or theirs. A bar appears above the input showing who/what you're replying to; `[x]` cancels. Works for text, photo, video, and voice. The quote shows at the top of the reply bubble, and tapping it scrolls to the original.

## More debug tools
The debug panel also has: device/mic/speech-service info and cache sizes, `[ping github]` (latency, API rate limit, repo access), `[test message]` (sends a "[debug] test message" into the chat), `[clear cache]` (wipes the local chat and media cache), `[test voice]` (shows what the recognizer hears and whether it matches the word typed in the field), and a live event log with `[copy log]`. The log never records the secret word or what was said at the gate.

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Tap `[mic]` to
   record a voice message — the button turns into a running timer and `[stop]`; tap it again (or
   `[cancel]` to discard) to send it. First tap asks for microphone permission.
3. Photos, videos and voice clips can be up to **100 MB** each — that's GitHub's hard per-file limit for
   the Contents API. Big files are streamed from/to disk (never held in memory), show upload progress
   in the status line, and appear in your own chat immediately while they upload.
4. **Tap any photo** to open it full-screen, then tap `[save]` to store the original, full-quality file
   in your gallery (Pictures/N). Android 9 and older will ask for storage permission the first time.

## Speed
- New messages are checked for every second using ETags — when nothing changed, GitHub replies with an
  empty `304` (which doesn't count against your API rate limit).
- New message files are fetched several at a time, and the chat is cached on the phone so it shows
  instantly on launch. Downloaded photos/videos/voice clips are cached too.
- Your own messages appear instantly and are sent in the background; sending skips the extra
  "does this file exist?" round-trip and retries automatically on 409 conflicts.

## Message history (month buckets)
- Messages are filed into one subfolder per calendar month — `Msg/2026-09/...`, `Msg/2026-10/...` —
  instead of one flat folder. GitHub's Contents API only returns a folder's first 1,000 entries, so
  without this, a long-lived chat would eventually go "blind" to its own oldest messages. Splitting
  by month means each folder gets its own fresh 1,000-message budget, so this would only bite if one
  side sent over 1,000 messages in a single calendar month.
- The app only polls the *current* month's folder every second. Older months are loaded on demand:
  scroll to the top of the chat and tap **[load earlier messages]** to pull in the previous month,
  one month at a time. Nothing is ever deleted or needs manual `[clear]`ing to keep working.
- Buckets are keyed in UTC, so both phones agree on which folder a message near a month boundary
  belongs to, regardless of either person's local timezone.
- Media (photos/videos/voice) still lives in one flat `Msg/media/` folder — it's never listed, only
  fetched by the exact path a message file points to, so it isn't subject to the 1,000-entry cap.



## Seen by (read receipts)
While the chat is on screen, N tells the repo how far you've read (`Config/seen/<user>.json`, one small file per
person, only ever moves forward). Under **your** messages you'll see the small profile pictures of everyone whose
read-marker sits on that message. Tap them (or long-press → `seen by`) for a pop-up with each person's picture,
nickname, when they last read, and who hasn't yet. Each new incoming message you view is one small commit.

## Reactions
Long-press any message → tap an emoji (❤️ 😂 😮 😢 👍 👎) or `+` for a bigger set. One reaction per person per message;
tap the same emoji again to remove it. Reactions appear as chips under the bubble; tap a chip to see who reacted
(with a `[remove]` next to your own). Stored in `Config/reactions/<user>.json` (your newest 400).

## Per-repo everything
Theme/background, profiles, seen markers and reactions all live in the repo in use and are cached per repo on the phone.
