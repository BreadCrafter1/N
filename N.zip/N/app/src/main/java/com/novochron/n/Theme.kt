package com.novochron.n

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

// ---------------------------------------------------------------------------------------------
// Theming.
//
// Two layers:
//  1. Per-device look: dark/light mode, accent colour, letter colour. Stored in Store (prefs).
//  2. Shared background: a solid colour, gradient or image, stored in the repo at
//     Config/theme.json (+ Config/bg-<ts>.jpg for images). Every phone polls that file, so
//     changing the background on one phone changes it on the other.
//
// Accent/Ink/Dim/Line/Raised/Warn/Mine are getters over ThemeState (which is Compose state), so
// every existing `color = Accent` in the UI recomposes automatically when the theme changes.
// ---------------------------------------------------------------------------------------------

const val THEME_PATH = "Config/theme.json"
private const val THEME_POLL_MS = 15_000L

/** A colour with a variant tuned for each mode, so a swatch keeps enough contrast in both. */
data class Swatch(val key: String, val dark: Color, val light: Color)

val AccentSwatches = listOf(
    Swatch("green", Color(0xFF3DFF5C), Color(0xFF0B8F23)),
    Swatch("cyan", Color(0xFF35E0FF), Color(0xFF00799A)),
    Swatch("blue", Color(0xFF5C9DFF), Color(0xFF1A56C4)),
    Swatch("purple", Color(0xFFB980FF), Color(0xFF6A2BC9)),
    Swatch("pink", Color(0xFFFF6FB5), Color(0xFFC2185B)),
    Swatch("red", Color(0xFFFF5C5C), Color(0xFFC62828)),
    Swatch("orange", Color(0xFFFFA23D), Color(0xFFC25E00)),
    Swatch("yellow", Color(0xFFFFE14D), Color(0xFF8A6D00)),
    Swatch("mono", Color(0xFFFFFFFF), Color(0xFF000000)),
)

val TextSwatches = listOf(
    Swatch("pure", Color(0xFFFFFFFF), Color(0xFF000000)),
    Swatch("warm", Color(0xFFFFE9C7), Color(0xFF4A2E00)),
    Swatch("cool", Color(0xFFC9E8FF), Color(0xFF00304D)),
    Swatch("mint", Color(0xFFC8FFD4), Color(0xFF0A3D16)),
    Swatch("rose", Color(0xFFFFD3E4), Color(0xFF5A0F2C)),
    Swatch("sun", Color(0xFFFFF3A3), Color(0xFF4D4000)),
)

fun parseHexColor(s: String): Color? = try {
    val t = s.trim().let { if (it.startsWith("#")) it else "#$it" }
    if (t.length != 7 && t.length != 9) null else Color(android.graphics.Color.parseColor(t))
} catch (_: Exception) { null }

fun Color.toHex(): String = "#%06X".format(toArgb() and 0xFFFFFF)

/** [key] is a swatch key, a hex colour, or blank (= use the default). */
fun resolveColor(key: String, swatches: List<Swatch>, dark: Boolean): Color? {
    if (key.isBlank()) return null
    swatches.firstOrNull { it.key == key }?.let { return if (dark) it.dark else it.light }
    return parseHexColor(key)
}

/** The shared background. Serialised to Config/theme.json in the repo. */
data class BgTheme(
    val kind: String = "none",       // none | solid | gradient | image
    val c1: Int = 0xFF000000.toInt(),
    val c2: Int = 0xFF000000.toInt(),
    val image: String = "",          // repo path of the image when kind == "image"
    val dim: Float = 0.45f,          // how much the image is darkened (light mode: lightened) for readability
    val updated: Long = 0L,          // ms timestamp; the newest one wins when phones disagree
) {
    fun toJson(): String = JSONObject().apply {
        put("kind", kind)
        put("c1", Color(c1).toHex()); put("c2", Color(c2).toHex())
        put("image", image); put("dim", dim.toDouble()); put("updated", updated)
    }.toString(2)

    companion object {
        fun fromJson(text: String): BgTheme? = try {
            val o = JSONObject(text)
            BgTheme(
                kind = o.optString("kind", "none"),
                c1 = parseHexColor(o.optString("c1", "#000000"))?.toArgb() ?: 0xFF000000.toInt(),
                c2 = parseHexColor(o.optString("c2", "#000000"))?.toArgb() ?: 0xFF000000.toInt(),
                image = o.optString("image", ""),
                dim = o.optDouble("dim", 0.45).toFloat().coerceIn(0f, 0.9f),
                updated = o.optLong("updated", 0L),
            )
        } catch (_: Exception) { null }
    }
}

object ThemeState {
    var dark by mutableStateOf(true)
    var accent by mutableStateOf<Color?>(null)     // null = the default for the current mode
    var text by mutableStateOf<Color?>(null)
    var bg by mutableStateOf(BgTheme())
    var bgImage by mutableStateOf<ImageBitmap?>(null)

    val hasImageBg: Boolean get() = bg.kind == "image" && bgImage != null

    fun load(store: Store) {
        dark = store.darkMode
        refreshColors(store)
        BgTheme.fromJson(store.bgThemeJson)?.let { bg = it }
    }

    /** Re-resolves accent/letter colours from their saved keys (call after changing mode or a key). */
    fun refreshColors(store: Store) {
        accent = resolveColor(store.accentKey, AccentSwatches, dark)
        text = resolveColor(store.textKey, TextSwatches, dark)
    }
}

// ---- the colours the rest of the UI uses (same names as before, now theme-aware) ----
val Accent: Color get() = ThemeState.accent ?: if (ThemeState.dark) Color(0xFF3DFF5C) else Color(0xFF0B8F23)
val Ink: Color get() = ThemeState.text ?: if (ThemeState.dark) Color(0xFFE8E8E8) else Color(0xFF1A1A1A)
val Dim: Color get() = ThemeState.text?.copy(alpha = 0.6f) ?: if (ThemeState.dark) Color(0xFF8C8C8C) else Color(0xFF5F5F5F)
val Line: Color get() = if (ThemeState.dark) Color(0xFF262626) else Color(0xFFCFCFCF)
val Warn: Color get() = if (ThemeState.dark) Color(0xFFFF5C5C) else Color(0xFFC62828)
/** The app title: always a soft grey, tuned per mode so it stays readable on any background. */
val TitleGrey: Color get() = if (ThemeState.dark) Color(0xFFA8A8A8) else Color(0xFF6B6B6B)
/** Plain page background when no custom background is set. */
val Bg: Color get() = if (ThemeState.dark) Color.Black else Color.White

private val panelAlpha: Float get() = if (ThemeState.hasImageBg) 0.82f else 1f
val Raised: Color get() = (if (ThemeState.dark) Color(0xFF101010) else Color(0xFFF1F1F1)).copy(alpha = panelAlpha)
val Mine: Color get() = lerp(if (ThemeState.dark) Color(0xFF101010) else Color(0xFFF1F1F1), Accent, 0.18f).copy(alpha = panelAlpha)

/** The themed page background: plain black/white, a custom solid/gradient, or an image with a readability scrim. */
@Composable
fun ThemedBackground() {
    val bg = ThemeState.bg
    val brush: Brush = when (bg.kind) {
        "solid" -> SolidColor(Color(bg.c1))
        "gradient" -> Brush.verticalGradient(listOf(Color(bg.c1), Color(bg.c2)))
        else -> SolidColor(Bg)
    }
    Box(Modifier.fillMaxSize().background(brush)) {
        val img = ThemeState.bgImage
        if (bg.kind == "image" && img != null) {
            Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background((if (ThemeState.dark) Color.Black else Color.White).copy(alpha = bg.dim)))
        }
    }
}

/** Keeps the background in step with Config/theme.json in the repo, and publishes changes to it. */
object ThemeSync {
    private fun cacheFileFor(ctx: Context, imagePath: String) =
        File(ctx.cacheDir, "n/bg/" + imagePath.substringAfterLast('/'))

    /** Loads the background image (downloading it once, then from cache) into [ThemeState]. */
    suspend fun loadImage(ctx: Context, client: GitHubClient?, repo: RepoRef?, imagePath: String) {
        if (imagePath.isBlank()) { ThemeState.bgImage = null; return }
        val f = cacheFileFor(ctx, imagePath)
        try {
            if (!f.exists() || f.length() == 0L) {
                if (client == null || repo == null) return
                if (!client.downloadFile(imagePath, repo, f)) { DebugLog.add("theme: image $imagePath missing in repo"); return }
            }
            val bmp = withContext(Dispatchers.IO) { decodeSampled(f, 1800) }
            ThemeState.bgImage = bmp?.asImageBitmap()
        } catch (e: Exception) { DebugLog.add("theme: image load failed: ${e.message?.take(60)}") }
    }

    /** Switches this phone to [t] (already known to be the newest) and remembers it for next launch. */
    suspend fun applyLocally(ctx: Context, store: Store, client: GitHubClient?, repo: RepoRef?, t: BgTheme) {
        ThemeState.bg = t
        store.bgThemeJson = t.toJson()
        if (t.kind == "image") loadImage(ctx, client, repo, t.image) else ThemeState.bgImage = null
    }

    /** Runs while the app is unlocked: restores the cached image, then polls the repo for newer themes. */
    suspend fun loop(ctx: Context, store: Store, client: GitHubClient?, repo: RepoRef?) {
        // The background belongs to ONE repo. Drop whatever the previous repo (or the launch default)
        // left in memory and start from this repo's own saved theme, or plain black/white if it has none.
        ThemeState.bg = BgTheme.fromJson(store.bgThemeJson) ?: BgTheme()
        ThemeState.bgImage = null
        if (ThemeState.bg.kind == "image") loadImage(ctx, client, repo, ThemeState.bg.image)
        if (client == null || repo == null) return
        while (true) {
            try {
                val text = client.readFile(THEME_PATH, repo)
                val remote = text?.let { BgTheme.fromJson(it) }
                if (remote != null && remote.updated > ThemeState.bg.updated) {
                    DebugLog.add("theme: synced from repo (${remote.kind})")
                    applyLocally(ctx, store, client, repo, remote)
                }
            } catch (e: Exception) { DebugLog.add("theme sync error: ${e.message?.take(60)}") }
            delay(THEME_POLL_MS)
        }
    }

    /**
     * Publishes [theme] (optionally with a new [imageFile]) to the repo, then applies it here.
     * Returns null on success, or an error message.
     */
    suspend fun publish(
        ctx: Context, store: Store, client: GitHubClient?, repo: RepoRef?,
        theme: BgTheme, imageFile: File? = null
    ): String? {
        if (client == null || repo == null) return "No repo/token configured."
        val now = System.currentTimeMillis()
        val old = ThemeState.bg.image
        return try {
            var t = theme.copy(updated = now)
            if (imageFile != null) {
                val path = "Config/bg-$now.jpg"
                client.commitFileStream(path, imageFile, "n: background", repo)
                val cached = cacheFileFor(ctx, path)
                cached.parentFile?.mkdirs()
                imageFile.copyTo(cached, overwrite = true)
                t = t.copy(kind = "image", image = path)
            }
            client.writeFile(THEME_PATH, t.toJson(), "n: theme", repo)
            applyLocally(ctx, store, client, repo, t)
            // Best-effort tidy-up: don't leave every old background sitting in the repo.
            if (old.isNotBlank() && old != t.image) {
                try {
                    client.listFiles("Config", repo).firstOrNull { it.path == old }
                        ?.let { client.deleteFile(it.path, it.sha, "n: remove old background", repo) }
                } catch (_: Exception) {}
            }
            null
        } catch (e: Exception) {
            DebugLog.add("theme publish failed: ${e.message?.take(60)}")
            if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error"
        }
    }
}
