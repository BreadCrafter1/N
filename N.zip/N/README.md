# N

A tiny Novochron-styled app: text, photo, video, and voice messages with one other person, using a
shared GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving
is polling the same folder.

## Setting the GitHub token
The token used to talk to the repo is no longer written into any source file, so it can't get
swept up in a `git push` and auto-revoked by GitHub's secret scanning.

- **Building locally:** copy `local.properties.example` to `local.properties` (already
  git-ignored) and paste your token in place of `ghp_your_token_here`.
- **Building via the "Build N" GitHub Actions workflow:** add the token as a repo secret instead
  — repo → **Settings → Secrets and variables → Actions → New repository secret**, name it
  `N_GH_TOKEN`, paste the token as the value. Then, in the workflow file's build step (the one
  that runs `./gradlew assembleDebug` or similar), add:
  ```yaml
  env:
    N_GH_TOKEN: ${{ secrets.N_GH_TOKEN }}
  ```
  (This project's workflow file wasn't part of what I edited — add that `env:` block to yours if
  it isn't there already, or ask me to write the whole workflow file if you'd rather start over.)

Either way, if you ever rotate the token, there's no source file to edit — just update
`local.properties` and/or the `N_GH_TOKEN` secret.

## Fix: "There was a problem parsing the package"
This happened because every CI build was signed with a throwaway, machine-generated debug
keystore, so each build's signature differed from the last one on your phone — Android shows
that generic parsing error for a signature mismatch on install-over-install, even though the
APK itself is fine. `app/debug.keystore` is now checked into the repo and every build (local or
CI) signs with it, so this won't happen again.

**One-time step:** since your currently-installed copy was signed with the old throwaway key,
this next build still won't install over it. Uninstall the app once, then install the new build
as usual — after that, updates will install cleanly over each other.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Voice gate + debug panel
- On every launch the app shows a pitch-black screen with the mic open. It stays that way until the secret word is spoken; then the chat appears. Nothing is remembered between launches.
- The secret word is **not in the app**. It lives in the shared repo at `Config/secret.txt` and is fetched at launch. If it can't be fetched (offline, file missing), the gate stays shut.
- **First-time setup:** tap the invisible spot at the top-left corner **5 times quickly** to open the debug panel, type `Operation`, and hit `[save]`. That creates `Config/secret.txt` in the repo. Change the word the same way any time.
- Your name is set once on first launch (there's no `[name]` button anymore). To change it later, open the debug panel and use `[save name]`. Messages you sent under the old name will show up on the other side, since they're matched by name.
- The debug panel also has `[lock now]` (re-locks the app) and shows repo/branch/version/token status.
- Speech recognition uses the phone's built-in recognizer (Google's on most phones), so the mic permission must be granted and the device needs a speech service.

## Calling
- `[call]` / `[video call]` at the top start a voice or video call. It rings everyone else who has
  the app open on the shared repo; whoever's around can `[accept]`, and a third person can join an
  already-active call the same way — up to 3 people total. There's no push notification, so calls
  only work while everyone involved has the chat open.
- Signaling (who's calling whom, the offer/answer handshakes) goes through the same shared repo as
  everything else, in a `Call/` folder — no separate server. Each phone opens a direct WebRTC
  connection to every other phone in the call (mesh style — fine for 3 people, not meant to scale
  past that), with Google's public STUN servers helping each side find its way through NAT. On
  [accept], you're asked for microphone (and camera, for a video call) permission if you haven't
  granted it yet.
- During a call: `[mute]`, `[flip]` (front/back camera, video calls only), `[share]` (screenshare,
  see below), and `[end]`. An unanswered call gives up after 45 seconds.
- STUN alone can't always punch through every network (a minority of carrier/corporate NATs need a
  TURN relay instead) — if calls reliably fail to connect on a particular network, that's the likely
  cause, and a TURN server would need to be added to fix it.

## Screenshare
- `[share]` during a call asks Android's own system permission dialog to confirm sharing *your*
  screen — the same dialog every screen-recording/casting app uses. It only ever captures the
  screen of the phone that tapped it; there's no way to use this to see anyone else's screen.
- Once granted, everyone else in the call sees your screen full-size, with everyone's camera
  feeds shown as small thumbnails along the top. `[stop share]` ends it and switches back to the
  normal camera view.
- Because of an Android 14+ requirement, sharing briefly starts a small foreground service (you'll
  see a persistent "your screen is being shared" notification the whole time it's on — Android
  requires this and it can't be hidden, which is intentional: it means screen sharing can never
  happen silently on your own phone).

## Replying
Swipe a message sideways (or long-press it) to reply to it — yours or theirs. A bar appears above the input showing who/what you're replying to; `[x]` cancels. Works for text, photo, video, and voice. The quote shows at the top of the reply bubble, and tapping it scrolls to the original.

## More debug tools
The debug panel also has: device/mic/speech-service info and cache sizes, `[ping github]` (latency, API rate limit, repo access), `[test message]` (sends a "[debug] test message" into the chat), `[clear cache]` (wipes the local chat and media cache), `[test voice]` (shows what the recognizer hears and whether it matches the word typed in the field), and a live event log with `[copy log]`. The log never records the secret word or what was said at the gate.

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Tap `[mic]` to
   record a voice message — the button turns into a running timer and `[stop]`; tap it again (or
   `[cancel]` to discard) to send it. First tap asks for microphone permission.
3. Photos, videos and voice clips can be up to **100 MB** each — that's GitHub's hard per-file limit for
   the Contents API. Big files are streamed from/to disk (never held in memory), show upload progress
   in the status line, and appear in your own chat immediately while they upload.
4. **Tap any photo** to open it full-screen, then tap `[save]` to store the original, full-quality file
   in your gallery (Pictures/N). Android 9 and older will ask for storage permission the first time.

## Speed
- New messages are checked for every second using ETags — when nothing changed, GitHub replies with an
  empty `304` (which doesn't count against your API rate limit).
- New message files are fetched several at a time, and the chat is cached on the phone so it shows
  instantly on launch. Downloaded photos/videos/voice clips are cached too.
- Your own messages appear instantly and are sent in the background; sending skips the extra
  "does this file exist?" round-trip and retries automatically on 409 conflicts.
- Known limit: GitHub only returns the first 1,000 files of a folder, so the chat is capped at roughly
  1,000 messages until you `[clear]` it.


