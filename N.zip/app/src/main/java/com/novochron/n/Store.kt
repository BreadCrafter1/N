package com.novochron.n

import android.content.Context

/** Everything N remembers between launches: the shared repo, the token, and your display name. */
class Store(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("n_prefs", Context.MODE_PRIVATE)

    var repo: String
        get() = prefs.getString("repo", "") ?: ""
        set(v) { prefs.edit().putString("repo", v.trim()).apply() }

    var branch: String
        get() = prefs.getString("branch", "main") ?: "main"
        set(v) { prefs.edit().putString("branch", v.trim().ifBlank { "main" }).apply() }

    var token: String
        get() = prefs.getString("token", "") ?: ""
        set(v) { prefs.edit().putString("token", v.trim()).apply() }

    var name: String
        get() = prefs.getString("name", "") ?: ""
        set(v) { prefs.edit().putString("name", v.trim()).apply() }
}
