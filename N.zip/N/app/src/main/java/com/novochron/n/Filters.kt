package com.novochron.n

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.os.SystemClock
import org.webrtc.JavaI420Buffer
import org.webrtc.VideoFrame
import org.webrtc.VideoProcessor
import org.webrtc.VideoSink
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------------------------------------
// Video call effects.
//
// Every camera frame passes through FilterProcessor before it is encoded, so the other person
// sees the effect and so does your own preview. Three independent things can be switched on at
// once (like Messenger):
//
//   VideoFx  - whole-picture looks: colour grades (mono, sepia, thermal...) and lens warps (swirl...)
//   FaceFx   - face effects: silly face warps (big eyes...) and stickers (dog ears, shades, crown...)
//   BgFx     - background replacement: blur, or a picture/pattern behind you
//
// Face effects and backgrounds need on-device ML (ML Kit face detection + selfie segmentation, see
// FaceFx.kt). That runs on a background thread a few times a second on a small copy of the frame;
// the capture thread only does the cheap per-pixel work, using the latest result.
// With everything set to "none" the frame is passed straight through without being touched.
// ---------------------------------------------------------------------------------------------

enum class VideoFx(val label: String, val icon: String) {
    NONE("none", "🚫"), MONO("mono", "⚫"), SEPIA("sepia", "🍂"), WARM("warm", "🔥"), COOL("cool", "❄️"),
    NEGATIVE("negative", "🔄"), VIGNETTE("vignette", "🔘"), PIXEL("pixel", "👾"),
    NOIR("noir", "🎬"), VIVID("vivid", "🌈"), FADE("fade", "🌫️"), DREAM("dream", "🦄"),
    POSTER("poster", "🎨"), THERMAL("thermal", "🌡️"), MATRIX("matrix", "💻"), SKETCH("sketch", "✏️"),
    MIRROR("mirror", "↔️"), SWIRL("swirl", "🌀"), FISHEYE("fisheye", "🐟"), WAVY("wavy", "🌊");

    /** Lens effects that move pixels around (as opposed to colour grades). */
    val geometric: Boolean get() = this == MIRROR || this == SWIRL || this == FISHEYE || this == WAVY

    fun next(): VideoFx = values()[(ordinal + 1) % values().size]
}

enum class FaceFx(val label: String, val icon: String, val warp: Boolean = false) {
    NONE("none", "🚫"),
    // stickers drawn on the face
    DOG("dog", "🐶"), CAT("cat", "🐱"), BUNNY("bunny", "🐰"), CLOWN("clown", "🤡"),
    SHADES("shades", "😎"), STACHE("stache", "🧔"), CROWN("crown", "👑"), DEVIL("devil", "😈"),
    ANGEL("angel", "😇"), HEARTS("hearts", "😍"), PARTY("party", "🎉"), ALIEN("alien", "👽"),
    // silly faces: the face itself is stretched / squished
    BIG_EYES("big eyes", "👀", true), BIG_NOSE("big nose", "👃", true), BIG_MOUTH("big mouth", "👄", true),
    SQUISH("squish", "😵", true), CHUBBY("chubby", "🐡", true), GOOFY("goofy", "😜", true);
}

enum class BgFx(val label: String, val icon: String) {
    NONE("none", "🚫"), BLUR("blur", "🌫️"),
    SUNSET("sunset", "🌅"), SPACE("space", "🌌"), OCEAN("ocean", "🌊"), FOREST("forest", "🌲"),
    SYNTHWAVE("neon", "🌃"), BOOKS("library", "📚"),
    CANDY("candy", "🍭"), HEARTS("hearts", "💖"), STARS("stars", "⭐"), PIZZA("pizza", "🍕"),
    GREEN("green screen", "💚");
}

/** Frames bigger than this (long side) are shrunk first when a face effect or background is on. */
private const val FX_MAX_SIDE = 640

class FilterProcessor : VideoProcessor {
    @Volatile var mode: VideoFx = VideoFx.NONE
    @Volatile var face: FaceFx = FaceFx.NONE
    @Volatile var bg: BgFx = BgFx.NONE
    @Volatile private var sink: VideoSink? = null
    private val pipe = FxPipeline()

    override fun setSink(s: VideoSink?) { sink = s }
    override fun onCapturerStarted(success: Boolean) {}
    override fun onCapturerStopped() {}

    override fun onFrameCaptured(frame: VideoFrame) {
        val s = sink ?: return
        val m = mode; val f = face; val b = bg
        if (m == VideoFx.NONE && f == FaceFx.NONE && b == BgFx.NONE) { s.onFrame(frame); return }
        var src: VideoFrame.I420Buffer? = try { frame.buffer.toI420() } catch (_: Exception) { null }
        if (src == null) { s.onFrame(frame); return }
        if ((f != FaceFx.NONE || b != BgFx.NONE) && max(src.width, src.height) > FX_MAX_SIDE) {
            val small = shrink(src)
            if (small != null) { src.release(); src = small }
        }
        val out = try { pipe.run(src, frame.rotation, m, f, b) } catch (_: Exception) { null }
        src.release()
        if (out == null) { s.onFrame(frame); return }
        val filtered = VideoFrame(out, frame.rotation, frame.timestampNs)
        s.onFrame(filtered)
        filtered.release()
    }

    /** Free the ML models and scratch bitmaps. Call once the camera has stopped. */
    fun release() { pipe.release() }

    private fun shrink(src: VideoFrame.I420Buffer): VideoFrame.I420Buffer? = try {
        val w = src.width; val h = src.height
        val sc = FX_MAX_SIDE.toFloat() / max(w, h)
        val nw = max(2, ((w * sc).toInt() / 2) * 2)
        val nh = max(2, ((h * sc).toInt() / 2) * 2)
        val scaled = src.cropAndScale(0, 0, w, h, nw, nh)
        val out = scaled.toI420()
        scaled.release()
        out
    } catch (_: Exception) { null }
}

// ---------------------------------------------------------------------------------------------
// One frame as three plain byte arrays, plus helpers for talking about it "upright".
//
// The camera hands us the sensor's picture plus a rotation (0/90/180/270) saying how far it must
// be turned clockwise to look upright. Everything in the ML code is upright; everything we edit
// is in buffer orientation. toBufX/toBufY and toUx/toUy convert between the two.
// ---------------------------------------------------------------------------------------------
internal class FxFrame(val w: Int, val h: Int, val rot: Int, val y: ByteArray, val u: ByteArray, val v: ByteArray) {
    val cw = (w + 1) / 2
    val ch = (h + 1) / 2
    val uw: Int get() = if (rot == 90 || rot == 270) h else w
    val uh: Int get() = if (rot == 90 || rot == 270) w else h

    /** Upright point -> buffer point. */
    fun toBufX(ux: Float, uy: Float): Float = when (rot) { 90 -> uy; 180 -> w - ux; 270 -> w - uy; else -> ux }
    fun toBufY(ux: Float, uy: Float): Float = when (rot) { 90 -> h - ux; 180 -> h - uy; 270 -> ux; else -> uy }
    /** Buffer point -> upright point. */
    fun toUx(px: Float, py: Float): Float = when (rot) { 90 -> h - py; 180 -> w - px; 270 -> py; else -> px }
    fun toUy(px: Float, py: Float): Float = when (rot) { 90 -> px; 180 -> h - py; 270 -> w - px; else -> py }

    fun toBuffer(): JavaI420Buffer {
        val dst = JavaI420Buffer.allocate(w, h)
        writePlane(dst.dataY, dst.strideY, w, h, y)
        writePlane(dst.dataU, dst.strideU, cw, ch, u)
        writePlane(dst.dataV, dst.strideV, cw, ch, v)
        return dst
    }

    companion object {
        fun from(src: VideoFrame.I420Buffer, rot: Int): FxFrame {
            val w = src.width; val h = src.height
            val cw = (w + 1) / 2; val ch = (h + 1) / 2
            return FxFrame(
                w, h, rot,
                readPlane(src.dataY, src.strideY, w, h),
                readPlane(src.dataU, src.strideU, cw, ch),
                readPlane(src.dataV, src.strideV, cw, ch),
            )
        }

        private fun readPlane(buf: ByteBuffer, stride: Int, w: Int, h: Int): ByteArray {
            val out = ByteArray(w * h)
            val b = buf.duplicate()
            for (r in 0 until h) { b.position(r * stride); b.get(out, r * w, w) }
            return out
        }

        private fun writePlane(buf: ByteBuffer, stride: Int, w: Int, h: Int, data: ByteArray) {
            val b = buf.duplicate()
            for (r in 0 until h) { b.position(r * stride); b.put(data, r * w, w) }
        }
    }
}

/** Matrix that maps upright coordinates onto a w x h buffer-orientation bitmap. */
internal fun fxUprightMatrix(w: Int, h: Int, rot: Int): Matrix {
    val wf = w.toFloat(); val hf = h.toFloat()
    val v = when (rot) {
        90 -> floatArrayOf(0f, 1f, 0f, -1f, 0f, hf, 0f, 0f, 1f)
        180 -> floatArrayOf(-1f, 0f, wf, 0f, -1f, hf, 0f, 0f, 1f)
        270 -> floatArrayOf(0f, -1f, wf, 1f, 0f, 0f, 0f, 0f, 1f)
        else -> floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    }
    val m = Matrix(); m.setValues(v)
    return m
}

internal fun fxRgbToY(r: Int, g: Int, b: Int) = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
internal fun fxRgbToU(r: Int, g: Int, b: Int) = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
internal fun fxRgbToV(r: Int, g: Int, b: Int) = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128

internal class FxPlanes(val y: ByteArray, val u: ByteArray, val v: ByteArray)

// ---------------------------------------------------------------------------------------------
// The per-frame pipeline. Order matters:
//   face warp -> background -> colour grade -> face stickers -> lens warp
// (the lens warp goes last so it bends the stickers and the background along with everything else.)
// ---------------------------------------------------------------------------------------------
internal class FxPipeline {
    private val tracker = FxTracker()
    private val art = FxArt()
    private var lastSubmit = 0L
    private var smooth: FaceGeo? = null

    // lens-warp lookup tables (dest pixel -> source pixel), rebuilt only when mode/size/rotation change
    private var lutKey = ""
    private var lutY: IntArray? = null
    private var lutC: IntArray? = null

    // cached picture-backgrounds, as ready-to-blend planes
    private var bgKey = ""
    private var bgPlanes: FxPlanes? = null

    // sticker layer
    private var ovBmp: Bitmap? = null
    private var ovCanvas: Canvas? = null
    private var ovPx: IntArray? = null

    fun run(src: VideoFrame.I420Buffer, rot: Int, mode: VideoFx, face: FaceFx, bg: BgFx): JavaI420Buffer {
        val f = FxFrame.from(src, rot)
        val now = SystemClock.uptimeMillis()
        val wantFace = face != FaceFx.NONE
        val wantSeg = bg != BgFx.NONE

        // Hand a small copy of this frame to the ML thread at most ~15x a second, and only if it is idle.
        if ((wantFace || wantSeg) && now - lastSubmit >= 60L && tracker.submit(f, wantFace, wantSeg)) lastSubmit = now

        val geo = if (wantFace) currentFace(now) else { smooth = null; null }
        if (geo != null && face.warp) faceWarp(f, face, geo)

        if (wantSeg) {
            val mk = tracker.mask
            if (mk != null && mk.rot == f.rot && now - mk.at < 1500L) background(f, bg, mk)
        }

        if (mode != VideoFx.NONE && !mode.geometric) colorFilter(f, mode)
        if (geo != null && !face.warp) overlay(f, face, geo, now / 1000f)
        if (mode.geometric) geometric(f, mode)
        return f.toBuffer()
    }

    fun release() {
        tracker.close()
        ovBmp?.recycle(); ovBmp = null; ovCanvas = null; ovPx = null
    }

    /** Latest detected face, eased frame to frame so stickers glide instead of jittering. */
    private fun currentFace(now: Long): FaceGeo? {
        val t = tracker.face
        if (t == null || now - t.at > 700L) { smooth = null; return null }
        val s = smooth
        val n = if (s == null) t else FaceGeo.lerp(s, t, 0.5f)
        smooth = n
        return n
    }

    // ------------------------------------------------------------------ colour grades

    private fun clamp(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    private fun colorFilter(f: FxFrame, mode: VideoFx) {
        val y = f.y; val u = f.u; val v = f.v
        val w = f.w; val h = f.h; val cw = f.cw; val ch = f.ch
        when (mode) {
            VideoFx.MONO -> { u.fill(128.toByte()); v.fill(128.toByte()) }
            VideoFx.SEPIA -> { u.fill(108.toByte()); v.fill(150.toByte()) }
            VideoFx.WARM -> for (i in u.indices) {
                u[i] = clamp((u[i].toInt() and 0xFF) - 10).toByte()
                v[i] = clamp((v[i].toInt() and 0xFF) + 12).toByte()
            }
            VideoFx.COOL -> for (i in u.indices) {
                u[i] = clamp((u[i].toInt() and 0xFF) + 12).toByte()
                v[i] = clamp((v[i].toInt() and 0xFF) - 10).toByte()
            }
            VideoFx.NEGATIVE -> {
                for (i in y.indices) y[i] = (255 - (y[i].toInt() and 0xFF)).toByte()
                for (i in u.indices) {
                    u[i] = clamp(256 - (u[i].toInt() and 0xFF)).toByte()
                    v[i] = clamp(256 - (v[i].toInt() and 0xFF)).toByte()
                }
            }
            VideoFx.VIGNETTE -> {
                val dx2 = FloatArray(w) { val d = (it - w / 2f) / (w / 2f); d * d }
                for (r in 0 until h) {
                    val dy = (r - h / 2f) / (h / 2f); val dy2 = dy * dy
                    val base = r * w
                    for (c in 0 until w) {
                        val d2 = (dx2[c] + dy2) / 2f
                        val k = (1f - 0.95f * d2 * d2 * 1.6f).coerceIn(0.08f, 1f)
                        y[base + c] = ((y[base + c].toInt() and 0xFF) * k).toInt().toByte()
                    }
                }
            }
            VideoFx.PIXEL -> {
                val b = 16
                for (r in 0 until h) {
                    val rr = r - r % b
                    for (c in 0 until w) y[r * w + c] = y[rr * w + (c - c % b)]
                }
                val cb = b / 2
                for (r in 0 until ch) {
                    val rr = r - r % cb
                    for (c in 0 until cw) {
                        u[r * cw + c] = u[rr * cw + (c - c % cb)]
                        v[r * cw + c] = v[rr * cw + (c - c % cb)]
                    }
                }
            }
            VideoFx.NOIR -> {
                for (i in y.indices) y[i] = clamp(((y[i].toInt() and 0xFF) - 120) * 14 / 10 + 114).toByte()
                u.fill(128.toByte()); v.fill(128.toByte())
            }
            VideoFx.VIVID -> {
                for (i in y.indices) y[i] = clamp(128 + ((y[i].toInt() and 0xFF) - 128) * 11 / 10).toByte()
                for (i in u.indices) {
                    u[i] = clamp(128 + ((u[i].toInt() and 0xFF) - 128) * 3 / 2).toByte()
                    v[i] = clamp(128 + ((v[i].toInt() and 0xFF) - 128) * 3 / 2).toByte()
                }
            }
            VideoFx.FADE -> {
                for (i in y.indices) y[i] = clamp(24 + (y[i].toInt() and 0xFF) * 4 / 5).toByte()
                for (i in u.indices) {
                    u[i] = clamp(128 + ((u[i].toInt() and 0xFF) - 128) * 7 / 10).toByte()
                    v[i] = clamp(128 + ((v[i].toInt() and 0xFF) - 128) * 7 / 10).toByte()
                }
            }
            VideoFx.DREAM -> {
                for (i in y.indices) y[i] = clamp(18 + (y[i].toInt() and 0xFF) * 9 / 10).toByte()
                for (i in u.indices) {
                    u[i] = clamp(128 + ((u[i].toInt() and 0xFF) - 128) * 85 / 100 + 6).toByte()
                    v[i] = clamp(128 + ((v[i].toInt() and 0xFF) - 128) * 85 / 100 + 12).toByte()
                }
            }
            VideoFx.POSTER -> {
                for (i in y.indices) y[i] = (16 + (((y[i].toInt() and 0xFF) * 5) shr 8) * 55).toByte()
                for (i in u.indices) {
                    u[i] = clamp(128 + ((u[i].toInt() and 0xFF) - 128) * 3 / 2).toByte()
                    v[i] = clamp(128 + ((v[i].toInt() and 0xFF) - 128) * 3 / 2).toByte()
                }
            }
            VideoFx.THERMAL -> {
                // false colour by brightness; chroma first because it reads the untouched luma
                for (cy in 0 until ch) {
                    val ry = min(h - 1, cy * 2)
                    for (cx in 0 until cw) {
                        val idx = y[ry * w + min(w - 1, cx * 2)].toInt() and 0xFF
                        u[cy * cw + cx] = FxLuts.thermalU[idx].toByte()
                        v[cy * cw + cx] = FxLuts.thermalV[idx].toByte()
                    }
                }
                for (i in y.indices) y[i] = FxLuts.thermalY[y[i].toInt() and 0xFF].toByte()
            }
            VideoFx.MATRIX -> {
                for (i in y.indices) y[i] = clamp((y[i].toInt() and 0xFF) * 115 / 100 + 4).toByte()
                u.fill(90.toByte()); v.fill(80.toByte())
            }
            VideoFx.SKETCH -> {
                val y0 = y.copyOf()
                y.fill(235.toByte())
                for (r in 1 until h - 1) {
                    val row = r * w
                    for (c in 1 until w - 1) {
                        val i = row + c
                        val gx = abs((y0[i + 1].toInt() and 0xFF) - (y0[i - 1].toInt() and 0xFF))
                        val gy = abs((y0[i + w].toInt() and 0xFF) - (y0[i - w].toInt() and 0xFF))
                        y[i] = (235 - min(219, (gx + gy) * 3)).toByte()
                    }
                }
                u.fill(128.toByte()); v.fill(128.toByte())
            }
            else -> {}
        }
    }

    // ------------------------------------------------------------------ lens warps (swirl, mirror...)

    private fun geometric(f: FxFrame, mode: VideoFx) {
        val key = "${mode.ordinal}:${f.w}x${f.h}:${f.rot}"
        if (key != lutKey || lutY == null || lutC == null) buildLut(f, mode, key)
        val ly = lutY ?: return
        val lc = lutC ?: return
        val y0 = f.y.copyOf(); val u0 = f.u.copyOf(); val v0 = f.v.copyOf()
        for (i in ly.indices) f.y[i] = y0[ly[i]]
        for (i in lc.indices) { f.u[i] = u0[lc[i]]; f.v[i] = v0[lc[i]] }
    }

    private fun buildLut(f: FxFrame, mode: VideoFx, key: String) {
        val w = f.w; val h = f.h
        val uw = f.uw.toFloat(); val uh = f.uh.toFloat()
        val o = FloatArray(2)
        val ly = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val px = x + 0.5f; val py = y + 0.5f
                geomSource(mode, f.toUx(px, py), f.toUy(px, py), uw, uh, o)
                val sx = f.toBufX(o[0], o[1]).toInt().coerceIn(0, w - 1)
                val sy = f.toBufY(o[0], o[1]).toInt().coerceIn(0, h - 1)
                ly[y * w + x] = sy * w + sx
            }
        }
        val cw = f.cw; val ch = f.ch
        val lc = IntArray(cw * ch)
        for (cy in 0 until ch) {
            for (cx in 0 until cw) {
                val s = ly[min(h - 1, cy * 2) * w + min(w - 1, cx * 2)]
                val sx = min(cw - 1, (s % w) / 2); val sy = min(ch - 1, (s / w) / 2)
                lc[cy * cw + cx] = sy * cw + sx
            }
        }
        lutY = ly; lutC = lc; lutKey = key
    }

    /** For an upright destination point, where in the upright source picture should its colour come from? */
    private fun geomSource(mode: VideoFx, ux: Float, uy: Float, uw: Float, uh: Float, o: FloatArray) {
        var sx = ux; var sy = uy
        val cx = uw / 2f; val cy = uh / 2f
        val m = min(uw, uh)
        val dx = ux - cx; val dy = uy - cy
        when (mode) {
            VideoFx.MIRROR -> if (ux > cx) sx = uw - ux
            VideoFx.SWIRL -> {
                val r = m * 0.55f
                val d = sqrt(dx * dx + dy * dy)
                if (d < r) {
                    val t = 1f - d / r
                    val a = 2.4f * t * t
                    val cs = cos(a); val sn = sin(a)
                    sx = cx + dx * cs - dy * sn
                    sy = cy + dx * sn + dy * cs
                }
            }
            VideoFx.FISHEYE -> {
                val r = m * 0.62f
                val d2 = dx * dx + dy * dy
                if (d2 < r * r) {
                    val k = 1f - 0.6f * (1f - d2 / (r * r))
                    sx = cx + dx * k; sy = cy + dy * k
                }
            }
            VideoFx.WAVY -> sx = ux + m * 0.025f * sin(uy * 6.2832f / (uh * 0.28f))
            else -> {}
        }
        o[0] = sx.coerceIn(0f, uw - 1f)
        o[1] = sy.coerceIn(0f, uh - 1f)
    }

    // ------------------------------------------------------------------ silly faces (local warps)

    private fun faceWarp(f: FxFrame, fx: FaceFx, g: FaceGeo) {
        val uw = f.uw.toFloat(); val uh = f.uh.toFloat()
        val d = hypot((g.e2x - g.e1x) * uw, (g.e2y - g.e1y) * uh).coerceAtLeast(8f)
        val y0 = f.y.copyOf(); val u0 = f.u.copyOf(); val v0 = f.v.copyOf()

        fun bulge(gx: Float, gy: Float, r: Float, s: Float) {
            val cx = f.toBufX(gx * uw, gy * uh); val cy = f.toBufY(gx * uw, gy * uh)
            bulgePlane(y0, f.y, f.w, f.h, cx, cy, r, s)
            bulgePlane(u0, f.u, f.cw, f.ch, cx / 2f, cy / 2f, r / 2f, s)
            bulgePlane(v0, f.v, f.cw, f.ch, cx / 2f, cy / 2f, r / 2f, s)
        }

        when (fx) {
            FaceFx.BIG_EYES -> { bulge(g.e1x, g.e1y, d * 0.6f, 0.65f); bulge(g.e2x, g.e2y, d * 0.6f, 0.65f) }
            FaceFx.BIG_NOSE -> bulge(g.nx, g.ny, d * 0.75f, 0.7f)
            FaceFx.BIG_MOUTH -> bulge(g.mx, g.my, max(g.mw * uw * 0.75f, d * 0.6f), 0.65f)
            FaceFx.SQUISH -> bulge((g.e1x + g.e2x + g.mx * 2f) / 4f, (g.e1y + g.e2y + g.my * 2f) / 4f, d * 1.6f, -0.55f)
            FaceFx.CHUBBY -> bulge(g.nx, g.ny, d * 1.8f, 0.5f)
            FaceFx.GOOFY -> {
                bulge(g.e1x, g.e1y, d * 0.6f, 0.7f); bulge(g.e2x, g.e2y, d * 0.6f, 0.7f)
                bulge(g.mx, g.my, d * 0.7f, -0.6f)
            }
            else -> {}
        }
    }

    /** s > 0 magnifies around (cx, cy); s < 0 shrinks. Reads [src], writes [dst]. */
    private fun bulgePlane(src: ByteArray, dst: ByteArray, pw: Int, ph: Int, cx: Float, cy: Float, r: Float, s: Float) {
        if (r < 2f) return
        val x0 = max(0, (cx - r).toInt()); val x1 = min(pw - 1, (cx + r).toInt() + 1)
        val y0 = max(0, (cy - r).toInt()); val y1 = min(ph - 1, (cy + r).toInt() + 1)
        val r2 = r * r
        for (yy in y0..y1) {
            val dy = yy + 0.5f - cy
            for (xx in x0..x1) {
                val dx = xx + 0.5f - cx
                val d2 = dx * dx + dy * dy
                if (d2 >= r2) continue
                val k = 1f - s * (1f - d2 / r2)
                dst[yy * pw + xx] = bilerp(src, pw, ph, cx + dx * k - 0.5f, cy + dy * k - 0.5f)
            }
        }
    }

    private fun bilerp(p: ByteArray, pw: Int, ph: Int, x: Float, y: Float): Byte {
        val xf = x.coerceIn(0f, pw - 1f); val yf = y.coerceIn(0f, ph - 1f)
        val x0 = xf.toInt(); val y0 = yf.toInt()
        val x1 = min(x0 + 1, pw - 1); val y1 = min(y0 + 1, ph - 1)
        val fx = xf - x0; val fy = yf - y0
        val a = p[y0 * pw + x0].toInt() and 0xFF; val b = p[y0 * pw + x1].toInt() and 0xFF
        val c = p[y1 * pw + x0].toInt() and 0xFF; val d = p[y1 * pw + x1].toInt() and 0xFF
        val top = a + (b - a) * fx; val bot = c + (d - c) * fx
        return (top + (bot - top) * fy + 0.5f).toInt().toByte()
    }

    // ------------------------------------------------------------------ background replacement

    private fun background(f: FxFrame, bg: BgFx, mk: FxMask) {
        val planes: FxPlanes
        if (bg == BgFx.BLUR) {
            planes = FxPlanes(blurPlane(f.y, f.w, f.h), blurPlane(f.u, f.cw, f.ch), blurPlane(f.v, f.cw, f.ch))
        } else {
            val key = "${bg.ordinal}:${f.w}x${f.h}:${f.rot}"
            val hit = bgPlanes
            planes = if (hit != null && key == bgKey) hit
            else FxBackdrops.render(bg, f.w, f.h, f.rot).also { bgPlanes = it; bgKey = key }
        }
        blendPlane(f.y, planes.y, f.w, f.h, mk)
        blendPlane(f.u, planes.u, f.cw, f.ch, mk)
        blendPlane(f.v, planes.v, f.cw, f.ch, mk)
    }

    /** fg = person where the mask says person, bgp elsewhere (soft edge). Writes into [fg]. */
    private fun blendPlane(fg: ByteArray, bgp: ByteArray, pw: Int, ph: Int, mk: FxMask) {
        val mw = mk.w; val mh = mk.h; val md = mk.data
        val xi0 = IntArray(pw); val xi1 = IntArray(pw); val xf = IntArray(pw)
        for (x in 0 until pw) {
            val s = ((x + 0.5f) * mw / pw - 0.5f).coerceIn(0f, mw - 1f)
            val i0 = s.toInt(); xi0[x] = i0; xi1[x] = min(i0 + 1, mw - 1); xf[x] = ((s - i0) * 256f).toInt()
        }
        val lut = FxLuts.alpha
        for (y in 0 until ph) {
            val s = ((y + 0.5f) * mh / ph - 0.5f).coerceIn(0f, mh - 1f)
            val j0 = s.toInt(); val j1 = min(j0 + 1, mh - 1); val fy = ((s - j0) * 256f).toInt()
            val r0 = j0 * mw; val r1 = j1 * mw
            val row = y * pw
            for (x in 0 until pw) {
                val a = md[r0 + xi0[x]].toInt() and 0xFF; val b = md[r0 + xi1[x]].toInt() and 0xFF
                val c = md[r1 + xi0[x]].toInt() and 0xFF; val d = md[r1 + xi1[x]].toInt() and 0xFF
                val fx = xf[x]
                val top = a * (256 - fx) + b * fx
                val bot = c * (256 - fx) + d * fx
                val alpha = lut[(top * (256 - fy) + bot * fy) ushr 16]
                if (alpha == 255) continue
                val i = row + x
                if (alpha == 0) { fg[i] = bgp[i]; continue }
                val t = (fg[i].toInt() and 0xFF) * alpha + (bgp[i].toInt() and 0xFF) * (255 - alpha) + 128
                fg[i] = ((t + (t shr 8)) shr 8).toByte()
            }
        }
    }

    /** Cheap strong blur: average into blocks, smooth once, then stretch back up bilinearly. */
    private fun blurPlane(src: ByteArray, pw: Int, ph: Int): ByteArray {
        val block = max(2, pw / 80)
        val sw = (pw + block - 1) / block; val sh = (ph + block - 1) / block
        val small = IntArray(sw * sh)
        for (sy in 0 until sh) {
            val y0 = sy * block; val y1 = min(ph, y0 + block)
            for (sx in 0 until sw) {
                val x0 = sx * block; val x1 = min(pw, x0 + block)
                var sum = 0
                for (yy in y0 until y1) { val row = yy * pw; for (xx in x0 until x1) sum += src[row + xx].toInt() and 0xFF }
                small[sy * sw + sx] = sum / ((y1 - y0) * (x1 - x0))
            }
        }
        val sm = IntArray(sw * sh)
        for (j in 0 until sh) for (i in 0 until sw) {
            var acc = 0; var n = 0
            for (dj in -1..1) for (di in -1..1) {
                val jj = j + dj; val ii = i + di
                if (jj in 0 until sh && ii in 0 until sw) { acc += small[jj * sw + ii]; n++ }
            }
            sm[j * sw + i] = acc / n
        }
        val xi0 = IntArray(pw); val xi1 = IntArray(pw); val xf = IntArray(pw)
        for (x in 0 until pw) {
            val s = ((x + 0.5f) / block - 0.5f).coerceIn(0f, sw - 1f)
            val i0 = s.toInt(); xi0[x] = i0; xi1[x] = min(i0 + 1, sw - 1); xf[x] = ((s - i0) * 256f).toInt()
        }
        val out = ByteArray(pw * ph)
        for (y in 0 until ph) {
            val s = ((y + 0.5f) / block - 0.5f).coerceIn(0f, sh - 1f)
            val j0 = s.toInt(); val j1 = min(j0 + 1, sh - 1); val fy = ((s - j0) * 256f).toInt()
            val r0 = j0 * sw; val r1 = j1 * sw
            for (x in 0 until pw) {
                val fx = xf[x]
                val top = sm[r0 + xi0[x]] * (256 - fx) + sm[r0 + xi1[x]] * fx
                val bot = sm[r1 + xi0[x]] * (256 - fx) + sm[r1 + xi1[x]] * fx
                out[y * pw + x] = ((top * (256 - fy) + bot * fy) ushr 16).toByte()
            }
        }
        return out
    }

    // ------------------------------------------------------------------ face stickers

    private fun overlay(f: FxFrame, fx: FaceFx, g: FaceGeo, tSec: Float) {
        val old = ovBmp
        if (old == null || old.width != f.w || old.height != f.h) {
            old?.recycle()
            val nb = Bitmap.createBitmap(f.w, f.h, Bitmap.Config.ARGB_8888)
            ovBmp = nb; ovCanvas = Canvas(nb); ovPx = IntArray(f.w * f.h)
        }
        val bmp = ovBmp ?: return
        val canvas = ovCanvas ?: return
        val px = ovPx ?: return
        bmp.eraseColor(0)
        canvas.save()
        canvas.concat(fxUprightMatrix(f.w, f.h, f.rot))
        art.draw(canvas, fx, g, f.uw, f.uh, tSec)
        canvas.restore()
        bmp.getPixels(px, 0, f.w, 0, 0, f.w, f.h)

        val w = f.w; val h = f.h
        for (i in 0 until w * h) {
            val c = px[i]
            val a = c ushr 24
            if (a == 0) continue
            val yo = fxRgbToY((c shr 16) and 0xFF, (c shr 8) and 0xFF, c and 0xFF)
            f.y[i] = ((((f.y[i].toInt() and 0xFF) * (255 - a)) + yo * a + 127) / 255).toByte()
        }
        val cw = f.cw; val ch = f.ch
        for (cy in 0 until ch) {
            val ry = min(h - 1, cy * 2)
            for (cx in 0 until cw) {
                val c = px[ry * w + min(w - 1, cx * 2)]
                val a = c ushr 24
                if (a == 0) continue
                val r = (c shr 16) and 0xFF; val gg = (c shr 8) and 0xFF; val b = c and 0xFF
                val i = cy * cw + cx
                f.u[i] = ((((f.u[i].toInt() and 0xFF) * (255 - a)) + fxRgbToU(r, gg, b) * a + 127) / 255).toByte()
                f.v[i] = ((((f.v[i].toInt() and 0xFF) * (255 - a)) + fxRgbToV(r, gg, b) * a + 127) / 255).toByte()
            }
        }
    }
}

/** Lookup tables built once. */
internal object FxLuts {
    /** Mask confidence (0..255) -> blend weight (0..255). A smoothstep that trims the fuzzy halo. */
    val alpha = IntArray(256) {
        val t = ((it / 255f - 0.45f) / 0.40f).coerceIn(0f, 1f)
        (t * t * (3f - 2f * t) * 255f + 0.5f).toInt()
    }

    val thermalY = IntArray(256); val thermalU = IntArray(256); val thermalV = IntArray(256)

    init {
        // dark blue -> purple -> red -> orange -> pale yellow
        val stops = arrayOf(
            floatArrayOf(0.00f, 0f, 0f, 70f), floatArrayOf(0.25f, 110f, 0f, 160f),
            floatArrayOf(0.50f, 230f, 30f, 40f), floatArrayOf(0.75f, 255f, 170f, 0f),
            floatArrayOf(1.00f, 255f, 255f, 200f),
        )
        for (i in 0 until 256) {
            val t = i / 255f
            var k = 0
            while (k < stops.size - 2 && t > stops[k + 1][0]) k++
            val a = stops[k]; val b = stops[k + 1]
            val f = ((t - a[0]) / (b[0] - a[0])).coerceIn(0f, 1f)
            val r = (a[1] + (b[1] - a[1]) * f).toInt()
            val g = (a[2] + (b[2] - a[2]) * f).toInt()
            val bl = (a[3] + (b[3] - a[3]) * f).toInt()
            thermalY[i] = fxRgbToY(r, g, bl).coerceIn(16, 235)
            thermalU[i] = fxRgbToU(r, g, bl).coerceIn(16, 240)
            thermalV[i] = fxRgbToV(r, g, bl).coerceIn(16, 240)
        }
    }
}
