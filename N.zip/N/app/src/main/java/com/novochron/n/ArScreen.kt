package com.novochron.n

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.roundToInt

// How far out signs are still shown — keeps the view from filling up with things across town.
private const val AR_VISIBLE_RADIUS_M = 300.0
// New signs are dropped a little way ahead of you (in the direction you're facing when you write
// one), not exactly on top of you — a sign sitting right at your own coordinates has no stable
// bearing to point at.
private const val AR_PLACE_AHEAD_M = 12.0
private const val AR_POLL_MS = 4000L
private const val DEFAULT_FOV_H = 62.0
private const val DEFAULT_FOV_V = 45.0

/**
 * The AR screen: camera preview underneath, floating words on top, positioned purely from compass
 * heading + device tilt + GPS — no ARCore, no plane detection, no persistent 6DOF anchors. A sign
 * is just a (lat, lon, text) triple synced through the same GitHub repo N already uses for chat,
 * so both people see the same signs in the same real-world places. Because there's no true anchor,
 * a sign's on-screen position is recomputed every frame from your current heading/tilt/location —
 * it doesn't drift or jitter like markerless SLAM AR, but it also won't survive you looking away
 * and back with perfect pixel stability the way ARCore's anchors would.
 */
@Composable
fun ArScreen(store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    // ---- permissions: camera to look through, fine location to place/see signs accurately ----
    var camGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var locGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        res[Manifest.permission.CAMERA]?.let { camGranted = it }
        res[Manifest.permission.ACCESS_FINE_LOCATION]?.let { locGranted = it }
    }
    LaunchedEffect(Unit) {
        val need = buildList {
            if (!camGranted) add(Manifest.permission.CAMERA)
            if (!locGranted) add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    // ---- orientation: compass heading (azimuth) + tilt (pitch), from accelerometer + magnetometer.
    // Assumes the phone is held upright in portrait with the back camera pointing forward, which is
    // why MainActivity is locked to portrait — that's the orientation SensorManager's model assumes
    // without extra axis remapping. ----
    var azimuthDeg by remember { mutableStateOf(0f) }
    var pitchDeg by remember { mutableStateOf(0f) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        val accelReading = FloatArray(3)
        val magReading = FloatArray(3)
        val rotationMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                when (e.sensor.type) {
                    Sensor.TYPE_ACCELEROMETER -> System.arraycopy(e.values, 0, accelReading, 0, 3)
                    Sensor.TYPE_MAGNETIC_FIELD -> System.arraycopy(e.values, 0, magReading, 0, 3)
                }
                if (SensorManager.getRotationMatrix(rotationMatrix, null, accelReading, magReading)) {
                    SensorManager.getOrientation(rotationMatrix, orientation)
                    azimuthDeg = ((Math.toDegrees(orientation[0].toDouble()) + 360) % 360).toFloat()
                    pitchDeg = Math.toDegrees(orientation[1].toDouble()).toFloat()
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (accel != null && mag != null) {
            sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME)
            sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_GAME)
        }
        onDispose { sm.unregisterListener(listener) }
    }

    // ---- location: plain LocationManager, no Play Services / no Fused location ----
    var here by remember { mutableStateOf<Location?>(null) }
    DisposableEffect(locGranted) {
        if (!locGranted) return@DisposableEffect onDispose {}
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        for (p in providers) {
            try {
                val last = lm.getLastKnownLocation(p)
                if (last != null && (here == null || last.time > (here?.time ?: 0L))) here = last
            } catch (_: Exception) {}
        }
        val listener = LocationListener { loc -> here = loc }
        for (p in providers) {
            try { lm.requestLocationUpdates(p, 1500L, 1f, listener, Looper.getMainLooper()) } catch (_: Exception) {}
        }
        onDispose { try { lm.removeUpdates(listener) } catch (_: Exception) {} }
    }

    // ---- field of view of the back camera, from its actual sensor size + focal length, so signs
    // land where they should instead of assuming a made-up lens angle ----
    val fov = remember {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cm.cameraIdList.firstOrNull()
            val ch = id?.let { cm.getCameraCharacteristics(it) }
            val f = ch?.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val size = ch?.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            if (f != null && f > 0f && size != null) {
                // The sensor is mounted landscape; in our portrait preview its height maps to the
                // image's horizontal extent and its width to the vertical extent.
                val horiz = Math.toDegrees(2 * atan((size.height / (2 * f)).toDouble()))
                val vert = Math.toDegrees(2 * atan((size.width / (2 * f)).toDouble()))
                horiz to vert
            } else DEFAULT_FOV_H to DEFAULT_FOV_V
        } catch (_: Exception) { DEFAULT_FOV_H to DEFAULT_FOV_V }
    }

    // ---- signs: cached on-device, synced through the shared repo's AR/ folder ----
    var signs by remember { mutableStateOf(listOf<ArSign>()) }
    val known = remember { mutableSetOf<String>() }
    LaunchedEffect(store.repo, store.branch) {
        val cached = withContext(Dispatchers.IO) { loadArCache(ctx, store.repo, store.branch) }
        signs = cached; known.addAll(cached.map { it.path })
        val r = repo; val c = client
        if (r == null || c == null) return@LaunchedEffect
        while (true) {
            try {
                val paths = listArSignPaths(c, r)
                val listedSet = paths.toHashSet()
                val gone = signs.filter { it.path !in listedSet }.map { it.path }
                if (gone.isNotEmpty()) { signs = signs.filter { it.path in listedSet }; known.removeAll(gone.toSet()) }
                val fresh = paths.filter { it !in known }
                for (p in fresh) {
                    val s = fetchArSign(c, r, p)
                    known += p
                    if (s != null) signs = signs + s
                }
                if (fresh.isNotEmpty() || gone.isNotEmpty()) {
                    withContext(Dispatchers.IO) { saveArCache(ctx, store.repo, store.branch, signs) }
                }
            } catch (_: Exception) { /* best-effort — just try again next tick */ }
            delay(AR_POLL_MS)
        }
    }

    // ---- placing a new sign ----
    var placing by remember { mutableStateOf(false) }
    var placeText by remember { mutableStateOf("") }
    var placeStatus by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }

    fun place() {
        val text = placeText.trim()
        val loc = here; val r = repo; val c = client
        if (text.isEmpty()) return
        if (loc == null) { placeStatus = "Still finding your location…"; return }
        if (r == null || c == null) { placeStatus = "Not configured."; return }
        val (lat, lon) = destinationPoint(loc.latitude, loc.longitude, azimuthDeg.toDouble(), AR_PLACE_AHEAD_M)
        val me = store.name.ifBlank { "me" }
        placing = false; placeText = ""; placeStatus = ""
        scope.launch {
            try {
                withContext(Dispatchers.IO) { commitArSign(c, r, me, text, lat, lon) }
            } catch (e: Exception) {
                placeStatus = "Couldn't place it: ${e.message?.take(60) ?: "unknown error"}"
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!camGranted) {
            Text(
                "Camera permission is needed for AR.", color = Ink, fontFamily = TermFont, fontSize = 14.sp,
                textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val previewView = PreviewView(c)
                    val providerFuture = ProcessCameraProvider.getInstance(c)
                    providerFuture.addListener({
                        try {
                            val provider = providerFuture.get()
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                        } catch (_: Exception) {}
                    }, ContextCompat.getMainExecutor(c))
                    previewView
                }
            )

            // ---- the AR itself: floating words, no background, positioned by real-world bearing ----
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val widthPx = with(density) { maxWidth.toPx() }
                val heightPx = with(density) { maxHeight.toPx() }
                val loc = here
                if (loc != null) {
                    for (s in signs) {
                        if (s.lat.isNaN() || s.lon.isNaN()) continue
                        val dist = distanceMeters(loc.latitude, loc.longitude, s.lat, s.lon)
                        if (dist > AR_VISIBLE_RADIUS_M || dist < 0.5) continue
                        val bearing = bearingDegrees(loc.latitude, loc.longitude, s.lat, s.lon)
                        val hDiff = angleDiff(bearing, azimuthDeg.toDouble())
                        if (abs(hDiff) > fov.first / 2 + 8) continue
                        // Signs sit at the horizon; tilting the phone up/down moves them the way a
                        // real object at that height would (no stored altitude — just the tilt).
                        val vDiff = -pitchDeg.toDouble()
                        if (abs(vDiff) > fov.second / 2 + 12) continue
                        val x = widthPx / 2 + (hDiff / (fov.first / 2)) * (widthPx / 2)
                        val y = heightPx / 2 - (vDiff / (fov.second / 2)) * (heightPx / 2)
                        val closeness = (1.0 - (dist / AR_VISIBLE_RADIUS_M).coerceIn(0.0, 1.0))
                        val scale = (0.55 + 0.6 * closeness).toFloat()
                        val alpha = (0.3 + 0.7 * closeness).toFloat()
                        Text(
                            s.text,
                            color = Accent.copy(alpha = alpha),
                            fontFamily = TermFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = (22 * scale).sp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                        )
                    }
                }
            }
        }

        // ---- chrome ----
        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
            TextButton(onClick = { showInfo = !showInfo }) { Text("[i]", color = Dim, fontFamily = TermFont, fontSize = 14.sp) }
        }

        if (showInfo) {
            val loc = here
            Column(Modifier.align(Alignment.TopStart).padding(top = 56.dp, start = 12.dp)) {
                Text("heading ${azimuthDeg.roundToInt()}° · pitch ${pitchDeg.roundToInt()}°", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Text(
                    if (loc != null) "fix: ${"%.5f".format(loc.latitude)}, ${"%.5f".format(loc.longitude)} (±${loc.accuracy.roundToInt()}m)"
                    else "no location fix yet",
                    color = Dim, fontFamily = TermFont, fontSize = 11.sp
                )
                Text("fov ${fov.first.roundToInt()}°×${fov.second.roundToInt()}° · ${signs.size} sign(s) known", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
        }

        // Center reticle — something to aim with, since new signs drop a bit ahead of where you're facing.
        Box(
            Modifier.align(Alignment.Center).size(10.dp)
                .background(Color.White.copy(alpha = 0.55f), shape = CircleShape)
        )

        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (placeStatus.isNotEmpty()) {
                Text(placeStatus, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
            }
            TextButton(onClick = { placing = true }, enabled = camGranted && locGranted) {
                Text("[write a sign]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        if (placing) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f))) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Words to leave floating here:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    TextField(
                        value = placeText, onValueChange = { placeText = it }, singleLine = true,
                        placeholder = { Text("hi", color = Dim, fontFamily = TermFont) },
                        textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 16.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { place() }),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                            focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        TextButton(onClick = { place() }, enabled = placeText.isNotBlank()) {
                            Text("[drop it]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        TextButton(onClick = { placing = false; placeText = "" }) {
                            Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}
