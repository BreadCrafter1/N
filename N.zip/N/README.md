# N

A tiny Novochron-styled app: text, photo, video, and voice messages with one other person, using a
shared GitHub repo as the mailbox instead of a server. No backend — sending is a commit, receiving
is polling the same folder.

## Setting the GitHub token
The token used to talk to the repo is no longer written into any source file, so it can't get
swept up in a `git push` and auto-revoked by GitHub's secret scanning.

- **Building locally:** copy `local.properties.example` to `local.properties` (already
  git-ignored) and paste your token in place of `ghp_your_token_here`.
- **Building via the "Build N" GitHub Actions workflow:** add the token as a repo secret instead
  — repo → **Settings → Secrets and variables → Actions → New repository secret**, name it
  `N_GH_TOKEN`, paste the token as the value. Then, in the workflow file's build step (the one
  that runs `./gradlew assembleDebug` or similar), add:
  ```yaml
  env:
    N_GH_TOKEN: ${{ secrets.N_GH_TOKEN }}
  ```
  (This project's workflow file wasn't part of what I edited — add that `env:` block to yours if
  it isn't there already, or ask me to write the whole workflow file if you'd rather start over.)

Either way, if you ever rotate the token, there's no source file to edit — just update
`local.properties` and/or the `N_GH_TOKEN` secret.

## Build it on GitHub (no Android Studio needed)
1. Create a new GitHub repo and push this project's contents to it (root of the repo = this folder).
2. Go to the repo's **Actions** tab — the "Build N" workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes, open the run and download **N-debug-apk** from the "Artifacts" section at the
   bottom. That zip contains `app-debug.apk` — install it on your phone (you may need to allow
   installs from unknown sources).

## Voice gate + debug panel
- On every launch the app shows a pitch-black screen with the mic open. It stays that way until the secret word is spoken; then the chat appears. Nothing is remembered between launches.
- The secret word is **not in the app**. It lives in the shared repo at `Config/secret.txt` and is fetched at launch. If it can't be fetched (offline, file missing), the gate stays shut.
- **First-time setup:** tap the invisible spot at the top-left corner **5 times quickly** to open the debug panel, type `Operation`, and hit `[save]`. That creates `Config/secret.txt` in the repo. Change the word the same way any time.
- Your name is set once on first launch (there's no `[name]` button anymore). To change it later, open the debug panel and use `[save name]`. Messages you sent under the old name will show up on the other side, since they're matched by name.
- The debug panel also has `[lock now]` (re-locks the app) and shows repo/branch/version/token status.
- Speech recognition uses the phone's built-in recognizer (Google's on most phones), so the mic permission must be granted and the device needs a speech service.

## Replying
Swipe a message sideways (or long-press it) to reply to it — yours or theirs. A bar appears above the input showing who/what you're replying to; `[x]` cancels. Works for text, photo, video, and voice. The quote shows at the top of the reply bubble, and tapping it scrolls to the original.

## AR signs
Tap `[AR]` next to the "N" title to open the camera. It's a compass-and-GPS AR, not ARCore: there's
no plane detection or 6DOF tracking, just your phone's compass heading, tilt, and location deciding
where things sit on screen. The one thing you can put in this AR world is floating text — no
background, no box, just words, colored and sized by how close they are.

- Tap `[write a sign]`, type some words, `[drop it]`. It's placed about 12m ahead of wherever
  you're facing (using the center reticle as roughly "there"), and saved as a small file in the
  shared repo's `AR/` folder — the same mailbox idea as chat messages, just a different folder.
- The other person's phone picks it up the next time they open `[AR]` (polls every 4s while the
  screen is open), and will see your words floating in the same real-world spot when they point
  their camera that way — same repo, same sign, both phones.
- Signs within 300m show up; farther ones fade out rather than cluttering the view.
- `[i]` in the top-right shows your heading/pitch/GPS fix and field-of-view numbers, if a sign
  ever seems to be floating in the wrong place and you want to see why.
- Needs camera and location permission (asked for on first open) and a GPS fix, so it works best
  outdoors or near a window. The whole app is locked to portrait orientation for this to work —
  the compass math assumes the phone is held upright with the camera pointing forward.
- Since there's no real anchor (no ARCore), a sign's position is recalculated from your current
  heading/tilt/location every frame — it won't drift, but it also won't hold pixel-perfect still
  the way a true SLAM anchor would if you look away and back.

## More debug tools
The debug panel also has: device/mic/speech-service info and cache sizes, `[ping github]` (latency, API rate limit, repo access), `[test message]` (sends a "[debug] test message" into the chat), `[clear cache]` (wipes the local chat and media cache), `[test voice]` (shows what the recognizer hears and whether it matches the word typed in the field), and a live event log with `[copy log]`. The log never records the secret word or what was said at the gate.

## Using it
1. Open the app. On first launch it asks for:
   - **A shared repo** (`owner/repo`) — both people must use the exact same one.
   - **A GitHub personal access token** — github.com → Settings → Developer settings → Personal
     access tokens → generate one with the `repo` scope, paste it in. It's stored only on your
     device (SharedPreferences), never sent anywhere but api.github.com.
   - **Your name**, shown on your own messages.
2. Type a message and hit `[send]`, or use `[photo]` / `[video]` to attach a file. Tap `[mic]` to
   record a voice message — the button turns into a running timer and `[stop]`; tap it again (or
   `[cancel]` to discard) to send it. First tap asks for microphone permission.
3. Photos, videos and voice clips can be up to **100 MB** each — that's GitHub's hard per-file limit for
   the Contents API. Big files are streamed from/to disk (never held in memory), show upload progress
   in the status line, and appear in your own chat immediately while they upload.
4. **Tap any photo** to open it full-screen, then tap `[save]` to store the original, full-quality file
   in your gallery (Pictures/N). Android 9 and older will ask for storage permission the first time.

## Speed
- New messages are checked for every second using ETags — when nothing changed, GitHub replies with an
  empty `304` (which doesn't count against your API rate limit).
- New message files are fetched several at a time, and the chat is cached on the phone so it shows
  instantly on launch. Downloaded photos/videos/voice clips are cached too.
- Your own messages appear instantly and are sent in the background; sending skips the extra
  "does this file exist?" round-trip and retries automatically on 409 conflicts.
- Known limit: GitHub only returns the first 1,000 files of a folder, so the chat is capped at roughly
  1,000 messages until you `[clear]` it.


