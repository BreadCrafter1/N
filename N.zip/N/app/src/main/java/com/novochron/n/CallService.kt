package com.novochron.n

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Foreground-service "slot" kept alive for the whole duration of a call.
 *
 * Without this, the app is just a plain background process once you leave it (Home button,
 * switching apps): Android mutes microphone/camera input for backgrounded apps starting on
 * Android 9, and can freeze or kill the process entirely a short while later since it holds no
 * foreground service — either way the call dies even though nothing in the call logic itself
 * failed. Running this service for the duration of the call keeps the process at foreground
 * priority and keeps mic/camera access alive, so a call started here survives you leaving the app,
 * the same way it would in a phone or WhatsApp call. CallManager starts this right before opening
 * the mic (in startCall/accept) and stops it in endLocally() -- it does no work of its own beyond
 * satisfying that OS requirement and showing the (mandatory) "call in progress" notification.
 */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val video = intent?.getBooleanExtra("video", false) == true
        val channelId = "n_call"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(channelId, "Calls", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("N")
            .setContentText(if (video) "Video call in progress" else "Call in progress")
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (video) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(2, notification, type)
        } else {
            @Suppress("DEPRECATION")
            startForeground(2, notification)
        }
        return START_NOT_STICKY
    }
}
