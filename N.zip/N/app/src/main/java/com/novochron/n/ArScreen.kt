package com.novochron.n

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.roundToInt

// How far out signs are still shown — keeps the view from filling up with things across town.
private const val AR_VISIBLE_RADIUS_M = 300.0
// New signs are dropped a little way ahead of you (in the direction you're facing when you write
// one), not exactly on top of you — a sign sitting right at your own coordinates has no stable
// bearing to point at.
private const val AR_PLACE_AHEAD_M = 12.0
private const val AR_POLL_MS = 4000L
private const val DEFAULT_FOV_H = 62.0
private const val DEFAULT_FOV_V = 45.0
// How many degrees past the frame edge a sign takes to fade to fully invisible. Signs stay
// mounted the whole time they're within AR_VISIBLE_RADIUS_M — this only controls the fade curve,
// not whether they're loaded.
private const val AR_EDGE_FADE_DEG = 18.0
// Exponential-smoothing factor for the raw accelerometer/magnetometer readings, 0..1 — lower is
// smoother but laggier. 0.15 is enough to kill visible shake without making the overlay feel sluggish.
private const val SENSOR_SMOOTHING = 0.15f
// How far off a viewer can stand from a sign's locked facing direction before it's considered
// "edge-on"/"behind" and fades to invisible, like a real one-sided sign or photo would.
private const val AR_FACE_FULL_DEG = 65.0
private const val AR_FACE_HIDDEN_DEG = 105.0
// How far the plane visually skews (pseudo-3D) as you move off its locked facing direction.
private const val AR_FACE_MAX_TILT_DEG = 70f
// GPS accuracy (meters) good enough to stop sampling early when placing a sign.
private const val AR_GOOD_ACCURACY_M = 6f
// Max time spent sampling GPS fixes when placing a sign, picking the best (most accurate) one seen.
private const val AR_FIX_TIMEOUT_MS = 5000L

/**
 * The AR screen: camera preview underneath, floating words on top, positioned purely from compass
 * heading + device tilt + GPS — no ARCore, no plane detection, no persistent 6DOF anchors. A sign
 * is just a (lat, lon, text) triple synced through the same GitHub repo N already uses for chat,
 * so both people see the same signs in the same real-world places. Because there's no true anchor,
 * a sign's on-screen position is recomputed every frame from your current heading/tilt/location —
 * it doesn't drift or jitter like markerless SLAM AR, but it also won't survive you looking away
 * and back with perfect pixel stability the way ARCore's anchors would.
 */
@Composable
fun ArScreen(store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    // ---- permissions: camera to look through, fine location to place/see signs accurately ----
    var camGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var locGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        res[Manifest.permission.CAMERA]?.let { camGranted = it }
        res[Manifest.permission.ACCESS_FINE_LOCATION]?.let { locGranted = it }
    }
    LaunchedEffect(Unit) {
        val need = buildList {
            if (!camGranted) add(Manifest.permission.CAMERA)
            if (!locGranted) add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    // ---- orientation: compass heading (azimuth) + tilt (pitch), from accelerometer + magnetometer.
    // getRotationMatrix()/getOrientation() assume the phone is lying flat, screen up (like a map
    // app) — held upright like a camera, that reference frame is ~90° off, which is why an
    // unmapped pitch reads near 90° even when you're looking straight ahead. remapCoordinateSystem
    // re-bases it onto "phone held vertically, camera pointing at the horizon" instead, which is
    // the standard fix for compass-camera overlays like this one. The raw sensors are also low-pass
    // filtered before use — without it, sensor noise makes signs visibly shake/jitter in place. ----
    var azimuthDeg by remember { mutableStateOf(0f) }
    var pitchDeg by remember { mutableStateOf(0f) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        val rawAccel = FloatArray(3)
        val rawMag = FloatArray(3)
        val accelReading = FloatArray(3)
        val magReading = FloatArray(3)
        val rotationMatrix = FloatArray(9)
        val remappedMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        fun lowPass(input: FloatArray, output: FloatArray) {
            for (i in input.indices) output[i] += SENSOR_SMOOTHING * (input[i] - output[i])
        }
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                when (e.sensor.type) {
                    Sensor.TYPE_ACCELEROMETER -> { System.arraycopy(e.values, 0, rawAccel, 0, 3); lowPass(rawAccel, accelReading) }
                    Sensor.TYPE_MAGNETIC_FIELD -> { System.arraycopy(e.values, 0, rawMag, 0, 3); lowPass(rawMag, magReading) }
                }
                if (SensorManager.getRotationMatrix(rotationMatrix, null, accelReading, magReading)) {
                    SensorManager.remapCoordinateSystem(
                        rotationMatrix, SensorManager.AXIS_X, SensorManager.AXIS_Z, remappedMatrix
                    )
                    SensorManager.getOrientation(remappedMatrix, orientation)
                    azimuthDeg = ((Math.toDegrees(orientation[0].toDouble()) + 360) % 360).toFloat()
                    pitchDeg = Math.toDegrees(orientation[1].toDouble()).toFloat()
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (accel != null && mag != null) {
            sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME)
            sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_GAME)
        }
        onDispose { sm.unregisterListener(listener) }
    }

    // ---- location: only turned on right when you place a sign, then switched off again — no
    // continuous GPS tracking just for standing around looking at the camera. Viewing existing
    // signs uses whatever fix is on hand (passive, read from the OS's own cache, which doesn't turn
    // GPS on by itself), so if you wander far between signs it may lag a bit until you write one,
    // which grabs a fresh fix. ----
    var here by remember { mutableStateOf<Location?>(null) }
    var acquiringFix by remember { mutableStateOf(false) }
    val fixListener = remember { mutableStateOf<LocationListener?>(null) }
    val lm = remember { ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager }

    fun stopFixRequest() {
        fixListener.value?.let { try { lm.removeUpdates(it) } catch (_: Exception) {} }
        fixListener.value = null
        acquiringFix = false
    }

    /**
     * Turns GPS on and keeps sampling — a phone's very first fix after waking the radio is often
     * rough — taking whichever reading has the best accuracy, for up to AR_FIX_TIMEOUT_MS or until
     * one is already good enough, then switches location back off. A precise fix here matters more
     * than for just looking around: it's the point a sign gets permanently locked to.
     */
    fun requestFreshFix() {
        if (!locGranted) return
        stopFixRequest()
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Exception) { false } }
        val provider = providers.firstOrNull() ?: return
        acquiringFix = true
        var best: Location? = null
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                if (best == null || loc.accuracy < best!!.accuracy) best = loc
                here = best
                if ((best?.accuracy ?: Float.MAX_VALUE) <= AR_GOOD_ACCURACY_M) stopFixRequest()
            }
        }
        fixListener.value = listener
        try {
            @Suppress("DEPRECATION")
            lm.requestLocationUpdates(provider, 400L, 0f, listener, Looper.getMainLooper())
        } catch (_: Exception) { stopFixRequest(); return }
        scope.launch { delay(AR_FIX_TIMEOUT_MS); stopFixRequest() }
    }

    // Passive seed on open: whatever the OS already has cached, without switching GPS on.
    LaunchedEffect(locGranted) {
        if (!locGranted) return@LaunchedEffect
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                val last = lm.getLastKnownLocation(p)
                if (last != null && (here == null || last.time > (here?.time ?: 0L))) here = last
            } catch (_: Exception) {}
        }
    }
    DisposableEffect(Unit) { onDispose { stopFixRequest() } }

    // ---- field of view of the back camera, from its actual sensor size + focal length, so signs
    // land where they should instead of assuming a made-up lens angle ----
    val fov = remember {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cm.cameraIdList.firstOrNull()
            val ch = id?.let { cm.getCameraCharacteristics(it) }
            val f = ch?.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val size = ch?.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            if (f != null && f > 0f && size != null) {
                // The sensor is mounted landscape; in our portrait preview its height maps to the
                // image's horizontal extent and its width to the vertical extent.
                val horiz = Math.toDegrees(2 * atan((size.height / (2 * f)).toDouble()))
                val vert = Math.toDegrees(2 * atan((size.width / (2 * f)).toDouble()))
                horiz to vert
            } else DEFAULT_FOV_H to DEFAULT_FOV_V
        } catch (_: Exception) { DEFAULT_FOV_H to DEFAULT_FOV_V }
    }

    // ---- signs: cached on-device, synced through the shared repo's AR/ folder ----
    var signs by remember { mutableStateOf(listOf<ArSign>()) }
    val known = remember { mutableSetOf<String>() }
    LaunchedEffect(store.repo, store.branch) {
        val cached = withContext(Dispatchers.IO) { loadArCache(ctx, store.repo, store.branch) }
        signs = cached; known.addAll(cached.map { it.path })
        val r = repo; val c = client
        if (r == null || c == null) return@LaunchedEffect
        while (true) {
            try {
                val paths = listArSignPaths(c, r)
                val listedSet = paths.toHashSet()
                val gone = signs.filter { it.path !in listedSet }.map { it.path }
                if (gone.isNotEmpty()) { signs = signs.filter { it.path in listedSet }; known.removeAll(gone.toSet()) }
                val fresh = paths.filter { it !in known }
                for (p in fresh) {
                    val s = fetchArSign(c, r, p)
                    known += p
                    if (s != null) signs = signs + s
                }
                if (fresh.isNotEmpty() || gone.isNotEmpty()) {
                    withContext(Dispatchers.IO) { saveArCache(ctx, store.repo, store.branch, signs) }
                }
            } catch (_: Exception) { /* best-effort — just try again next tick */ }
            delay(AR_POLL_MS)
        }
    }

    // ---- placing a new sign: words, a photo, or both ----
    var placing by remember { mutableStateOf(false) }
    var placeText by remember { mutableStateOf("") }
    var placeStatus by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }
    var pendingPhoto by remember { mutableStateOf<File?>(null) }
    var pendingPhotoThumb by remember { mutableStateOf<Bitmap?>(null) }

    fun clearPending() {
        pendingPhoto?.delete()
        pendingPhoto = null; pendingPhotoThumb = null
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ext = arPhotoExt(ctx.contentResolver.getType(uri).orEmpty())
            val dest = File(File(ctx.cacheDir, "n/ar_pending").apply { mkdirs() }, "${System.currentTimeMillis()}.$ext")
            val ok = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { input ->
                        dest.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                    } != null
                } catch (e: Exception) { false }
            }
            if (ok && dest.exists() && dest.length() > 0) {
                clearPending()
                pendingPhoto = dest
                pendingPhotoThumb = withContext(Dispatchers.IO) { decodeArSampled(dest, 300) }
            } else {
                dest.delete()
                placeStatus = "Couldn't read that photo."
            }
        }
    }

    fun place() {
        val text = placeText.trim()
        val photo = pendingPhoto
        val loc = here; val r = repo; val c = client
        if (text.isEmpty() && photo == null) return
        if (loc == null) { placeStatus = "Still finding your location…"; return }
        if (r == null || c == null) { placeStatus = "Not configured."; return }
        stopFixRequest()   // got what we needed to save it — switch location back off
        val (lat, lon) = destinationPoint(loc.latitude, loc.longitude, azimuthDeg.toDouble(), AR_PLACE_AHEAD_M)
        // Locks the sign's height to wherever you're standing (GPS altitude, when the fix has one),
        // and its facing direction to the direction you were pointing when you wrote it — so it
        // reads straight-on from about where you're standing now, and looks turned away/edge-on
        // from other angles, like a real sign or photo would.
        val alt = if (loc.hasAltitude()) loc.altitude else Double.NaN
        val faceBearing = (azimuthDeg.toDouble() + 180.0) % 360.0
        val me = store.name.ifBlank { "me" }
        placing = false; placeText = ""; placeStatus = ""; pendingPhoto = null; pendingPhotoThumb = null
        scope.launch {
            try {
                var mediaPath = ""
                if (photo != null) {
                    val ts = System.currentTimeMillis()
                    mediaPath = "AR/media/$ts.${photo.extension.ifBlank { "jpg" }}"
                    withContext(Dispatchers.IO) { c.commitFileStream(mediaPath, photo, "n: ar photo", r) }
                }
                withContext(Dispatchers.IO) { commitArSign(c, r, me, text, lat, lon, alt, faceBearing, mediaPath) }
            } catch (e: Exception) {
                placeStatus = "Couldn't place it: ${e.message?.take(60) ?: "unknown error"}"
            } finally {
                photo?.delete()
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!camGranted) {
            Text(
                "Camera permission is needed for AR.", color = Ink, fontFamily = TermFont, fontSize = 14.sp,
                textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        } else {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    val previewView = PreviewView(c)
                    val providerFuture = ProcessCameraProvider.getInstance(c)
                    providerFuture.addListener({
                        try {
                            val provider = providerFuture.get()
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview)
                        } catch (_: Exception) {}
                    }, ContextCompat.getMainExecutor(c))
                    previewView
                }
            )

            // ---- the AR itself: floating words/photos, no background, positioned by real-world
            // bearing. Signs stay mounted (and their photos stay downloaded/decoded) for as long as
            // they're in range, even while off to the side — only their opacity changes as they
            // enter/leave the camera's field of view. That's what keeps them from re-loading and
            // popping in each time you swing the camera back onto one. ----
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val widthPx = with(density) { maxWidth.toPx() }
                val heightPx = with(density) { maxHeight.toPx() }
                val loc = here
                if (loc != null) {
                    for (s in signs) {
                        if (s.lat.isNaN() || s.lon.isNaN()) continue
                        val dist = distanceMeters(loc.latitude, loc.longitude, s.lat, s.lon)
                        if (dist > AR_VISIBLE_RADIUS_M || dist < 0.5) continue
                        key(s.path) {
                            val bearing = bearingDegrees(loc.latitude, loc.longitude, s.lat, s.lon)
                            val hDiff = angleDiff(bearing, azimuthDeg.toDouble())

                            // Elevation is locked to the sign's actual GPS altitude versus wherever
                            // you're standing now, not just however you happen to be tilting the
                            // phone — so a sign uphill or upstairs from you stays up there. Falls
                            // back to "sits at the horizon" when either altitude is missing (phone
                            // GPS altitude is often unavailable, especially from a network fix, and
                            // is noisier than horizontal position even when it is available).
                            val elevAngleDeg = if (!s.alt.isNaN() && loc.hasAltitude()) {
                                Math.toDegrees(atan2(s.alt - loc.altitude, dist))
                            } else 0.0
                            val vDiff = elevAngleDeg - pitchDeg.toDouble()

                            // Facing: locked to the direction its creator was pointing when they
                            // wrote it, so it reads straight-on from about where they stood and
                            // skews away like a real plane as you move around it, fading out past
                            // ~90° as you pass behind it. Signs from before this existed have no
                            // stored facing and stay simple always-facing-you billboards.
                            val faceOffDeg = if (!s.faceBearing.isNaN()) {
                                angleDiff((bearing + 180.0) % 360.0, s.faceBearing)
                            } else 0.0
                            val faceFactor = when {
                                s.faceBearing.isNaN() -> 1.0
                                abs(faceOffDeg) <= AR_FACE_FULL_DEG -> 1.0
                                abs(faceOffDeg) >= AR_FACE_HIDDEN_DEG -> 0.0
                                else -> 1.0 - (abs(faceOffDeg) - AR_FACE_FULL_DEG) / (AR_FACE_HIDDEN_DEG - AR_FACE_FULL_DEG)
                            }
                            val tiltDeg = (faceOffDeg / AR_FACE_HIDDEN_DEG * AR_FACE_MAX_TILT_DEG)
                                .coerceIn(-AR_FACE_MAX_TILT_DEG.toDouble(), AR_FACE_MAX_TILT_DEG.toDouble()).toFloat()

                            val hEdge = fov.first / 2; val vEdge = fov.second / 2
                            // Fades out over the last few degrees before the frame edge instead of
                            // popping at a hard cutoff, and never un-mounts within AR_VISIBLE_RADIUS_M —
                            // so a sign already has its photo loaded and waiting by the time it's
                            // actually back in frame.
                            val hFactor = (1.0 - ((abs(hDiff) - hEdge) / AR_EDGE_FADE_DEG)).coerceIn(0.0, 1.0)
                            val vFactor = (1.0 - ((abs(vDiff) - vEdge) / AR_EDGE_FADE_DEG)).coerceIn(0.0, 1.0)
                            val closeness = 1.0 - (dist / AR_VISIBLE_RADIUS_M).coerceIn(0.0, 1.0)
                            val scale = (0.55 + 0.6 * closeness).toFloat()
                            val alpha = ((0.3 + 0.7 * closeness) * hFactor * vFactor * faceFactor).toFloat()
                            val x = widthPx / 2 + (hDiff / hEdge) * (widthPx / 2)
                            val y = heightPx / 2 - (vDiff / vEdge) * (heightPx / 2)

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                                    .graphicsLayer { this.alpha = alpha; this.rotationY = tiltDeg }
                            ) {
                                if (s.mediaPath.isNotBlank()) {
                                    var bmp by remember(s.path) { mutableStateOf<Bitmap?>(null) }
                                    LaunchedEffect(s.path) {
                                        val c = client; val r = repo
                                        if (c == null || r == null) return@LaunchedEffect
                                        val dest = arMediaCacheFile(ctx, s.mediaPath)
                                        val ready = dest.exists() && dest.length() > 0
                                        val ok = ready || try {
                                            withContext(Dispatchers.IO) { c.downloadFile(s.mediaPath, r, dest) }
                                        } catch (_: Exception) { false }
                                        if (ok) bmp = withContext(Dispatchers.IO) { decodeArSampled(dest, 480) }
                                    }
                                    bmp?.let { b ->
                                        Image(
                                            b.asImageBitmap(), contentDescription = null,
                                            modifier = Modifier.widthIn(max = (180 * scale).dp)
                                        )
                                    }
                                }
                                if (s.text.isNotBlank()) {
                                    Text(
                                        s.text, color = Accent, fontFamily = TermFont,
                                        fontWeight = FontWeight.Bold, fontSize = (22 * scale).sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---- chrome ----
        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
            TextButton(onClick = { showInfo = !showInfo }) { Text("[i]", color = Dim, fontFamily = TermFont, fontSize = 14.sp) }
        }

        if (showInfo) {
            val loc = here
            Column(Modifier.align(Alignment.TopStart).padding(top = 56.dp, start = 12.dp)) {
                Text("heading ${azimuthDeg.roundToInt()}° · pitch ${pitchDeg.roundToInt()}°", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Text(
                    if (loc != null) "fix: ${"%.5f".format(loc.latitude)}, ${"%.5f".format(loc.longitude)} (±${loc.accuracy.roundToInt()}m)"
                    else "no location fix yet",
                    color = Dim, fontFamily = TermFont, fontSize = 11.sp
                )
                Text(
                    if (loc != null && loc.hasAltitude()) {
                        val vAcc = if (loc.hasVerticalAccuracy()) " (±${loc.verticalAccuracyMeters.roundToInt()}m)" else " (accuracy unknown)"
                        "alt: ${"%.1f".format(loc.altitude)}m$vAcc"
                    } else "no altitude in this fix",
                    color = Dim, fontFamily = TermFont, fontSize = 11.sp
                )
                Text("fov ${fov.first.roundToInt()}°×${fov.second.roundToInt()}° · ${signs.size} sign(s) known", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
        }

        // Center reticle — something to aim with, since new signs drop a bit ahead of where you're facing.
        Box(
            Modifier.align(Alignment.Center).size(10.dp)
                .background(Color.White.copy(alpha = 0.55f), shape = CircleShape)
        )

        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (placeStatus.isNotEmpty()) {
                Text(placeStatus, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
            }
            TextButton(onClick = { placing = true; requestFreshFix() }, enabled = camGranted && locGranted) {
                Text("[write a sign]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        if (placing) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f))) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Words and/or a photo to leave floating here:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                    if (acquiringFix) {
                        Spacer(Modifier.height(4.dp))
                        Text("finding your location…", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    pendingPhotoThumb?.let { thumb ->
                        Image(
                            thumb.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.widthIn(max = 140.dp).padding(bottom = 4.dp)
                        )
                        TextButton(onClick = { clearPending() }) {
                            Text("[remove photo]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                    TextField(
                        value = placeText, onValueChange = { placeText = it }, singleLine = true,
                        placeholder = { Text("hi", color = Dim, fontFamily = TermFont) },
                        textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 16.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { place() }),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                            focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        if (pendingPhotoThumb == null) {
                            TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }) {
                                Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 15.sp)
                            }
                        }
                        TextButton(onClick = { place() }, enabled = placeText.isNotBlank() || pendingPhoto != null) {
                            Text("[drop it]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        TextButton(onClick = { placing = false; placeText = ""; clearPending(); stopFixRequest() }) {
                            Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 15.sp)
                        }
                    }
                }
            }
        }
    }
}

/** Decodes at reduced size so a big photo doesn't blow up memory just to float it on screen. */
private fun decodeArSampled(file: File, maxDim: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}
