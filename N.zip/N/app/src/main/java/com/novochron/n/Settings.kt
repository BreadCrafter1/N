package com.novochron.n

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

/** A ready-made background the person can tap. Publishing one syncs it to everyone on the repo. */
private data class BgPreset(val name: String, val kind: String, val c1: Long, val c2: Long = c1)

private val BgPresets = listOf(
    BgPreset("default", "none", 0x000000),
    BgPreset("midnight", "solid", 0xFF0B1020),
    BgPreset("forest", "solid", 0xFF0A1F14),
    BgPreset("wine", "solid", 0xFF2A0B16),
    BgPreset("slate", "solid", 0xFF1E2530),
    BgPreset("paper", "solid", 0xFFF5EFE0),
    BgPreset("sky", "solid", 0xFFDCEBFF),
    BgPreset("dusk", "gradient", 0xFF1B1B3A, 0xFF69306D),
    BgPreset("ocean", "gradient", 0xFF0F2027, 0xFF2C5364),
    BgPreset("ember", "gradient", 0xFF200122, 0xFF6F0000),
    BgPreset("aurora", "gradient", 0xFF0F2A2A, 0xFF3B1F5C),
    BgPreset("peach", "gradient", 0xFFFFE3D1, 0xFFFFB6C1),
    BgPreset("mint", "gradient", 0xFFD4FC79, 0xFF96E6A1),
)

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(18.dp))
    Text(text, color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
}

/** [label] button that shows as "[● label]" when selected. */
@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(
            if (selected) "[● $label]" else "[$label]",
            color = if (selected) Accent else Ink, fontFamily = TermFont,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp
        )
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(32.dp).clip(CircleShape).background(color)
            .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) Ink else Line), CircleShape)
            .clickable(onClick = onClick)
    )
}

@Composable
private fun HexRow(placeholder: String, initial: String, onApply: (String) -> Boolean) {
    var v by remember { mutableStateOf(initial) }
    var bad by remember { mutableStateOf(false) }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        androidx.compose.material3.TextField(
            value = v, onValueChange = { v = it; bad = false }, singleLine = true,
            placeholder = { Text(placeholder, color = Dim, fontFamily = TermFont) },
            textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
            colors = androidx.compose.material3.TextFieldDefaults.colors(
                focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
            ),
            modifier = Modifier.width(160.dp)
        )
        TextButton(onClick = { bad = !onApply(v) }) { Text("[apply]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        if (bad) Text("bad hex", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
    }
}

/**
 * Settings screen (opened from the top-right of the chat). Look-and-feel choices for dark/light,
 * accent and letter colours are saved on this device; the background is published to the repo
 * (Config/theme.json) so it changes on every phone using it. Also holds the notification controls.
 */
@Composable
fun SettingsPanel(store: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }
    BackHandler(onBack = onClose)

    var dark by remember { mutableStateOf(store.darkMode) }
    var accentKey by remember { mutableStateOf(store.accentKey) }
    var textKey by remember { mutableStateOf(store.textKey) }
    var bgStatus by remember { mutableStateOf("") }
    var bgBusy by remember { mutableStateOf(false) }
    var dimDraft by remember { mutableStateOf(ThemeState.bg.dim) }

    var notifOn by remember { mutableStateOf(store.notifEnabled && Notifier.canPost(ctx)) }
    var notifPreview by remember { mutableStateOf(store.notifPreview) }
    var notifStatus by remember { mutableStateOf("") }

    // Re-check battery/notification status whenever we come back from a system screen.
    var permTick by remember { mutableStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) permTick++ }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    val unrestricted = remember(permTick) {
        try { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName) } catch (_: Exception) { false }
    }
    val notifAllowed = remember(permTick, notifOn) { Notifier.canPost(ctx) }

    // ---- profile ----
    val me = store.name.ifBlank { "me" }
    var nickDraft by remember { mutableStateOf(Profiles.map[me]?.nick ?: "") }
    var profileStatus by remember { mutableStateOf("") }
    var profileBusy by remember { mutableStateOf(false) }
    fun saveProfile(newAvatar: File? = null, removeAvatar: Boolean = false) {
        scope.launch {
            profileBusy = true; profileStatus = "saving…"
            val err = Profiles.publish(ctx.applicationContext, store, client, repo, nickDraft, newAvatar, removeAvatar)
            profileStatus = if (err == null) "✓ saved — the other phone will see it shortly" else "Couldn't save: $err"
            profileBusy = false
        }
    }
    val avatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            profileBusy = true; profileStatus = "preparing picture…"
            val f = Profiles.prepareAvatar(ctx, uri)
            profileBusy = false
            if (f == null) profileStatus = "Couldn't read that image." else saveProfile(newAvatar = f)
        }
    }

    fun setMode(d: Boolean) {
        dark = d; store.darkMode = d; ThemeState.dark = d; ThemeState.refreshColors(store)
    }
    fun setAccent(k: String) { accentKey = k; store.accentKey = k; ThemeState.refreshColors(store) }
    fun setText(k: String) { textKey = k; store.textKey = k; ThemeState.refreshColors(store) }

    fun publishBg(theme: BgTheme, image: File? = null) {
        scope.launch {
            bgBusy = true; bgStatus = "syncing to repo…"
            val err = ThemeSync.publish(ctx.applicationContext, store, client, repo, theme, image)
            bgStatus = if (err == null) "✓ synced — everyone on this repo will see it within ~15s" else "Couldn't sync: $err"
            dimDraft = ThemeState.bg.dim
            bgBusy = false
        }
    }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            bgBusy = true; bgStatus = "preparing image…"
            val f = prepareBgImage(ctx, uri)
            if (f == null) { bgStatus = "Couldn't read that image."; bgBusy = false; return@launch }
            bgBusy = false
            publishBg(ThemeState.bg.copy(kind = "image", dim = if (dimDraft > 0f) dimDraft else 0.45f), f)
        }
    }

    // ---- notifications ----
    val notifPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && Notifier.canPost(ctx)) {
            store.notifEnabled = true; notifOn = true; notifStatus = ""
            Notifier.start(ctx)
        } else {
            store.notifEnabled = false; notifOn = false
            notifStatus = "Notifications are blocked for N — allow them in system settings."
        }
    }
    fun toggleNotifications() {
        if (notifOn) {
            store.notifEnabled = false; notifOn = false; notifStatus = ""
            Notifier.stop(ctx)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (!Notifier.canPost(ctx)) {
            notifStatus = "Notifications are blocked for N — allow them in system settings."
            return
        }
        store.notifEnabled = true; notifOn = true; notifStatus = ""
        Notifier.start(ctx)
    }

    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) {
        ThemedBackground()
        Box(Modifier.fillMaxSize().background(Bg.copy(alpha = 0.55f)))
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 12.dp).verticalScroll(rememberScrollState())
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("settings", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
            }

            // ---------------- profile ----------------
            SectionTitle("profile")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Avatar(me, 64.dp)
                Column {
                    Text(Profiles.display(me), color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("username: $me", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { avatarLauncher.launch(arrayOf("image/*")) }, enabled = !profileBusy) {
                    Text("[change picture]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (Profiles.avatars[me] != null) TextButton(onClick = { saveProfile(removeAvatar = true) }, enabled = !profileBusy) {
                    Text("[remove]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                }
            }
            Text("nickname (shown instead of your username)", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.TextField(
                    value = nickDraft, onValueChange = { nickDraft = it.take(30) }, singleLine = true,
                    placeholder = { Text(me, color = Dim, fontFamily = TermFont) },
                    textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                        focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
                    ),
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { saveProfile() }, enabled = !profileBusy) {
                    Text("[save]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            if (profileStatus.isNotEmpty()) Text(profileStatus, color = if (profileStatus.startsWith("Couldn't")) Warn else Dim, fontFamily = TermFont, fontSize = 11.sp)
            Hint("Your username stays the same underneath (it's how messages are matched to you). Nickname and picture are shared through the repo.")

            // ---------------- appearance ----------------
            SectionTitle("appearance")
            Row { Choice("dark", dark) { setMode(true) }; Choice("light", !dark) { setMode(false) } }

            Spacer(Modifier.height(8.dp))
            Text("accent colour (buttons, labels)", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ColorDot(if (dark) Color(0xFF3DFF5C) else Color(0xFF0B8F23), accentKey.isBlank()) { setAccent("") }
                AccentSwatches.filter { it.key != "green" }.forEach { s ->
                    ColorDot(if (dark) s.dark else s.light, accentKey == s.key) { setAccent(s.key) }
                }
            }
            Spacer(Modifier.height(4.dp))
            HexRow("#RRGGBB", if (accentKey.startsWith("#")) accentKey else "") { h -> parseHexColor(h)?.let { setAccent(it.toHex()); true } ?: false }

            Spacer(Modifier.height(12.dp))
            Text("letter colour", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ColorDot(if (dark) Color(0xFFE8E8E8) else Color(0xFF1A1A1A), textKey.isBlank()) { setText("") }
                TextSwatches.forEach { s ->
                    ColorDot(if (dark) s.dark else s.light, textKey == s.key) { setText(s.key) }
                }
            }
            Spacer(Modifier.height(4.dp))
            HexRow("#RRGGBB", if (textKey.startsWith("#")) textKey else "") { h -> parseHexColor(h)?.let { setText(it.toHex()); true } ?: false }
            Spacer(Modifier.height(4.dp))
            Hint("Mode and colours are saved on this phone only.")
            TextButton(onClick = { setAccent(""); setText("") }) {
                Text("[reset colours]", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
            }

            // ---------------- background (synced) ----------------
            SectionTitle("background · synced with repo")
            Hint("Changes are committed to Config/theme.json, so the other phone gets the same background.")
            Spacer(Modifier.height(8.dp))
            val cur = ThemeState.bg
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BgPresets.forEach { p ->
                    val brush = when (p.kind) {
                        "none" -> Brush.linearGradient(listOf(Bg, Bg))
                        "solid" -> Brush.linearGradient(listOf(Color(p.c1), Color(p.c1)))
                        else -> Brush.verticalGradient(listOf(Color(p.c1), Color(p.c2)))
                    }
                    val selected = cur.kind == p.kind && (p.kind == "none" || (cur.c1 == p.c1.toInt() && (p.kind == "solid" || cur.c2 == p.c2.toInt())))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(46.dp).clip(RoundedCornerShape(8.dp)).background(brush)
                                .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) Accent else Line), RoundedCornerShape(8.dp))
                                .clickable(enabled = !bgBusy) {
                                    publishBg(BgTheme(kind = p.kind, c1 = p.c1.toInt(), c2 = p.c2.toInt(), dim = cur.dim))
                                }
                        )
                        Text(p.name, color = Dim, fontFamily = TermFont, fontSize = 9.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("custom colours", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            var c1 by remember { mutableStateOf(if (cur.kind == "solid" || cur.kind == "gradient") Color(cur.c1).toHex() else "") }
            var c2 by remember { mutableStateOf(if (cur.kind == "gradient") Color(cur.c2).toHex() else "") }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.TextField(
                    value = c1, onValueChange = { c1 = it }, singleLine = true,
                    placeholder = { Text("top #RRGGBB", color = Dim, fontFamily = TermFont, fontSize = 12.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 13.sp),
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                        focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
                    ),
                    modifier = Modifier.weight(1f)
                )
                androidx.compose.material3.TextField(
                    value = c2, onValueChange = { c2 = it }, singleLine = true,
                    placeholder = { Text("bottom (optional)", color = Dim, fontFamily = TermFont, fontSize = 12.sp) },
                    textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontFamily = TermFont, fontSize = 13.sp),
                    colors = androidx.compose.material3.TextFieldDefaults.colors(
                        focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                        focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
            TextButton(
                enabled = !bgBusy,
                onClick = {
                    val a = parseHexColor(c1)
                    val b = if (c2.isBlank()) null else parseHexColor(c2)
                    when {
                        a == null -> bgStatus = "First colour isn't a valid hex (like #1A2B3C)."
                        c2.isNotBlank() && b == null -> bgStatus = "Second colour isn't a valid hex."
                        else -> publishBg(BgTheme(kind = if (b == null) "solid" else "gradient", c1 = a.toArgb(), c2 = (b ?: a).toArgb(), dim = cur.dim))
                    }
                }
            ) { Text("[apply & sync]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }

            Spacer(Modifier.height(8.dp))
            Text("image", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { imageLauncher.launch(arrayOf("image/*")) }, enabled = !bgBusy) {
                    Text("[pick image]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (cur.kind == "image") TextButton(
                    onClick = { publishBg(BgTheme(kind = "none", dim = cur.dim)) }, enabled = !bgBusy
                ) { Text("[remove image]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            }
            if (cur.kind == "image") {
                Text("readability shade: ${(dimDraft * 100).toInt()}%", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                Slider(
                    value = dimDraft, valueRange = 0f..0.85f,
                    onValueChange = { dimDraft = it; ThemeState.bg = ThemeState.bg.copy(dim = it) },
                    onValueChangeFinished = { publishBg(ThemeState.bg.copy(dim = dimDraft)) },
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Line)
                )
            }
            if (bgStatus.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(bgStatus, color = if (bgStatus.startsWith("Couldn't") || bgStatus.contains("valid")) Warn else Dim, fontFamily = TermFont, fontSize = 11.sp)
            }

            // ---------------- notifications ----------------
            SectionTitle("notifications")
            Row { Choice("on", notifOn) { if (!notifOn) toggleNotifications() }; Choice("off", !notifOn) { if (notifOn) toggleNotifications() } }
            Row {
                Choice("hide text", !notifPreview) { notifPreview = false; store.notifPreview = false }
                Choice("show text", notifPreview) { notifPreview = true; store.notifPreview = true }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    if (!Notifier.canPost(ctx)) notifStatus = "Notifications are blocked for N — allow them in system settings."
                    else { Notifier.showMessage(ctx, "Constellation", "This is a test notification", store.notifPreview); notifStatus = "" }
                }) { Text("[send test]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                TextButton(onClick = {
                    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    try { ctx.startActivity(i) } catch (_: Exception) {}
                }) { Text("[system settings]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            }
            if (notifStatus.isNotEmpty()) Text(notifStatus, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Spacer(Modifier.height(10.dp))
            Text("permissions", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            Text(
                (if (notifAllowed) "✓" else "✗") + " show notifications" + if (notifAllowed) "" else "  (blocked)",
                color = if (notifAllowed) Ink else Warn, fontFamily = TermFont, fontSize = 12.sp
            )
            Text(
                (if (unrestricted) "✓" else "✗") + " run in background unrestricted" + if (unrestricted) "" else "  (Android may put it to sleep)",
                color = if (unrestricted) Ink else Warn, fontFamily = TermFont, fontSize = 12.sp
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (!unrestricted) TextButton(onClick = {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
                    } catch (_: Exception) {
                        try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
                    }
                }) { Text("[allow background]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                if (!notifAllowed) TextButton(onClick = {
                    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    try { ctx.startActivity(i) } catch (_: Exception) {}
                }) { Text("[allow notifications]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                TextButton(onClick = {
                    val i = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, CH_SYNC)
                    try { ctx.startActivity(i) } catch (_: Exception) {}
                }) { Text("[hide 'listening' entry]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            }
            Spacer(Modifier.height(4.dp))
            Hint("Starts by itself after a reboot or update. You get an alert when someone messages you, and your phone rings when someone calls (tap it to answer in the app). Never while the app is open. \"hide text\" also hides who is calling.")
            Spacer(Modifier.height(4.dp))
            Hint("Why there's a \"listening\" entry at all: there's no push server, and Android only lets an app stay awake in the background if it shows one. It's silent and has no status-bar icon; \"hide 'listening' entry\" lets you switch that one channel off (the listener keeps running, messages still alert). Phones from Xiaomi, Oppo, Vivo, Samsung and others also have their own \"auto-start\" / \"battery\" pages - allow N there too if alerts stop.")
            Spacer(Modifier.height(28.dp))
        }
    }
}

/**
 * Shrinks the picked image to something sensible to commit to a repo (max 1600px, JPEG), honouring
 * EXIF rotation. Returns the cached file, or null if it couldn't be read.
 */
private suspend fun prepareBgImage(ctx: Context, uri: Uri): File? = withContext(Dispatchers.IO) {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return@withContext null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2
        var bmp: Bitmap = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return@withContext null

        val rotation = try {
            ctx.contentResolver.openInputStream(uri)?.use { s ->
                when (android.media.ExifInterface(s).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Exception) { 0f }

        val scale = 1600f / max(bmp.width, bmp.height)
        val m = Matrix().apply {
            if (scale < 1f) postScale(scale, scale)
            if (rotation != 0f) postRotate(rotation)
        }
        if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)

        val out = File(ctx.cacheDir, "n/bg/upload-${System.currentTimeMillis()}.jpg")
        out.parentFile?.mkdirs()
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        out
    } catch (e: Exception) { null }
}
