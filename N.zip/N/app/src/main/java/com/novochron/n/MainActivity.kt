package com.novochron.n

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Environment
import android.provider.MediaStore
import android.util.Rational
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// ---- theme, matching Novochron's terminal look (colours: see Theme.kt) ----
// Accent / Ink / Dim / Line / Raised / Warn / Mine are defined in Theme.kt (dark/light aware).
val TermFont = FontFamily.Monospace

internal const val MSG_DIR = "Msg"
private const val MSG_MEDIA_DIR = "Msg/media"
private const val POLL_MS = 1000L              // cheap: unchanged polls come back as empty 304s
private const val FETCH_PARALLELISM = 6         // new message files fetched this many at a time
// GitHub's Contents API tops out at 100 MB per file — that's the real ceiling for photos/videos/voice.
private const val MAX_MEDIA_BYTES = 100L * 1024 * 1024

// ---- message bucketing ----
// GitHub's Contents API only returns the first 1,000 entries of a folder. Instead of one flat
// Msg/ folder that eventually caps out (forcing a manual [clear]), messages are split into one
// subfolder per calendar month: Msg/2026-09/<ts>-<uuid>.json. Each month gets its own fresh
// 1,000-file budget, older months stay put as permanent, lazily-loaded history, and nothing ever
// needs deleting. Media (photos/videos/voice) stays in the flat Msg/media/ folder unchanged,
// since it's only ever fetched by exact path (from a message's "media" field), never listed.
private val bucketFmt = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US).apply {
    // UTC, not the phone's local zone — otherwise two phones in different timezones could file the
    // same moment into two different month folders near a month boundary.
    timeZone = java.util.TimeZone.getTimeZone("UTC")
}
internal fun bucketFor(ts: Long): String = bucketFmt.format(java.util.Date(ts))
private fun msgDirFor(ts: Long): String = "$MSG_DIR/${bucketFor(ts)}"
/** The month-bucket a stored message file belongs to, read back out of its own path. */
private fun bucketOf(path: String): String = path.removePrefix("$MSG_DIR/").substringBefore('/')

private enum class MsgType { TEXT, PHOTO, VIDEO, VOICE, STICKER }
/** A snapshot of the message being replied to, so the quote still shows even if the original is gone. */
private data class ReplyRef(val path: String, val from: String, val preview: String)
private data class ChatMsg(
    val path: String, val sender: String, val ts: Long, val type: MsgType,
    val text: String = "", val mediaPath: String = "", val durationMs: Long = 0L,
    val pending: Boolean = false, val reply: ReplyRef? = null
)

/** In-memory event log shown in the debug panel. Never records the secret word or what was said at the gate. */
object DebugLog {
    val lines = mutableStateListOf<String>()
    fun add(msg: String) {
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        if (lines.lastOrNull()?.drop(10) == msg) return          // collapse repeats (e.g. polling while offline)
        lines.add("$stamp  $msg")
        while (lines.size > 100) lines.removeAt(0)
    }
}

/**
 * Debug-only runtime toggles, flipped from the debug panel to make the app misbehave on purpose
 * so its error paths / retry logic / UI states can be exercised. All reset to defaults on process
 * restart — nothing here is persisted.
 */
object DebugFlags {
    var simulateSendFailure by mutableStateOf(false)   // every send throws instead of hitting the network
    var verbosePolling by mutableStateOf(false)        // log every poll tick, not just changes
    var pollIntervalMs by mutableStateOf(POLL_MS)       // overrides the normal 1s poll cadence
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()
        val store = Store(applicationContext)
        ThemeState.load(store)
        Profiles.load(store)
        setContent {
            MaterialTheme(
                colorScheme = if (ThemeState.dark) darkColorScheme(background = Color.Black)
                else lightColorScheme(background = Color.White)
            ) {
                NApp(store)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        AppState.foreground = true
        // Looking at the app now, so anything still sitting in the shade is stale.
        Notifier.clearMessages(this)
        Notifier.clearCall(this)
        // (Re)start the background message listener if notifications are on. Harmless if it's already running.
        val store = Store(applicationContext)
        if (store.notifEnabled && Notifier.canPost(this)) Notifier.start(this)
    }

    override fun onStop() {
        AppState.foreground = false
        super.onStop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Re-hide on every focus regain: the status/nav bars reappear after things like the
        // system share sheet, a permission dialog, or the recents switcher, and don't hide
        // themselves back again on their own.
        if (hasFocus) hideSystemBars()
    }

    // Fires when the person leaves the app (Home button, switching apps) but NOT on back/screen
    // off. If there's a live call, shrink it into a Picture-in-Picture window instead of just
    // going to the background — the call itself already survives either way (see CallService),
    // this just keeps it visible.
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && CallPip.active &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            val ratio = if (CallPip.video) Rational(9, 16) else Rational(3, 4)
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(ratio).build())
            } catch (_: Exception) {}
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        CallPip.inPip = isInPictureInPictureMode
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}

private const val SECRET_PATH = "Config/secret.txt"   // lives in the shared repo, never inside the app

@Composable
fun NApp(store: Store) {
    var nameText by remember { mutableStateOf(store.name.ifBlank { "me" }) }
    var editingSetup by remember { mutableStateOf(store.name.isBlank()) }
    var setupStatus by remember { mutableStateOf("") }

    // Voice gate state. Nothing here is persisted: every launch starts locked, and the secret word
    // is only ever held in memory after being fetched from the repo.
    var unlocked by remember { mutableStateOf(false) }
    var secret by remember { mutableStateOf<String?>(null) }
    var showDebug by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var reloadTick by remember { mutableStateOf(0) }   // bumped when the chat should reload (name changed, cache cleared)
    LaunchedEffect(Unit) { DebugLog.add("app started v${BuildConfig.VERSION_NAME}") }

    // Once unlocked, keep the shared background in sync with Config/theme.json in the repo.
    val appCtx = LocalContext.current.applicationContext
    LaunchedEffect(unlocked, reloadTick) {
        if (!unlocked) return@LaunchedEffect
        val r = RepoRef.parse(store.repo)
        val c = if (store.token.isBlank()) null else GitHubClient(store.token, store.branch)
        ThemeSync.loop(appCtx, store, c, r)
    }
    LaunchedEffect(unlocked, reloadTick) {
        if (!unlocked) return@LaunchedEffect
        val r = RepoRef.parse(store.repo)
        val c = if (store.token.isBlank()) null else GitHubClient(store.token, store.branch)
        Profiles.loop(appCtx, store, c, r)
    }

    // While locked, keep fetching the word from the repo. Fails closed: no word (offline, missing
    // file, bad token) means the gate simply stays shut.
    LaunchedEffect(unlocked) {
        if (unlocked) { secret = null; return@LaunchedEffect }
        val r = RepoRef.parse(store.repo)
        if (r == null || store.token.isBlank()) return@LaunchedEffect
        val c = GitHubClient(store.token, store.branch)
        while (true) {
            val w = try {
                c.readFile(SECRET_PATH, r)?.trim().also { if (it == null) DebugLog.add("secret file not found in repo") }
            } catch (e: Exception) { DebugLog.add("secret fetch error: ${e.message?.take(60)}"); null }
            if (!w.isNullOrBlank()) secret = w
            delay(if (secret == null) 3000 else 8000)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!unlocked) {
            // Pitch black. No text, no title — just the mic listening until the word is heard.
            VoiceGate(secret, paused = showDebug) { DebugLog.add("gate: unlocked by voice"); unlocked = true }
        } else {
            ThemedBackground()
            Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    // Cursive script (the phone's built-in one), in grey rather than the accent colour.
                    Text(
                        "Constellation", color = TitleGrey, fontFamily = FontFamily.Cursive,
                        fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = 1.sp
                    )
                    TextButton(onClick = { showSettings = true }) {
                        Text("[settings]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))

                if (editingSetup) {
                    SetupForm(
                        nameText, setupStatus,
                        onName = { nameText = it },
                        canCancel = store.name.isNotBlank(),
                        onCancel = { editingSetup = false; setupStatus = "" },
                        onSave = {
                            store.name = nameText.ifBlank { "me" }
                            editingSetup = false
                            setupStatus = ""
                        }
                    )
                } else {
                    key(reloadTick) { ChatBody(store) }
                }
            }
        }

        if (unlocked && showSettings && !showDebug) {
            SettingsPanel(store, onClose = { showSettings = false })
        }

        if (showDebug) {
            DebugPanel(
                store,
                onWordSaved = { secret = it },
                onNameSaved = { nameText = it; reloadTick++ },
                onRepoSaved = { reloadTick++ },
                onCacheCleared = { reloadTick++ },
                onLock = { DebugLog.add("locked from debug"); unlocked = false; showDebug = false; showSettings = false },
                onForceUnlock = { DebugLog.add("force-unlocked from debug"); unlocked = true; showDebug = false },
                onReset = {
                    store.name = ""; store.branch = "main"
                    nameText = ""; editingSetup = true; reloadTick++
                    DebugLog.add("app reset from debug"); showDebug = false
                },
                onClose = { showDebug = false }
            )
        } else {
            // The invisible debug button, top-left. Five quick taps opens the debug panel.
            var taps by remember { mutableStateOf(0) }
            var lastTap by remember { mutableStateOf(0L) }
            Box(
                Modifier.align(Alignment.TopStart).size(56.dp).clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null
                ) {
                    val now = System.currentTimeMillis()
                    taps = if (now - lastTap < 1500) taps + 1 else 1
                    lastTap = now
                    if (taps >= 5) { taps = 0; showDebug = true }
                }
            )
        }
    }
}

private fun normalizeSpeech(t: String): String =
    " " + t.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim().replace(Regex("\\s+"), " ") + " "

/**
 * Black screen that listens with the mic non-stop (restarting the recognizer whenever it times out)
 * and only lets go once the secret word is heard. [word] == null means it isn't known yet
 * (still fetching / unreachable) — the gate stays shut and keeps listening.
 */
@Composable
private fun VoiceGate(word: String?, paused: Boolean, onPass: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(Manifest.permission.RECORD_AUDIO) }

    val currentWord by rememberUpdatedState(word)
    val passed by rememberUpdatedState(onPass)

    DisposableEffect(granted, paused) {
        view.keepScreenOn = true
        if (!granted || paused || !SpeechRecognizer.isRecognitionAvailable(ctx)) {
            return@DisposableEffect onDispose { view.keepScreenOn = false }
        }
        val handler = Handler(Looper.getMainLooper())
        var alive = true
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        fun listen() { if (alive) try { sr.startListening(intent) } catch (_: Exception) { handler.postDelayed({ if (alive) listen() }, 1000) } }
        fun relisten(delayMs: Long) { handler.postDelayed({ if (alive) { try { sr.cancel() } catch (_: Exception) {}; listen() } }, delayMs) }
        fun heard(list: List<String>?): Boolean {
            val w = currentWord?.let { normalizeSpeech(it) } ?: return false
            if (w.isBlank()) return false
            if (list?.any { normalizeSpeech(it).contains(w) } == true) {
                alive = false
                handler.removeCallbacksAndMessages(null)
                try { sr.cancel(); sr.destroy() } catch (_: Exception) {}
                passed()
                return true
            }
            return false
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                if (!heard(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))) relisten(150)
            }
            override fun onPartialResults(partial: Bundle?) {
                heard(partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))
            }
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return
                relisten(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 250)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        listen()
        onDispose {
            alive = false
            handler.removeCallbacksAndMessages(null)
            try { sr.cancel(); sr.destroy() } catch (_: Exception) {}
            view.keepScreenOn = false
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black))
}

/** Hidden debug screen. The secret word is read from / written to the repo — it isn't stored in the app. */
@Composable
private fun DebugPanel(
    store: Store, onWordSaved: (String) -> Unit, onNameSaved: (String) -> Unit,
    onRepoSaved: () -> Unit,
    onCacheCleared: () -> Unit, onLock: () -> Unit, onForceUnlock: () -> Unit,
    onReset: () -> Unit, onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }
    var word by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var dbgName by remember { mutableStateOf(store.name) }
    var nameStatus by remember { mutableStateOf("") }
    var dbgRepo by remember { mutableStateOf(store.customRepo) }
    var repoStatus by remember { mutableStateOf("") }
    var toolStatus by remember { mutableStateOf("") }
    var cacheInfo by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var heard by remember { mutableStateOf("") }
    var simulateFailure by remember { mutableStateOf(DebugFlags.simulateSendFailure) }
    var verbosePolling by remember { mutableStateOf(DebugFlags.verbosePolling) }
    var pollMs by remember { mutableStateOf(DebugFlags.pollIntervalMs) }
    var confirmReset by remember { mutableStateOf(false) }
    var clearingChat by remember { mutableStateOf(false) }
    var msgFolder by remember { mutableStateOf("") }
    val micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    BackHandler(onBack = onClose)

    fun refreshCacheInfo() {
        val chat = msgCacheFile(ctx, store.repo, store.branch)
        cacheInfo = "chat ${humanBytes(chat.length())} · media ${humanBytes(dirSize(File(ctx.cacheDir, "n/media")))}"
    }

    suspend fun load() {
        val r = repo; val c = client
        if (r == null || c == null) { status = "No repo/token configured."; loaded = true; return }
        working = true; status = "Loading word from repo…"
        try {
            val w = c.readFile(SECRET_PATH, r)?.trim()
            if (w == null) { status = "No word set in the repo yet ($SECRET_PATH). Type one and [save]." }
            else { word = w; status = "" }
        } catch (e: Exception) { status = "Couldn't load: ${errText(e)}" }
        working = false; loaded = true
    }
    LaunchedEffect(Unit) { load(); refreshCacheInfo() }

    fun clearChatHistory() {
        val r = repo; val c = client
        if (r == null || c == null) { toolStatus = "No repo/token configured."; return }
        scope.launch {
            clearingChat = true
            toolStatus = "Clearing chat history…"
            try {
                withContext(Dispatchers.IO) {
                    try { c.deleteTree(MSG_DIR, r, "n: clear chat history") }
                    catch (e: Exception) { c.deleteAll(MSG_DIR, r, "n: clear chat history") }   // slow fallback
                    msgCacheFile(ctx, store.repo, store.branch).delete()
                    File(ctx.cacheDir, "n/media").deleteRecursively()
                }
                refreshCacheInfo(); onCacheCleared()
                toolStatus = "Chat history cleared."; DebugLog.add("chat history cleared")
            } catch (e: Exception) {
                toolStatus = "Couldn't clear history: ${errText(e)}"; DebugLog.add("clear failed: ${errText(e)}")
            }
            clearingChat = false
        }
    }

    // Voice test: one-shot listen that shows what the recognizer heard and whether it matches the word typed above.
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) { heard = ""; testing = true } }
    DisposableEffect(testing) {
        if (!testing) return@DisposableEffect onDispose {}
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            heard = "(no speech recognizer on this device)"; testing = false
            return@DisposableEffect onDispose {}
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard = it }
                testing = false
            }
            override fun onPartialResults(partial: Bundle?) {
                partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard = it }
            }
            override fun onError(error: Int) { if (heard.isBlank()) heard = "(nothing heard — error $error)"; testing = false }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { sr.startListening(intent) } catch (e: Exception) { heard = "(couldn't start: ${e.message})"; testing = false }
        onDispose { try { sr.cancel(); sr.destroy() } catch (_: Exception) {} }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().imePadding()
            .padding(horizontal = 14.dp, vertical = 12.dp).verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("debug", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }

        // ---- info
        Text("${store.repo} @ ${store.branch} · v${BuildConfig.VERSION_NAME} · token ${if (store.token.isBlank()) "MISSING" else "set"}",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Text("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MODEL}", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Text("mic ${if (micGranted) "granted" else "denied"} · speech service ${if (SpeechRecognizer.isRecognitionAvailable(ctx)) "yes" else "no"} · cache $cacheInfo",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp)

        // ---- secret word
        Spacer(Modifier.height(16.dp))
        Text("Secret word (stored in the repo at $SECRET_PATH):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        NTextField(word, { word = it }, "secret word", password = !show)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = { show = !show }) { Text(if (show) "[hide]" else "[show]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { scope.launch { load() } }, enabled = !working) { Text("[reload]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(
                enabled = !working && loaded && word.isNotBlank(),
                onClick = {
                    val r = repo; val c = client; if (r == null || c == null) return@TextButton
                    val w = word.trim()
                    scope.launch {
                        working = true; status = "Saving…"
                        try {
                            withContext(Dispatchers.IO) { c.writeFile(SECRET_PATH, w, "n: config", r) }
                            word = w; onWordSaved(w); status = "Saved to the repo."; DebugLog.add("secret word updated")
                        } catch (e: Exception) { status = "Couldn't save: ${errText(e)}"; DebugLog.add("secret save failed: ${errText(e)}") }
                        working = false
                    }
                }
            ) { Text("[save]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
        if (status.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
        }

        // ---- name
        Spacer(Modifier.height(20.dp))
        Text("Your name (can only be changed here):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        NTextField(dbgName, { dbgName = it }, "me")
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                val n = dbgName.trim().ifBlank { "me" }
                store.name = n; dbgName = n; onNameSaved(n); nameStatus = "Name changed to \"$n\"."; DebugLog.add("name changed")
            }) { Text("[save name]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            if (nameStatus.isNotEmpty()) Text(nameStatus, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }

        // ---- custom repo
        Spacer(Modifier.height(20.dp))
        Text("Custom shared repo (overrides the built-in default; \"owner/name\", blank = use default):",
            color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        NTextField(dbgRepo, { dbgRepo = it }, "owner/name")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                val v = dbgRepo.trim()
                if (v.isNotBlank() && RepoRef.parse(v) == null) {
                    repoStatus = "Bad repo format — expected \"owner/name\"."
                } else {
                    store.customRepo = v; dbgRepo = v; onRepoSaved()
                    repoStatus = if (v.isBlank()) "Using default repo." else "Now using \"$v\"."
                    DebugLog.add("repo changed to \"${store.repo}\"")
                }
            }) { Text("[save repo]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            TextButton(onClick = {
                store.customRepo = ""; dbgRepo = ""; onRepoSaved()
                repoStatus = "Using default repo."; DebugLog.add("repo reset to default")
            }) { Text("[use default]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            if (repoStatus.isNotEmpty()) Text(repoStatus, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }

        // ---- test tools
        Spacer(Modifier.height(20.dp))
        Text("Tools:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    toolStatus = "Pinging GitHub…"
                    toolStatus = try { c.ping(r) } catch (e: Exception) { "Ping failed: ${errText(e)}" }
                    DebugLog.add("ping: $toolStatus")
                }
            }) { Text("[ping github]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    val me = store.name.ifBlank { "me" }
                    val ts = System.currentTimeMillis()
                    val path = "${msgDirFor(ts)}/$ts-${UUID.randomUUID().toString().take(6)}.json"
                    toolStatus = "Sending test message…"
                    try {
                        val body = JSONObject().apply { put("from", me); put("ts", ts); put("type", "TEXT"); put("text", "[debug] test message") }
                        withContext(Dispatchers.IO) { c.commitFile(path, body.toString(), "n: debug test", r) }
                        toolStatus = "Test message sent."; DebugLog.add("test message sent")
                    } catch (e: Exception) { toolStatus = "Test failed: ${errText(e)}"; DebugLog.add("test message failed: ${errText(e)}") }
                }
            }) { Text("[test message]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) {
                        msgCacheFile(ctx, store.repo, store.branch).delete()
                        File(ctx.cacheDir, "n/media").deleteRecursively()
                    }
                    refreshCacheInfo(); onCacheCleared(); toolStatus = "Local cache cleared."; DebugLog.add("local cache cleared")
                }
            }) { Text("[clear cache]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                if (testing) testing = false
                else if (micGranted) { heard = ""; testing = true }
                else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (testing) "[stop voice test]" else "[test voice]", color = if (testing) Warn else Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        if (toolStatus.isNotEmpty()) Text(toolStatus, color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        if (testing || heard.isNotEmpty()) {
            Text("heard: ${heard.ifEmpty { "…" }}", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
            if (word.isNotBlank() && heard.isNotBlank() && !heard.startsWith("(")) {
                val ok = normalizeSpeech(heard).contains(normalizeSpeech(word))
                Text(if (ok) "matches the word above" else "doesn't match the word above", color = if (ok) Accent else Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
        }

        // ---- more tools
        Spacer(Modifier.height(16.dp))
        Text("More tools:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = onForceUnlock) { Text("[force unlock]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    toolStatus = "Checking rate limit…"
                    toolStatus = try {
                        withContext(Dispatchers.IO) { c.rateLimit() }
                    } catch (e: Exception) { "Rate limit check failed: ${errText(e)}" }
                    DebugLog.add("rate limit: $toolStatus")
                }
            }) { Text("[rate limit]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    // Messages live under one subfolder per month now (Msg/<bucket>/...), so list
                    // this month's bucket — that's the one the running app is actually polling.
                    val bucket = msgDirFor(System.currentTimeMillis())
                    toolStatus = "Listing $bucket…"
                    try {
                        val files = withContext(Dispatchers.IO) { c.listFiles(bucket, r) }
                        val bucketDirs = withContext(Dispatchers.IO) { c.listFiles(MSG_DIR, r) }.count { it.isDir }
                        msgFolder = files.joinToString("\n") { it.path }
                        toolStatus = "${files.size} entries in $bucket ($bucketDirs month-folder(s) total)."
                        DebugLog.add("listed $bucket: ${files.size} entries")
                    } catch (e: Exception) { toolStatus = "Listing failed: ${errText(e)}"; DebugLog.add("list failed: ${errText(e)}") }
                }
            }) { Text("[list msg folder]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { clearChatHistory() }, enabled = !clearingChat) {
                Text(if (clearingChat) "[clearing…]" else "[clear]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                simulateFailure = !simulateFailure; DebugFlags.simulateSendFailure = simulateFailure
                DebugLog.add("simulate send failure: ${if (simulateFailure) "ON" else "off"}")
            }) {
                Text(
                    if (simulateFailure) "[simulate failure: ON]" else "[simulate failure: off]",
                    color = if (simulateFailure) Warn else Ink, fontFamily = TermFont, fontSize = 13.sp
                )
            }
            TextButton(onClick = {
                verbosePolling = !verbosePolling; DebugFlags.verbosePolling = verbosePolling
                DebugLog.add("verbose polling: ${if (verbosePolling) "ON" else "off"}")
            }) {
                Text(
                    if (verbosePolling) "[verbose polling: ON]" else "[verbose polling: off]",
                    color = if (verbosePolling) Accent else Ink, fontFamily = TermFont, fontSize = 13.sp
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("poll every:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            listOf(250L to "250ms", 1000L to "1s", 5000L to "5s", 15000L to "15s").forEach { (ms, label) ->
                TextButton(onClick = { pollMs = ms; DebugFlags.pollIntervalMs = ms; DebugLog.add("poll interval set to $label") }) {
                    Text(if (pollMs == ms) "[$label]" else label, color = if (pollMs == ms) Accent else Ink, fontFamily = TermFont, fontSize = 12.sp)
                }
            }
        }
        if (msgFolder.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(msgFolder, color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                val report = buildString {
                    appendLine("N debug report")
                    appendLine("repo: ${store.repo} @ ${store.branch}")
                    appendLine("version: ${BuildConfig.VERSION_NAME}")
                    appendLine("token: ${if (store.token.isBlank()) "MISSING" else "set (" + store.token.take(4) + "…)"}")
                    appendLine("name: ${store.name}")
                    appendLine("android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MODEL}")
                    appendLine("mic: ${if (micGranted) "granted" else "denied"} · speech service: ${if (SpeechRecognizer.isRecognitionAvailable(ctx)) "yes" else "no"}")
                    appendLine("cache: $cacheInfo")
                    appendLine("simulate failure: $simulateFailure · verbose polling: $verbosePolling · poll interval: ${pollMs}ms")
                    appendLine("---- log tail ----")
                    DebugLog.lines.takeLast(30).forEach { appendLine(it) }
                }
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("N debug report", report))
                Toast.makeText(ctx, "Debug report copied", Toast.LENGTH_SHORT).show()
                DebugLog.add("debug report copied")
            }) { Text("[copy debug report]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }

        // ---- log
        Spacer(Modifier.height(20.dp))
        val log = DebugLog.lines
        Text("Log (${log.size}):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        if (log.isEmpty()) Text("(empty)", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        log.takeLast(30).forEach { Text(it, color = Dim, fontFamily = TermFont, fontSize = 10.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("N log", log.joinToString("\n")))
                Toast.makeText(ctx, "Log copied", Toast.LENGTH_SHORT).show()
            }) { Text("[copy log]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { log.clear() }) { Text("[clear log]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            TextButton(onClick = onLock) { Text("[lock now]", color = Warn, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { confirmReset = true }) { Text("[reset app]", color = Warn, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset this app?", fontFamily = TermFont) },
            text = { Text("Clears your saved name and branch on this device and drops you back at setup. Chat history in the repo is untouched.", fontFamily = TermFont, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; onReset() }) {
                    Text("[reset]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("[cancel]", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

@Composable
private fun SetupForm(
    nameText: String, status: String,
    onName: (String) -> Unit,
    canCancel: Boolean, onCancel: () -> Unit, onSave: () -> Unit
) {
    Text("Your name (shown on your messages):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    NTextField(nameText, onName, "me")
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        TextButton(onClick = onSave) { Text("[save]", color = Accent, fontFamily = TermFont, fontSize = 14.sp) }
        if (canCancel) TextButton(onClick = onCancel) { Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
    }
    if (status.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
    }
}

@Composable
private fun NTextField(value: String, onChange: (String) -> Unit, placeholder: String, password: Boolean = false) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(placeholder, color = Dim, fontFamily = TermFont) },
        visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Raised, unfocusedContainerColor = Raised,
            focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ColumnScope.ChatBody(store: Store) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    var messages by remember { mutableStateOf(listOf<ChatMsg>()) }
    val known = remember { mutableSetOf<String>() }
    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<ChatMsg?>(null) }   // message currently being replied to
    var busy by remember { mutableStateOf(false) }          // a photo/video/voice upload is in progress
    var status by remember { mutableStateOf("") }
    var viewing by remember { mutableStateOf<Pair<File, String>?>(null) }   // photo open full-screen: (file, mediaPath)
    var cacheReady by remember { mutableStateOf(false) }
    val sendLock = remember { Mutex() }                     // commits to one branch go out one at a time
    val listState = rememberLazyListState()
    val cacheFile = remember(store.repo, store.branch) { msgCacheFile(ctx, store.repo, store.branch) }

    // ---- month-bucket history (see msgDirFor/bucketOf near the top of the file) ----
    var pollBucket by remember { mutableStateOf(bucketFor(System.currentTimeMillis())) }   // bucket poll() is watching live
    var messageBuckets by remember { mutableStateOf(listOf<String>()) }                    // every month-folder that exists in the repo, ascending
    var loadingOlder by remember { mutableStateOf(false) }
    // Recomputed each recomposition — cheap, and `messages`/`messageBuckets` already drive recomposition here.
    val earliestLoadedBucket = messages.map { bucketOf(it.path) }.minOrNull()
    val canLoadOlder = messageBuckets.any { b -> earliestLoadedBucket == null || b < earliestLoadedBucket }

    // ---- calling ----
    val callManager = remember(client, repo) { CallManager(ctx.applicationContext, scope, client, repo, store) }
    DisposableEffect(callManager) { onDispose { callManager.dispose() } }
    LaunchedEffect(callManager) { while (true) { callManager.poll(); delay(CALL_POLL_MS) } }
    var callMinimized by remember { mutableStateOf(false) }          // call tucked into the floating mini window
    LaunchedEffect(callManager.ui?.callId) { callMinimized = false }  // a new call always opens full-screen
    var pendingCallAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    val callPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val micOk = result[Manifest.permission.RECORD_AUDIO]
            ?: (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        if (micOk) pendingCallAction?.invoke() else status = "Microphone permission is needed to call."
        pendingCallAction = null
    }
    fun requestCallPermsThen(video: Boolean, action: () -> Unit) {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (video && ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.CAMERA
        // So the "call in progress" foreground-service notification (the thing that keeps the call
        // alive once you leave the app) can actually be shown, not just silently running.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) action() else { pendingCallAction = action; callPermLauncher.launch(need.toTypedArray()) }
    }

    // Screenshare: Android's own system dialog asks the person operating THIS phone to confirm
    // sharing THEIR OWN screen — it can't be used to capture anyone else's device. The result
    // Intent is handed straight to CallManager, which needs it to start the WebRTC screen capturer.
    val projectionManager = remember { ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    val screenShareLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == android.app.Activity.RESULT_OK && data != null) {
            callManager.startScreenShare(data)
        } else {
            status = "Screen share permission was declined."
        }
    }
    val notifPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun requestScreenShare() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        screenShareLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    // If either of these is null, nothing below can talk to GitHub at all. Surface that
    // clearly instead of every call silently no-op'ing (see poll()/sendText()/etc below).
    val configError = when {
        repo == null -> "Bad repo format (\"${store.repo}\") — expected \"owner/name\"."
        client == null -> "No GitHub token configured. If this is a local build, fill in " +
            "local.properties. If this came from CI, add the N_GH_TOKEN repo secret and rerun the build."
        else -> null
    }

    // Lists one month-bucket folder and folds in whatever's new there. Shared by the live poll
    // loop (called on `pollBucket`, every second) and [load earlier messages] (called once per
    // older bucket, on demand).
    suspend fun pollDir(dir: String) {
        val r = repo ?: return
        val c = client ?: return
        if (DebugFlags.verbosePolling) DebugLog.add("poll: checking $dir")
        val files = try {
            c.listFiles(dir, r)
        } catch (e: GitHubApiException) {
            status = "Couldn't check for messages: ${e.body.take(80)}"; DebugLog.add("poll error: HTTP ${e.code}"); return
        } catch (e: Exception) {
            status = "Couldn't check for messages: ${e.message ?: "unknown error"}"; DebugLog.add("poll error: ${e.message?.take(60)}"); return
        }
        val jsonFiles = files.filter { !it.isDir && it.path.endsWith(".json") }

        // Drop messages that were deleted remotely (e.g. the other person hit [clear]). Scoped to
        // this bucket's own messages only — messages loaded from *other* buckets aren't part of
        // this listing and must never be treated as "gone" just because they're not in it.
        val listed = jsonFiles.mapTo(HashSet()) { it.path }
        val recent = System.currentTimeMillis() - 30_000
        val gone = messages.filter { !it.pending && it.path.startsWith("$dir/") && it.path !in listed && it.ts < recent }
            .mapTo(HashSet()) { it.path }
        if (gone.isNotEmpty()) { messages = messages.filter { it.path !in gone }; known.removeAll(gone) }

        val newOnes = jsonFiles.filter { it.path !in known }
        if (newOnes.isEmpty()) {
            if (DebugFlags.verbosePolling) DebugLog.add("poll: ${jsonFiles.size} files in $dir, 0 new")
            return
        }

        // Fetch all new message files at once (a few at a time) instead of one after another.
        val gate = Semaphore(FETCH_PARALLELISM)
        val parsed = coroutineScope {
            newOnes.sortedBy { it.path }.map { f -> async { gate.withPermit { fetchMessage(c, r, f.path, known) } } }.awaitAll()
        }.filterNotNull()
        for (m in parsed) known += m.path
        if (parsed.isNotEmpty()) { messages = (messages + parsed).sortedBy { it.ts }; status = "" }
        if (DebugFlags.verbosePolling) DebugLog.add("poll: ${jsonFiles.size} files in $dir, ${parsed.size} new")
    }

    suspend fun poll() {
        val nowBucket = bucketFor(System.currentTimeMillis())
        if (nowBucket != pollBucket) {
            // The calendar month just rolled over. Give the outgoing bucket one last check for
            // any straggler committed right at the boundary, fold it into the known bucket list
            // as history, then start following the new one.
            pollDir("$MSG_DIR/$pollBucket")
            if (pollBucket !in messageBuckets) messageBuckets = (messageBuckets + pollBucket).sorted()
            DebugLog.add("poll: rolled over from $pollBucket to $nowBucket")
            pollBucket = nowBucket
        }
        if (nowBucket !in messageBuckets) messageBuckets = (messageBuckets + nowBucket).sorted()
        pollDir("$MSG_DIR/$pollBucket")
    }

    /** [load earlier messages]: fetches one whole older month-bucket and prepends it to the chat. */
    fun loadOlderBucket() {
        val r = repo ?: return; val c = client ?: return
        if (loadingOlder) return
        val prevBucket = messageBuckets.filter { earliestLoadedBucket == null || it < earliestLoadedBucket }.maxOrNull()
        if (prevBucket == null) { status = "No earlier messages."; return }
        scope.launch {
            loadingOlder = true
            val anchorPath = messages.getOrNull(listState.firstVisibleItemIndex)?.path
            try {
                val dir = "$MSG_DIR/$prevBucket"
                val files = try { c.listFiles(dir, r) } catch (e: Exception) {
                    status = "Couldn't load $prevBucket: ${errText(e)}"; null
                }
                val jsonFiles = files?.filter { !it.isDir && it.path.endsWith(".json") } ?: emptyList()
                val gate = Semaphore(FETCH_PARALLELISM)
                val parsed = coroutineScope {
                    jsonFiles.map { f -> async { gate.withPermit { fetchMessage(c, r, f.path, known) } } }.awaitAll()
                }.filterNotNull()
                for (m in parsed) known += m.path
                if (parsed.isNotEmpty()) messages = (messages + parsed).sortedBy { it.ts }
                status = if (files != null && parsed.isEmpty()) "No messages found in $prevBucket." else ""
                // Keep the same message anchored on screen instead of the view jumping as older
                // messages are inserted above it.
                anchorPath?.let { p ->
                    val idx = messages.indexOfFirst { it.path == p }
                    if (idx >= 0) listState.scrollToItem(idx)
                }
            } finally { loadingOlder = false }
        }
    }

    LaunchedEffect(store.repo, store.token, store.branch) {
        messages = emptyList(); known.clear(); cacheReady = false
        messageBuckets = emptyList(); pollBucket = bucketFor(System.currentTimeMillis())
        if (configError != null) { status = configError; return@LaunchedEffect }
        // Show the last-seen chat instantly, then catch up with whatever's new.
        val cached = withContext(Dispatchers.IO) { loadMsgCache(cacheFile) }
        messages = cached; known.addAll(cached.map { it.path }); cacheReady = true
        if (repo != null && client != null) {
            // Discover which month-folders exist at all, so [load earlier messages] knows what's
            // available before the user ever taps it. Best-effort: if this fails, older buckets
            // are still picked up lazily (e.g. the next time one is fetched via poll()).
            try {
                val dirs = client.listFiles(MSG_DIR, repo).filter { it.isDir }.map { it.path.substringAfterLast('/') }
                messageBuckets = (dirs + pollBucket).distinct().sorted()
            } catch (_: Exception) {}
            while (true) { poll(); delay(DebugFlags.pollIntervalMs) }
        }
    }
    LaunchedEffect(messages, cacheReady) {
        if (!cacheReady) return@LaunchedEffect
        delay(400)
        val snapshot = messages
        withContext(Dispatchers.IO) { saveMsgCache(cacheFile, snapshot) }
    }
    // Keyed on the *last* message rather than the list size: loading an older bucket via
    // [load earlier messages] also changes messages.size (by prepending), but doesn't change what
    // the newest message is, so it correctly won't yank the view back down to the bottom.
    LaunchedEffect(messages.lastOrNull()?.path) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    fun markSent(path: String) { messages = messages.map { if (it.path == path) it.copy(pending = false) else it } }
    fun dropFailed(path: String) { known -= path; messages = messages.filter { it.path != path } }

    // Text goes on screen instantly; the commit happens in the background.
    fun sendText(text: String) {
        val r = repo ?: return; val c = client ?: run { status = configError ?: "Not configured."; return }
        val trimmed = text.trim(); if (trimmed.isEmpty()) return
        input = ""
        val target = replyTo; val rr = target?.toReplyRef(); replyTo = null
        val me = store.name.ifBlank { "me" }
        val ts = System.currentTimeMillis()
        val path = "${msgDirFor(ts)}/$ts-${UUID.randomUUID().toString().take(6)}.json"
        known += path
        messages = messages + ChatMsg(path, me, ts, MsgType.TEXT, text = trimmed, pending = true, reply = rr)
        scope.launch {
            try {
                if (DebugFlags.simulateSendFailure) throw Exception("Simulated failure (debug)")
                val body = JSONObject().apply { put("from", me); put("ts", ts); put("type", "TEXT"); put("text", trimmed); rr?.let { putReply(it) } }
                sendLock.withLock { c.commitFile(path, body.toString(), "n: text", r) }
                markSent(path)
            } catch (e: Exception) {
                dropFailed(path)
                if (input.isBlank()) input = trimmed
                if (replyTo == null) replyTo = target
                status = "Failed to send: ${errText(e)}"; DebugLog.add("send failed: ${errText(e)}")
            }
        }
    }

    /** [local] is already in the media cache, so the bubble shows it right away while it uploads. */
    suspend fun sendMediaFile(local: File, mediaPath: String, type: MsgType, ts: Long, durationMs: Long = 0L, reply: ReplyRef? = null) {
        val r = repo; val c = client
        if (r == null || c == null) { local.delete(); status = configError ?: "Not configured."; busy = false; return }
        val me = store.name.ifBlank { "me" }
        val label = type.name.lowercase()
        val jsonPath = "${msgDirFor(ts)}/$ts-${UUID.randomUUID().toString().take(6)}.json"
        busy = true
        status = "Uploading $label…"
        known += jsonPath
        messages = messages + ChatMsg(jsonPath, me, ts, type, mediaPath = mediaPath, durationMs = durationMs, pending = true, reply = reply)
        try {
            if (DebugFlags.simulateSendFailure) throw Exception("Simulated failure (debug)")
            sendLock.withLock {
                c.commitFileStream(mediaPath, local, "n: $label", r) { pct -> status = "Uploading $label… $pct%" }
                val body = JSONObject().apply {
                    put("from", me); put("ts", ts); put("type", type.name); put("media", mediaPath)
                    if (durationMs > 0) put("duration", durationMs)
                    reply?.let { putReply(it) }
                }
                c.commitFile(jsonPath, body.toString(), "n: $label", r)
            }
            markSent(jsonPath)
            status = ""
        } catch (e: Exception) {
            dropFailed(jsonPath); local.delete()
            status = "Failed to send: ${errText(e)}"; DebugLog.add("$label send failed: ${errText(e)}")
        }
        busy = false
    }

    /**
     * Deletes one of your own messages for everyone: the message file (and any photo/video/voice file it
     * uploaded) is removed from the repo, and the other phone drops it on its next poll. It disappears here
     * immediately; if the repo refuses, it comes back with an error. Shared stickers are never deleted.
     */
    fun deleteMessage(m: ChatMsg) {
        val r = repo ?: return; val c = client ?: run { status = configError ?: "Not configured."; return }
        if (m.pending) return
        messages = messages.filter { it.path != m.path }
        scope.launch {
            try {
                if (DebugFlags.simulateSendFailure) throw Exception("Simulated failure (debug)")
                val sha = c.listFiles(m.path.substringBeforeLast('/'), r).firstOrNull { it.path == m.path }?.sha
                if (sha != null) sendLock.withLock { c.deleteFile(m.path, sha, "n: delete message", r) }
                if (m.mediaPath.startsWith("$MSG_MEDIA_DIR/")) {
                    try {
                        c.listFiles(MSG_MEDIA_DIR, r).firstOrNull { it.path == m.mediaPath }
                            ?.let { c.deleteFile(it.path, it.sha, "n: delete media", r) }
                    } catch (e: Exception) { DebugLog.add("delete: media cleanup failed: ${errText(e)}") }
                    mediaCacheFile(ctx, m.mediaPath).delete()
                }
                DebugLog.add("message deleted")
            } catch (e: Exception) {
                messages = (messages + m).sortedBy { it.ts }
                status = "Couldn't delete: ${errText(e)}"; DebugLog.add("delete failed: ${errText(e)}")
            }
        }
    }

    /** An emoji sticker ([text]) or a shared custom sticker already in the repo ([media]). Nothing is uploaded. */
    fun sendSticker(text: String = "", media: String = "") {
        val r = repo ?: return; val c = client ?: run { status = configError ?: "Not configured."; return }
        val rr = replyTo?.toReplyRef(); replyTo = null
        val me = store.name.ifBlank { "me" }
        val ts = System.currentTimeMillis()
        val path = "${msgDirFor(ts)}/$ts-${UUID.randomUUID().toString().take(6)}.json"
        known += path
        messages = messages + ChatMsg(path, me, ts, MsgType.STICKER, text = text, mediaPath = media, pending = true, reply = rr)
        scope.launch {
            try {
                if (DebugFlags.simulateSendFailure) throw Exception("Simulated failure (debug)")
                val body = JSONObject().apply {
                    put("from", me); put("ts", ts); put("type", "STICKER"); put("text", text); put("media", media)
                    rr?.let { putReply(it) }
                }
                sendLock.withLock { c.commitFile(path, body.toString(), "n: sticker", r) }
                markSent(path)
            } catch (e: Exception) {
                dropFailed(path)
                status = "Failed to send: ${errText(e)}"; DebugLog.add("sticker send failed: ${errText(e)}")
            }
        }
    }

    /** Downloads a GIF from search results and sends it like a photo (it animates in the chat). */
    fun sendGifUrl(url: String) {
        val rr = replyTo?.toReplyRef(); replyTo = null
        scope.launch {
            busy = true; status = "Downloading gif…"
            val ts = System.currentTimeMillis()
            val mediaPath = "$MSG_MEDIA_DIR/$ts.gif"
            val dest = mediaCacheFile(ctx, mediaPath)
            if (!Giphy.download(url, dest)) { status = "Couldn't download that gif."; busy = false; return@launch }
            sendMediaFile(dest, mediaPath, MsgType.PHOTO, ts, 0L, rr)
        }
    }

    fun sendMedia(uri: Uri, type: MsgType) {
        val rr = replyTo?.toReplyRef(); replyTo = null
        scope.launch {
            busy = true
            status = "Preparing ${type.name.lowercase()}…"
            val ts = System.currentTimeMillis()
            val ext = if (type == MsgType.PHOTO) photoExt(ctx.contentResolver.getType(uri).orEmpty()) else "mp4"
            val mediaPath = "$MSG_MEDIA_DIR/$ts.$ext"
            val local = mediaCacheFile(ctx, mediaPath)
            val copied = withContext(Dispatchers.IO) {
                try {
                    val stream = ctx.contentResolver.openInputStream(uri) ?: return@withContext false
                    local.parentFile?.mkdirs()
                    stream.use { i -> local.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                    true
                } catch (e: Exception) { false }
            }
            if (!copied) { local.delete(); status = "Couldn't read that file."; busy = false; return@launch }
            if (local.length() > MAX_MEDIA_BYTES) {
                val size = local.length(); local.delete()
                status = "That's ${humanBytes(size)} — the max is ${humanBytes(MAX_MEDIA_BYTES)}."
                busy = false; return@launch
            }
            sendMediaFile(local, mediaPath, type, ts, reply = rr)
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(uri, MsgType.PHOTO) }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(uri, MsgType.VIDEO) }
    val gifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(uri, MsgType.PHOTO) }

    var stickerPickerOpen by remember { mutableStateOf(false) }
    var stickerRefresh by remember { mutableStateOf(0) }
    val stickerAddLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val c = client; val r = repo
        if (uri != null && c != null && r != null) scope.launch {
            status = "Adding sticker…"
            val err = Stickers.add(ctx, c, r, uri)
            status = if (err == null) "" else "Couldn't add sticker: $err"
            stickerRefresh++
        }
    }
    var pendingVoice by remember { mutableStateOf<File?>(null) }     // recorded, waiting for a voice pick + send
    var pendingVoiceMs by remember { mutableStateOf(0L) }

    var hasMicPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var recordStartMs by remember { mutableStateOf(0L) }
    var isRecording by remember { mutableStateOf(false) }
    var recordedSec by remember { mutableStateOf(0) }

    fun startRecording() {
        if (busy || isRecording) return
        val dir = File(ctx.cacheDir, "n").apply { mkdirs() }
        val file = File(dir, "rec-${System.currentTimeMillis()}.m4a")
        // Highest quality first (48 kHz, 256 kbps AAC — the default is a thin 8 kHz "phone call" sound).
        // If a phone's encoder refuses that, step down to safer settings instead of failing.
        val configs = listOf(48_000 to 256_000, 44_100 to 192_000, 44_100 to 128_000, 0 to 0)
        var started: MediaRecorder? = null
        var lastError = ""
        for ((rate, bitrate) in configs) {
            val rec = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                if (rate > 0) { setAudioChannels(1); setAudioSamplingRate(rate); setAudioEncodingBitRate(bitrate) }
                setOutputFile(file.absolutePath)
            }
            try {
                rec.prepare(); rec.start()
                started = rec; break
            } catch (e: Exception) {
                lastError = e.message ?: "unknown error"
                try { rec.release() } catch (_: Exception) {}
            }
        }
        val rec = started
        if (rec == null) { status = "Couldn't start recording: $lastError"; return }
        recorder = rec; recordingFile = file; recordStartMs = System.currentTimeMillis()
        isRecording = true; recordedSec = 0; status = ""
    }

    fun stopRecording(send: Boolean) {
        val rec = recorder ?: return
        val file = recordingFile
        val durationMs = System.currentTimeMillis() - recordStartMs
        isRecording = false; recorder = null; recordingFile = null
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
        if (send && file != null && durationMs >= 500) {
            // Hold it here so a voice effect can be chosen and previewed first (see VoiceBar).
            pendingVoice = file; pendingVoiceMs = durationMs
        } else {
            file?.delete()
            if (send) status = "Recording was too short."
        }
    }

    /** [file] is the recording as it should be sent: the original .m4a, or a processed .wav. */
    fun sendVoice(file: File, ext: String, ms: Long) {
        val ts = System.currentTimeMillis()
        val mediaPath = "$MSG_MEDIA_DIR/$ts.$ext"
        val dest = mediaCacheFile(ctx, mediaPath)
        dest.parentFile?.mkdirs()
        if (!file.renameTo(dest)) { file.copyTo(dest, overwrite = true); file.delete() }
        val rr = replyTo?.toReplyRef(); replyTo = null
        scope.launch { sendMediaFile(dest, mediaPath, MsgType.VOICE, ts, ms, rr) }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasMicPermission = granted
        if (granted) startRecording()
    }

    LaunchedEffect(isRecording) {
        while (isRecording) { delay(1000); recordedSec += 1 }
    }
    DisposableEffect(Unit) {
        onDispose { recorder?.let { try { it.stop() } catch (_: Exception) {}; it.release() } }
    }

    Column(Modifier.fillMaxWidth()) {
        // Scrolls horizontally instead of clipping off-screen: on narrower/lower-density phones
        // this row is wider than the screen, which was silently cutting off [video call] (and
        // sometimes [clear]) with no visual indication anything was missing.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Starting a call rings everyone else in the shared repo; if someone's already on it,
            // anyone else who opens the app while it's ringing/active can [accept] to join too,
            // up to MAX_CALL_PARTICIPANTS people total.
            TextButton(onClick = { requestCallPermsThen(false) { callManager.startCall(false) } }, enabled = callManager.ui == null) {
                Text("[call]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
            }
            TextButton(onClick = { requestCallPermsThen(true) { callManager.startCall(true) } }, enabled = callManager.ui == null) {
                Text("[video call]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
            }
            TextButton(onClick = { stickerPickerOpen = true }, enabled = !busy && !isRecording) {
                Text("[stickers & gifs]", color = Accent, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
    }

    if (stickerPickerOpen) {
        StickerGifPicker(
            client = client, repo = repo, refreshKey = stickerRefresh,
            onDismiss = { stickerPickerOpen = false },
            onEmoji = { sendSticker(text = it) },
            onRepoSticker = { sendSticker(media = it) },
            onAddStickerPick = { stickerAddLauncher.launch(arrayOf("image/*")) },
            onGifFromGallery = { gifLauncher.launch(arrayOf("image/gif")) },
            onGifUrl = { sendGifUrl(it) },
        )
    }

    callManager.ui?.let { st ->
        if (CallPip.inPip) {
            CallPipView(st, callManager.localVideo, callManager.eglBaseContext)
        } else if (callMinimized && st.phase != CallPhase.RINGING_IN) {
            // Minimized: the call keeps running in a small draggable window, and the chat is usable underneath.
            CallMiniWindow(
                state = st, localVideo = callManager.localVideo, eglBaseContext = callManager.eglBaseContext,
                onExpand = { callMinimized = false },
                onToggleMute = callManager::toggleMute, onHangup = callManager::hangup,
            )
        } else {
            CallOverlay(
                state = st, localVideo = callManager.localVideo, localScreenTrack = callManager.localScreenTrack,
                eglBaseContext = callManager.eglBaseContext,
                onAccept = { requestCallPermsThen(st.video) { callManager.accept() } },
                onDecline = callManager::decline, onHangup = callManager::hangup,
                onToggleMute = callManager::toggleMute, onSwitchCamera = callManager::switchCamera,
                onToggleSpeaker = callManager::toggleSpeaker,
                onStartScreenShare = { requestScreenShare() }, onStopScreenShare = { callManager.stopScreenShare() },
                onMinimize = { callMinimized = true },
                filterName = callManager.filterName, onCycleFilter = callManager::cycleFilter,
            )
        }
    }
    Spacer(Modifier.height(6.dp))

    viewing?.let { (file, mediaPath) ->
        PhotoViewer(file, mediaPath, onClose = { viewing = null })
    }

    if (canLoadOlder) {
        Text(
            if (loadingOlder) "Loading earlier messages…" else "[load earlier messages]",
            color = if (loadingOlder) Dim else Accent,
            fontFamily = TermFont, fontSize = 12.sp,
            modifier = Modifier
                .padding(bottom = 6.dp)
                .clickable(enabled = !loadingOlder) { loadOlderBucket() }
        )
    }
    Box(Modifier.weight(1f).fillMaxWidth()) {
        if (messages.isEmpty()) {
            Text(status.ifEmpty { "No messages yet. Say hi below." }, color = Dim, fontFamily = TermFont, fontSize = 13.sp)
        } else {
            LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.path }) { m ->
                    MsgBubble(
                        m, mine = m.sender == store.name.ifBlank { "me" }, client = client, repo = repo,
                        onOpenPhoto = { f -> viewing = f to m.mediaPath },
                        onReply = { replyTo = m },
                        onDelete = { deleteMessage(m) },
                        onJump = { path ->
                            val idx = messages.indexOfFirst { it.path == path }
                            if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                        }
                    )
                }
            }
        }
    }
    if (status.isNotEmpty() && messages.isNotEmpty()) {
        Text(status, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
    }

    replyTo?.let { t ->
        Row(
            Modifier.fillMaxWidth().padding(bottom = 4.dp).clip(RoundedCornerShape(6.dp)).background(Raised),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(3.dp).height(36.dp).background(Accent))
            Column(Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 4.dp)) {
                Text("replying to ${Profiles.display(t.sender)}", color = Accent, fontFamily = TermFont, fontSize = 10.sp)
                Text(previewOf(t).ifBlank { "…" }, color = Dim, fontFamily = TermFont, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            TextButton(onClick = { replyTo = null }) { Text("[x]", color = Dim, fontFamily = TermFont, fontSize = 13.sp) }
        }
    }
    val pv = pendingVoice
    if (pv != null) VoiceBar(
        src = pv, durationMs = pendingVoiceMs,
        onDiscard = { pv.delete(); pendingVoice = null },
        onSend = { f, ext, ms ->
            pendingVoice = null
            sendVoice(f, ext, ms)
            if (f != pv) pv.delete()      // an effect was applied: the original recording is no longer needed
        }
    ) else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }, enabled = !busy && !isRecording) { Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        TextButton(onClick = { videoLauncher.launch(arrayOf("video/*")) }, enabled = !busy && !isRecording) { Text("[video]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        TextButton(
            onClick = {
                if (isRecording) stopRecording(send = true)
                else if (hasMicPermission) startRecording()
                else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            enabled = !busy || isRecording
        ) {
            Text(
                if (isRecording) "[● %d:%02d — stop]".format(recordedSec / 60, recordedSec % 60) else "[mic]",
                color = if (isRecording) Warn else Accent, fontFamily = TermFont, fontSize = 13.sp
            )
        }
        if (isRecording) {
            TextButton(onClick = { stopRecording(send = false) }) { Text("[cancel]", color = Dim, fontFamily = TermFont, fontSize = 13.sp) }
        }
        TextField(
            value = input, onValueChange = { input = it }, singleLine = true, enabled = !isRecording,
            placeholder = { Text("message…", color = Dim, fontFamily = TermFont) },
            textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { sendText(input) }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
            ),
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { sendText(input) }, enabled = input.isNotBlank()) {
            Text("[send]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun MsgBubble(
    m: ChatMsg, mine: Boolean, client: GitHubClient?, repo: RepoRef?,
    onOpenPhoto: (File) -> Unit, onReply: () -> Unit, onDelete: () -> Unit, onJump: (String) -> Unit
) {
    val bg = if (mine) Mine else Raised
    val align = if (mine) Alignment.End else Alignment.Start
    val threshold = with(LocalDensity.current) { 56.dp.toPx() }
    var dx by remember(m.path) { mutableStateOf(0f) }
    var menuOpen by remember(m.path) { mutableStateOf(false) }
    var confirmDelete by remember(m.path) { mutableStateOf(false) }

    // Swipe a message sideways (either direction) to reply, like Messenger. Long-press works too.
    Box(Modifier.fillMaxWidth()) {
        if (abs(dx) > threshold / 3) {
            Text(
                "↩", color = if (abs(dx) >= threshold) Accent else Dim, fontFamily = TermFont, fontSize = 18.sp,
                modifier = Modifier.align(if (dx > 0) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = 6.dp)
            )
        }
        Column(
            Modifier.fillMaxWidth()
                .offset { IntOffset(dx.roundToInt(), 0) }
                .pointerInput(m.path) {
                    detectHorizontalDragGestures(
                        onDragEnd = { if (abs(dx) >= threshold) onReply(); dx = 0f },
                        onDragCancel = { dx = 0f }
                    ) { change, amount ->
                        change.consume()
                        dx = (dx + amount * 0.6f).coerceIn(-threshold * 1.5f, threshold * 1.5f)
                    }
                },
            horizontalAlignment = align
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(m.sender, 20.dp)
                Spacer(Modifier.width(5.dp))
                Text("${Profiles.display(m.sender)} · ${if (m.pending) "sending…" else timeLabel(m.ts)}", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
            }
            Box(
                Modifier.widthIn(max = 260.dp).clip(RoundedCornerShape(6.dp))
                    .background(if (m.type == MsgType.STICKER && m.reply == null) Color.Transparent else bg)
                    // Long-press opens a small menu: reply, and (on your own messages) delete.
                    .pointerInput(m.path) { detectTapGestures(onLongPress = { menuOpen = true }) }
                    .padding(if (m.type == MsgType.STICKER && m.reply == null) 2.dp else 10.dp)
            ) {
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("reply", color = Ink, fontFamily = TermFont, fontSize = 14.sp) },
                        onClick = { menuOpen = false; onReply() }
                    )
                    if (mine && !m.pending) DropdownMenuItem(
                        text = { Text("delete", color = Warn, fontFamily = TermFont, fontSize = 14.sp) },
                        onClick = { menuOpen = false; confirmDelete = true }
                    )
                }
                if (confirmDelete) androidx.compose.ui.window.Dialog(onDismissRequest = { confirmDelete = false }) {
                    Column(Modifier.clip(RoundedCornerShape(10.dp)).background(Raised).padding(16.dp)) {
                        Text("Delete this message for everyone?", color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                        Text("It's removed from the shared repo, so it disappears on both phones.", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
                        Row {
                            TextButton(onClick = { confirmDelete = false; onDelete() }) {
                                Text("[delete]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            TextButton(onClick = { confirmDelete = false }) { Text("[keep]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
                        }
                    }
                }
                Column {
                    m.reply?.let { rp -> ReplyQuote(rp, onJump) }
                    when (m.type) {
                        MsgType.TEXT -> Text(m.text, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                        MsgType.STICKER ->
                            if (m.mediaPath.isNotBlank()) RepoImage(client, repo, m.mediaPath, 400, Modifier.size(140.dp))
                            else Text(m.text, fontSize = 64.sp)
                        else -> MediaBubble(m, client, repo, type = m.type, onOpenPhoto = onOpenPhoto)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(2.dp))
}

/** The small quoted block at the top of a reply. Tap it to jump to the original message. */
@Composable
private fun ReplyQuote(rp: ReplyRef, onJump: (String) -> Unit) {
    Row(
        Modifier.padding(bottom = 6.dp).height(IntrinsicSize.Min).clip(RoundedCornerShape(4.dp))
            .background(Ink.copy(alpha = 0.13f)).clickable { onJump(rp.path) }
    ) {
        Box(Modifier.width(2.dp).fillMaxHeight().background(Accent))
        Column(Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
            Text(Profiles.display(rp.from), color = Accent, fontFamily = TermFont, fontSize = 10.sp)
            Text(rp.preview.ifBlank { "…" }, color = Dim, fontFamily = TermFont, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MediaBubble(m: ChatMsg, client: GitHubClient?, repo: RepoRef?, type: MsgType, onOpenPhoto: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var file by remember(m.path) { mutableStateOf<File?>(null) }
    var error by remember(m.path) { mutableStateOf("") }
    var loading by remember(m.path) { mutableStateOf(false) }

    /** Gets the media onto disk (instant if it's already cached or we sent it ourselves). */
    fun load(onDone: (File?) -> Unit) {
        file?.let { onDone(it); return }
        val c = client ?: return; val r = repo ?: return
        loading = true; error = ""
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) {
                    val dest = mediaCacheFile(ctx, m.mediaPath)
                    if (dest.exists() && dest.length() > 0) dest
                    else if (c.downloadFile(m.mediaPath, r, dest)) dest else null
                }
            } catch (e: Exception) { error = e.message ?: "couldn't load"; null }
            if (result == null && error.isEmpty()) error = "not found"
            loading = false; file = result; onDone(result)
        }
    }

    when (type) {
        MsgType.PHOTO -> {
            LaunchedEffect(m.path) { if (file == null && error.isEmpty()) load {} }
            val f = file
            var thumb by remember(f) { mutableStateOf<Bitmap?>(null) }
            var decodeFailed by remember(f) { mutableStateOf(false) }
            LaunchedEffect(f) {
                if (f != null) {
                    val b = withContext(Dispatchers.IO) { decodeSampled(f, 720) }
                    if (b == null) decodeFailed = true else thumb = b
                }
            }
            val bmp = thumb
            if (f != null && f.extension.equals("gif", ignoreCase = true) && Build.VERSION.SDK_INT >= 28) {
                AnimatedGif(f, Modifier.width(220.dp), onClick = { onOpenPhoto(f) })
            } else when {
                bmp != null && f != null -> Image(
                    bmp.asImageBitmap(), contentDescription = "photo (tap to view or save)",
                    modifier = Modifier.widthIn(max = 240.dp).clickable { onOpenPhoto(f) }
                )
                decodeFailed -> Text("[photo couldn't be decoded]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                error.isNotEmpty() -> Text("[photo failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                loading || f != null -> Text("[loading photo…]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                else -> Text("[photo]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
        MsgType.VIDEO -> {
            Column {
                Text("[ video ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { load { f -> f?.let { openVideo(ctx, it) } } }, enabled = !loading) {
                    Text(if (loading) "[loading…]" else "[play]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (error.isNotEmpty()) Text("[video failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        MsgType.VOICE -> {
            var player by remember(m.path) { mutableStateOf<MediaPlayer?>(null) }
            var playing by remember(m.path) { mutableStateOf(false) }
            DisposableEffect(m.path) { onDispose { player?.release() } }

            fun playFile(f: File) {
                val mp = MediaPlayer().apply {
                    setDataSource(f.absolutePath)
                    setOnCompletionListener { playing = false }
                    prepare()
                    start()
                }
                player = mp; playing = true
            }

            val labelLen = if (m.durationMs > 0) {
                val s = (m.durationMs / 1000).toInt()
                " · %d:%02d".format(s / 60, s % 60)
            } else ""
            Column {
                Text("[ voice$labelLen ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                TextButton(
                    onClick = {
                        if (playing) {
                            player?.stop(); player?.release(); player = null; playing = false
                        } else {
                            load { f -> f?.let { playFile(it) } }
                        }
                    },
                    enabled = !loading
                ) {
                    Text(
                        if (loading) "[loading…]" else if (playing) "[■ stop]" else "[▶ play]",
                        color = Accent, fontFamily = TermFont, fontSize = 13.sp
                    )
                }
                if (error.isNotEmpty()) Text("[voice failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        MsgType.TEXT, MsgType.STICKER -> {}
    }
}

/** Full-screen photo with a [save] button that puts the original file in Pictures/N. */
@Composable
private fun PhotoViewer(file: File, mediaPath: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember(file) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(file) { bmp = withContext(Dispatchers.IO) { decodeSampled(file, 2048) } }

    val name = "N-" + mediaPath.substringAfterLast('/')
    val mime = mimeForExt(name.substringAfterLast('.', "jpg"))

    fun save() {
        scope.launch {
            val ok = withContext(Dispatchers.IO) { saveImageToGallery(ctx, file, name, mime) }
            Toast.makeText(ctx, if (ok) "Saved to Pictures/N" else "Couldn't save photo", Toast.LENGTH_SHORT).show()
        }
    }
    // Android 9 and older need a storage permission to write to Pictures; 10+ doesn't.
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) save() else Toast.makeText(ctx, "Storage permission is needed to save photos on this Android version", Toast.LENGTH_LONG).show()
    }
    fun onSaveClick() {
        val needsPermission = Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else save()
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), contentDescription = "photo", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                Text("[loading…]", color = Dim, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
            }
            Row(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = { onSaveClick() }, enabled = b != null) {
                    Text("[save]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 15.sp) }
            }
        }
    }
}

// ---------------- helpers ----------------

private fun previewOf(m: ChatMsg): String = when (m.type) {
    MsgType.TEXT -> m.text.replace('\n', ' ').take(80)
    MsgType.PHOTO -> "[photo]"
    MsgType.VIDEO -> "[video]"
    MsgType.VOICE -> "[voice message]"
    MsgType.STICKER -> if (m.text.isNotBlank()) m.text else "[sticker]"
}
private fun ChatMsg.toReplyRef() = ReplyRef(path, sender, previewOf(this))
private fun JSONObject.putReply(r: ReplyRef) { put("reply_to", r.path); put("reply_from", r.from); put("reply_text", r.preview) }
private fun dirSize(f: File): Long = if (!f.exists()) 0L else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

private fun errText(e: Exception): String = if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error"

/** Where a media file lives on this phone once downloaded (or before upload, for our own). */
internal fun mediaCacheFile(ctx: Context, mediaPath: String): File =
    File(ctx.cacheDir, "n/media/" + mediaPath.replace('/', '_'))

private fun photoExt(mime: String): String = when (mime.lowercase()) {
    "image/png" -> "png"
    "image/webp" -> "webp"
    "image/gif" -> "gif"
    "image/heic" -> "heic"
    "image/heif" -> "heif"
    else -> "jpg"
}

private fun mimeForExt(ext: String): String = when (ext.lowercase()) {
    "png" -> "image/png"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "heic" -> "image/heic"
    "heif" -> "image/heif"
    else -> "image/jpeg"
}

/** Decodes at reduced size so a 50 MB photo doesn't blow up memory. Result is at least [maxDim] px where possible. */
internal fun decodeSampled(file: File, maxDim: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}

/** Copies the original, full-quality file into the gallery (Pictures/N). */
private fun saveImageToGallery(ctx: Context, src: File, displayName: String, mime: String): Boolean = try {
    if (Build.VERSION.SDK_INT >= 29) {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/N")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) false else {
            val out = resolver.openOutputStream(uri)
            if (out == null) false else {
                out.use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } }
                values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            }
        }
    } else {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "N").apply { mkdirs() }
        val dest = File(dir, displayName)
        src.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
        true
    }
} catch (e: Exception) { false }

private fun openVideo(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    ctx.startActivity(intent)
}

// ---- message parsing + on-disk cache of the chat (so it appears instantly on launch) ----

private fun parseMsg(path: String, o: JSONObject) = ChatMsg(
    path = path, sender = o.optString("from", "them"), ts = o.optLong("ts", 0L),
    type = MsgType.valueOf(o.optString("type", "TEXT").uppercase()),
    text = o.optString("text", ""), mediaPath = o.optString("media", ""),
    durationMs = o.optLong("duration", 0L),
    reply = o.optString("reply_to", "").takeIf { it.isNotEmpty() }
        ?.let { ReplyRef(it, o.optString("reply_from", ""), o.optString("reply_text", "")) }
)

/** null = couldn't fetch right now (retried on the next poll). Malformed files are marked known and skipped for good. */
private suspend fun fetchMessage(c: GitHubClient, r: RepoRef, path: String, known: MutableSet<String>): ChatMsg? {
    val body = try { c.readFile(path, r) } catch (e: Exception) { null } ?: return null
    return try { parseMsg(path, JSONObject(body)) } catch (e: Exception) { known += path; null }
}

private fun msgCacheFile(ctx: Context, repo: String, branch: String) =
    File(ctx.filesDir, "n_chat_${"$repo@$branch".hashCode()}.json")

private fun saveMsgCache(f: File, list: List<ChatMsg>) {
    try {
        val arr = JSONArray()
        for (m in list) if (!m.pending) arr.put(JSONObject().apply {
            put("path", m.path); put("from", m.sender); put("ts", m.ts); put("type", m.type.name)
            put("text", m.text); put("media", m.mediaPath); put("duration", m.durationMs)
            m.reply?.let { putReply(it) }
        })
        f.writeText(arr.toString())
    } catch (_: Exception) {}
}

private fun loadMsgCache(f: File): List<ChatMsg> = try {
    if (!f.exists()) emptyList() else {
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { val o = arr.getJSONObject(it); parseMsg(o.getString("path"), o) }.sortedBy { it.ts }
    }
} catch (e: Exception) { emptyList() }

private fun timeLabel(ts: Long): String {
    if (ts <= 0L) return ""
    val fmt = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
    return fmt.format(java.util.Date(ts))
}

private fun humanBytes(n: Long): String = when {
    n >= 1_000_000 -> "%.1f MB".format(n / 1_000_000.0)
    n >= 1_000 -> "%.0f KB".format(n / 1_000.0)
    else -> "$n B"
}
