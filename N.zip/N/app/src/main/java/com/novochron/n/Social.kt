package com.novochron.n

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------
// Read receipts ("seen by") and emoji reactions.
//
// Same idea as profiles: nobody ever writes anyone else's file, so there are no merge conflicts.
//   Config/seen/<user>.json       {"user", "ts", "at"}  — "I've read everything up to message-time ts"
//   Config/reactions/<user>.json  {"user", "updated", "r": {"<message file id>": "❤️"}}
// Both live inside the repo in use, so a voice-key repo has its own receipts and reactions.
// ---------------------------------------------------------------------------------------------

object Social {
    const val SEEN_DIR = "Config/seen"
    const val REACT_DIR = "Config/reactions"
    private const val POLL_MS = 3_000L
    private const val MAX_MY_REACTIONS = 400

    val QuickEmojis = listOf("❤️", "😂", "😮", "😢", "👍", "👎")
    val MoreEmojis = listOf(
        "❤️", "😂", "😮", "😢", "😡", "👍", "👎", "🔥", "🎉", "😍", "🥰", "😘",
        "🤔", "😅", "🙏", "👏", "💯", "✨", "😭", "🤣", "😊", "😎", "🤯", "😴",
        "💀", "🫶", "🥺", "😬", "🙌", "💔", "😏", "🤝",
    )

    data class SeenInfo(val ts: Long, val at: Long)

    /** user → how far they've read (message time) and when they last reported it. */
    val seen = mutableStateMapOf<String, SeenInfo>()
    /** user → (message id → emoji). */
    val reactions = mutableStateMapOf<String, Map<String, String>>()
    var synced by mutableStateOf(false)
        private set

    private val shas = HashMap<String, String>()
    private val writeLock = Mutex()
    private var myReactionsLoaded = false

    /** A message's stable id across buckets: its file name without ".json". */
    fun idOf(path: String) = path.substringAfterLast('/').removeSuffix(".json")

    fun reset() {
        seen.clear(); reactions.clear(); shas.clear(); synced = false; myReactionsLoaded = false
    }

    // ---- syncing ----

    private suspend fun syncSeen(client: GitHubClient, repo: RepoRef, me: String) {
        val files = client.listFiles(SEEN_DIR, repo).filter { !it.isDir && it.path.endsWith(".json") }
        for (f in files) {
            if (shas[f.path] == f.sha) continue
            val o = client.readFile(f.path, repo)?.let { try { JSONObject(it) } catch (_: Exception) { null } } ?: continue
            shas[f.path] = f.sha
            val u = o.optString("user", ""); if (u.isBlank()) continue
            val info = SeenInfo(o.optLong("ts", 0L), o.optLong("at", 0L))
            val cur = seen[u]
            if (cur == null || info.ts >= cur.ts) seen[u] = info
        }
    }

    private suspend fun syncReactions(client: GitHubClient, repo: RepoRef, me: String) {
        val files = client.listFiles(REACT_DIR, repo).filter { !it.isDir && it.path.endsWith(".json") }
        for (f in files) {
            if (shas[f.path] == f.sha) continue
            val o = client.readFile(f.path, repo)?.let { try { JSONObject(it) } catch (_: Exception) { null } } ?: continue
            shas[f.path] = f.sha
            val u = o.optString("user", ""); if (u.isBlank()) continue
            // My own reactions are authoritative in memory (they're applied instantly); only adopt
            // the repo's copy of them once, on first load, so a slow poll can't undo a fresh tap.
            if (u == me && myReactionsLoaded) continue
            val r = o.optJSONObject("r") ?: JSONObject()
            val m = HashMap<String, String>()
            r.keys().forEach { k -> r.optString(k, "").takeIf { it.isNotBlank() }?.let { m[k] = it } }
            reactions[u] = m
        }
        myReactionsLoaded = true
    }

    /** Runs while the app is unlocked and a chat is open; keeps receipts + reactions in step with the repo. */
    suspend fun loop(client: GitHubClient?, repo: RepoRef?, me: String) {
        reset()
        if (client == null || repo == null) return
        while (true) {
            try { syncSeen(client, repo, me) } catch (e: Exception) { DebugLog.add("seen sync: ${e.message?.take(60)}") }
            try { syncReactions(client, repo, me) } catch (e: Exception) { DebugLog.add("reaction sync: ${e.message?.take(60)}") }
            synced = true
            delay(POLL_MS)
        }
    }

    // ---- publishing ----

    /** Tells everyone "I've read up to [ts]". Only ever moves forward. */
    suspend fun publishSeen(client: GitHubClient?, repo: RepoRef?, me: String, ts: Long) {
        if (client == null || repo == null) return
        if ((seen[me]?.ts ?: 0L) >= ts) return
        val now = System.currentTimeMillis()
        seen[me] = SeenInfo(ts, now)
        try {
            val body = JSONObject().apply { put("user", me); put("ts", ts); put("at", now) }
            client.writeFile("$SEEN_DIR/${safeName(me)}.json", body.toString(2), "n: seen", repo)
        } catch (e: Exception) { DebugLog.add("seen publish failed: ${e.message?.take(60)}") }
    }

    /**
     * Sets my reaction on [msgId] to [emoji]; tapping the emoji I already have (or passing "") removes it.
     * Applied to the UI immediately, then written to the repo in the background.
     */
    suspend fun react(client: GitHubClient?, repo: RepoRef?, me: String, msgId: String, emoji: String) {
        val mine = HashMap(reactions[me] ?: emptyMap())
        if (emoji.isBlank() || mine[msgId] == emoji) mine.remove(msgId) else mine[msgId] = emoji
        // Keep the file small: ids start with a timestamp, so the biggest ones are the newest.
        val trimmed = if (mine.size > MAX_MY_REACTIONS) mine.toSortedMap().entries.toList().takeLast(MAX_MY_REACTIONS).associate { it.key to it.value } else mine
        reactions[me] = trimmed
        myReactionsLoaded = true
        if (client == null || repo == null) return
        writeLock.withLock {
            try {
                val snapshot = reactions[me] ?: emptyMap()   // latest state, in case of rapid taps
                val r = JSONObject(); snapshot.forEach { (k, v) -> r.put(k, v) }
                val body = JSONObject().apply { put("user", me); put("updated", System.currentTimeMillis()); put("r", r) }
                client.writeFile("$REACT_DIR/${safeName(me)}.json", body.toString(2), "n: reaction", repo)
            } catch (e: Exception) { DebugLog.add("reaction publish failed: ${e.message?.take(60)}") }
        }
    }

    // ---- lookups used by the UI ----

    /** emoji by user for one message. */
    fun reactionsFor(msgId: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((u, m) in reactions) m[msgId]?.let { out[u] = it }
        return out
    }

    /** Everyone we know about except me: profile owners plus anyone who has a read-marker. */
    fun others(me: String): List<String> = (Profiles.map.keys + seen.keys + reactions.keys).filter { it != me }.distinct().sorted()
}

// ---------------------------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------------------------

/** The little row of profile pictures under a message: "these people have read up to here". */
@Composable
fun SeenRow(users: List<String>, onClick: () -> Unit) {
    Row(
        Modifier.padding(top = 2.dp).clip(RoundedCornerShape(10.dp)).clickable { onClick() }.padding(horizontal = 2.dp, vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        users.take(4).forEachIndexed { i, u ->
            if (i > 0) Spacer(Modifier.width(2.dp))
            Avatar(u, 14.dp)
        }
        if (users.size > 4) Text("+${users.size - 4}", color = Dim, fontFamily = TermFont, fontSize = 9.sp, modifier = Modifier.padding(start = 3.dp))
    }
}

/** Grouped reaction chips under a message. Tap to see who reacted. */
@Composable
fun ReactionChips(reactions: Map<String, String>, me: String, onClick: () -> Unit) {
    if (reactions.isEmpty()) return
    val grouped = reactions.values.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }
    Row(Modifier.padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((emoji, n) in grouped) {
            val mineHere = reactions[me] == emoji
            Row(
                Modifier.clip(RoundedCornerShape(10.dp))
                    .background(if (mineHere) Accent.copy(alpha = 0.22f) else Raised)
                    .clickable { onClick() }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(emoji, fontSize = 13.sp)
                if (n > 1) Text(" $n", color = Ink, fontFamily = TermFont, fontSize = 10.sp)
            }
        }
    }
}

/** A full emoji grid for reactions beyond the quick row. */
@Composable
fun EmojiPickerDialog(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(RoundedCornerShape(10.dp)).background(Raised).padding(12.dp)) {
            Text("react", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(6), modifier = Modifier.heightIn(max = 260.dp)) {
                items(Social.MoreEmojis) { e ->
                    Box(Modifier.padding(2.dp).clip(RoundedCornerShape(6.dp)).clickable { onPick(e) }.padding(6.dp), contentAlignment = Alignment.Center) {
                        Text(e, fontSize = 22.sp)
                    }
                }
            }
        }
    }
}

/**
 * The pop-up with profiles: who has seen a message (mine only) and who reacted with what.
 * [onRemoveMine] is offered next to my own reaction.
 */
@Composable
fun MessageInfoDialog(
    msgPath: String, msgTs: Long, mine: Boolean, me: String,
    seenLabel: (Long) -> String,
    onRemoveMine: () -> Unit, onDismiss: () -> Unit
) {
    val id = Social.idOf(msgPath)
    val rx = Social.reactionsFor(id)
    val others = Social.others(me)
    val seenUsers = others.filter { (Social.seen[it]?.ts ?: 0L) >= msgTs }
    val notSeen = others.filter { it !in seenUsers }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(RoundedCornerShape(10.dp)).background(Raised).padding(16.dp)) {
            if (rx.isNotEmpty()) {
                Text("reactions", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                for ((u, e) in rx) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (u == me) "you" else Profiles.display(u), color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                            if (u != me && Profiles.display(u) != u) Text(u, color = Dim, fontFamily = TermFont, fontSize = 10.sp)
                        }
                        Text(e, fontSize = 20.sp)
                        if (u == me) TextButton(onClick = { onRemoveMine(); onDismiss() }) {
                            Text("[remove]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            if (mine) {
                Text("seen by", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                if (seenUsers.isEmpty() && notSeen.isEmpty()) {
                    Text("nobody else in this chat yet", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                }
                for (u in seenUsers) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(Profiles.display(u), color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                            if (Profiles.display(u) != u) Text(u, color = Dim, fontFamily = TermFont, fontSize = 10.sp)
                        }
                        val at = Social.seen[u]?.at ?: 0L
                        if (at > 0L) Text("read ${seenLabel(at)}", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
                    }
                }
                for (u in notSeen) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(u, 32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(Profiles.display(u), color = Dim, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text("not yet", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            }
        }
    }
}
