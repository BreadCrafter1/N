package com.novochron.n

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.Segmenter
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// The ML half of video effects: finds your face and cuts you out from the background, on a small
// copy of the camera frame, on its own thread. The camera thread never waits for it - it just uses
// the most recent result. (Both models are bundled in the app, so no Google Play services and no
// downloads are needed.)
// ---------------------------------------------------------------------------------------------

/** Where the biggest face is, as fractions (0..1) of the upright picture. Eyes are sorted left-to-right on screen. */
internal class FaceGeo(
    val e1x: Float, val e1y: Float, val e2x: Float, val e2y: Float,  // eyes (1 = left on screen)
    val nx: Float, val ny: Float,                                   // nose
    val mx: Float, val my: Float, val mw: Float,                    // mouth centre + width
    val smile: Float, val at: Long,
) {
    companion object {
        fun from(face: Face, sw: Int, sh: Int): FaceGeo {
            val box = face.boundingBox
            val bw = box.width().toFloat(); val bh = box.height().toFloat()
            fun pos(type: Int): PointF? = face.getLandmark(type)?.position

            var e1x = box.left + bw * 0.32f; var e1y = box.top + bh * 0.40f
            var e2x = box.left + bw * 0.68f; var e2y = e1y
            val le = pos(FaceLandmark.LEFT_EYE); val re = pos(FaceLandmark.RIGHT_EYE)
            if (le != null && re != null) {
                if (le.x <= re.x) { e1x = le.x; e1y = le.y; e2x = re.x; e2y = re.y }
                else { e1x = re.x; e1y = re.y; e2x = le.x; e2y = le.y }
            }
            val nose = pos(FaceLandmark.NOSE_BASE)
            val nx = nose?.x ?: box.exactCenterX()
            val ny = nose?.y ?: (box.top + bh * 0.62f)

            var mx = box.exactCenterX(); var my = box.top + bh * 0.78f; var mw = bw * 0.4f
            val ml = pos(FaceLandmark.MOUTH_LEFT); val mr = pos(FaceLandmark.MOUTH_RIGHT)
            if (ml != null && mr != null) {
                mx = (ml.x + mr.x) / 2f; my = (ml.y + mr.y) / 2f; mw = Math.abs(mr.x - ml.x)
            }
            val sW = sw.toFloat(); val sH = sh.toFloat()
            return FaceGeo(
                e1x / sW, e1y / sH, e2x / sW, e2y / sH, nx / sW, ny / sH, mx / sW, my / sH, mw / sW,
                face.smilingProbability ?: 0f, SystemClock.uptimeMillis(),
            )
        }

        fun lerp(a: FaceGeo, b: FaceGeo, t: Float): FaceGeo {
            fun l(p: Float, q: Float) = p + (q - p) * t
            return FaceGeo(
                l(a.e1x, b.e1x), l(a.e1y, b.e1y), l(a.e2x, b.e2x), l(a.e2y, b.e2y), l(a.nx, b.nx), l(a.ny, b.ny),
                l(a.mx, b.mx), l(a.my, b.my), l(a.mw, b.mw), l(a.smile, b.smile), b.at,
            )
        }
    }
}

/** Person-vs-background mask (0 = background, 255 = you), already turned to match the camera buffer. */
internal class FxMask(val data: ByteArray, val w: Int, val h: Int, val rot: Int, val at: Long)

internal class FxTracker {
    @Volatile var face: FaceGeo? = null
    @Volatile var mask: FxMask? = null

    private val busy = AtomicBoolean(false)
    private val pending = AtomicInteger(0)
    private val exec: ExecutorService = Executors.newSingleThreadExecutor()
    private var detector: FaceDetector? = null
    private var segmenter: Segmenter? = null
    @Volatile private var closed = false
    private var loggedError = false

    /** Starts an analysis of [f] if the ML thread is idle. Returns true if it actually started one. */
    fun submit(f: FxFrame, wantFace: Boolean, wantSeg: Boolean): Boolean {
        if (closed || !busy.compareAndSet(false, true)) return false
        var bmp: Bitmap? = null
        try {
            val b = smallBitmap(f)
            bmp = b
            val sw = b.width; val sh = b.height
            val rot = f.rot
            val d = if (wantFace) (detector ?: FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                    .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                    .setMinFaceSize(0.15f)
                    .build()
            ).also { detector = it }) else null
            val s = if (wantSeg) (segmenter ?: Segmentation.getClient(
                SelfieSegmenterOptions.Builder()
                    .setDetectorMode(SelfieSegmenterOptions.STREAM_MODE)
                    .build()
            ).also { segmenter = it }) else null

            pending.set((if (d != null) 1 else 0) + (if (s != null) 1 else 0))
            val done: () -> Unit = {
                if (pending.decrementAndGet() <= 0) {
                    busy.set(false)
                    try { b.recycle() } catch (_: Exception) {}
                }
            }
            val image = InputImage.fromBitmap(b, 0)
            if (d != null) {
                d.process(image)
                    .addOnSuccessListener(exec) { faces -> onFaces(faces, sw, sh) }
                    .addOnFailureListener(exec) { e -> logOnce("face: ${e.message?.take(60)}") }
                    .addOnCompleteListener(exec) { done() }
            }
            if (s != null) {
                s.process(image)
                    .addOnSuccessListener(exec) { m -> onMask(m, rot) }
                    .addOnFailureListener(exec) { e -> logOnce("segment: ${e.message?.take(60)}") }
                    .addOnCompleteListener(exec) { done() }
            }
            return true
        } catch (e: Exception) {
            logOnce("effects: ${e.message?.take(60)}")
            pending.set(0); busy.set(false)
            try { bmp?.recycle() } catch (_: Exception) {}
            return false
        }
    }

    fun close() {
        closed = true
        try { detector?.close() } catch (_: Exception) {}
        try { segmenter?.close() } catch (_: Exception) {}
        detector = null; segmenter = null
        exec.shutdown()
    }

    private fun logOnce(msg: String) {
        if (loggedError) return
        loggedError = true
        DebugLog.add("video effect problem - $msg")
    }

    private fun onFaces(faces: List<Face>, sw: Int, sh: Int) {
        // No face this time? Keep the previous one - FxPipeline lets it expire after 0.7s, which
        // stops stickers flickering off when one detection misses.
        val best = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() } ?: return
        face = FaceGeo.from(best, sw, sh)
    }

    private fun onMask(m: SegmentationMask, rot: Int) {
        val mw = m.width; val mh = m.height
        val bb = m.buffer
        bb.rewind()
        val fl = FloatArray(mw * mh)
        bb.asFloatBuffer().get(fl)
        val sideways = rot == 90 || rot == 270
        val bw = if (sideways) mh else mw
        val bh = if (sideways) mw else mh
        val out = ByteArray(bw * bh)
        for (j in 0 until bh) {
            for (i in 0 until bw) {
                var ux = i; var uy = j
                when (rot) {
                    90 -> { ux = bh - 1 - j; uy = i }
                    180 -> { ux = bw - 1 - i; uy = bh - 1 - j }
                    270 -> { ux = j; uy = bw - 1 - i }
                }
                out[j * bw + i] = (fl[uy * mw + ux].coerceIn(0f, 1f) * 255f).toInt().toByte()
            }
        }
        mask = FxMask(out, bw, bh, rot, SystemClock.uptimeMillis())
    }

    /** Small, upright, RGB copy of the frame for the ML models. */
    private fun smallBitmap(f: FxFrame): Bitmap {
        val uw = f.uw; val uh = f.uh
        val sc = 320f / max(uw, uh)
        val sw = max(2, (uw * sc).roundToInt()); val sh = max(2, (uh * sc).roundToInt())
        val px = IntArray(sw * sh)
        val w = f.w; val h = f.h; val cw = f.cw
        for (j in 0 until sh) {
            val uy = min(uh - 1, (j / sc).toInt())
            for (i in 0 until sw) {
                val ux = min(uw - 1, (i / sc).toInt())
                var x = ux; var y = uy
                when (f.rot) {
                    90 -> { x = uy; y = h - 1 - ux }
                    180 -> { x = w - 1 - ux; y = h - 1 - uy }
                    270 -> { x = w - 1 - uy; y = ux }
                }
                val yy = max(0, (f.y[y * w + x].toInt() and 0xFF) - 16)
                val ci = (y shr 1) * cw + (x shr 1)
                val uu = (f.u[ci].toInt() and 0xFF) - 128
                val vv = (f.v[ci].toInt() and 0xFF) - 128
                val c = 298 * yy
                val r = ((c + 409 * vv + 128) shr 8).coerceIn(0, 255)
                val g = ((c - 100 * uu - 208 * vv + 128) shr 8).coerceIn(0, 255)
                val b = ((c + 516 * uu + 128) shr 8).coerceIn(0, 255)
                px[j * sw + i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, sw, 0, 0, sw, sh)
        return bmp
    }
}

// ---------------------------------------------------------------------------------------------
// Face stickers. Everything is drawn in "face units": the origin is the point between your eyes,
// +x runs along the line of your eyes (so stickers tilt with your head), and 1.0 = the distance
// between your eyes. Eyes sit at (-0.5, 0) and (0.5, 0); the top of the head is at about y = -1.
// ---------------------------------------------------------------------------------------------
internal class FxArt {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val path = Path()
    private var cs = 1f; private var sn = 0f; private var d = 1f; private var ox = 0f; private var oy = 0f

    private fun col(v: Long): Int = v.toInt()
    private fun lx(px: Float, py: Float) = ((px - ox) * cs + (py - oy) * sn) / d
    private fun ly(px: Float, py: Float) = (-(px - ox) * sn + (py - oy) * cs) / d

    fun draw(c: Canvas, fx: FaceFx, g: FaceGeo, uw: Int, uh: Int, t: Float) {
        val x1 = g.e1x * uw; val y1 = g.e1y * uh; val x2 = g.e2x * uw; val y2 = g.e2y * uh
        d = max(8f, hypot(x2 - x1, y2 - y1))
        val ang = atan2(y2 - y1, x2 - x1)
        cs = cos(ang); sn = sin(ang)
        ox = (x1 + x2) / 2f; oy = (y1 + y2) / 2f
        val nX = lx(g.nx * uw, g.ny * uh); val nY = ly(g.nx * uw, g.ny * uh)
        val mX = lx(g.mx * uw, g.my * uh); val mY = ly(g.mx * uw, g.my * uh)

        if (fx == FaceFx.PARTY) confetti(c, uw, uh, t)
        c.save()
        c.translate(ox, oy)
        c.rotate(ang * 57.29578f)
        c.scale(d, d)
        when (fx) {
            FaceFx.DOG -> dog(c, nX, nY, mX, mY, g.smile)
            FaceFx.CAT -> cat(c, nX, nY)
            FaceFx.BUNNY -> bunny(c, nX, nY, mX, mY)
            FaceFx.CLOWN -> clown(c, nX, nY)
            FaceFx.SHADES -> shades(c)
            FaceFx.STACHE -> stache(c, (nY + mY) / 2f, nX)
            FaceFx.CROWN -> crown(c)
            FaceFx.DEVIL -> devil(c, mX, mY)
            FaceFx.ANGEL -> angel(c)
            FaceFx.HEARTS -> hearts(c, t)
            FaceFx.PARTY -> party(c)
            FaceFx.ALIEN -> alien(c)
            else -> {}
        }
        c.restore()
    }

    // ---- tiny drawing helpers (all in face units)

    private fun oval(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, color: Int, rot: Float = 0f) {
        p.style = Paint.Style.FILL; p.color = color
        if (rot != 0f) { c.save(); c.rotate(rot, cx, cy) }
        r.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        c.drawOval(r, p)
        if (rot != 0f) c.restore()
    }

    private fun round(c: Canvas, cx: Float, cy: Float, w: Float, h: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL; p.color = color
        r.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        c.drawRoundRect(r, rad, rad, p)
    }

    private fun circle(c: Canvas, cx: Float, cy: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL; p.color = color
        c.drawCircle(cx, cy, rad, p)
    }

    private fun ring(c: Canvas, cx: Float, cy: Float, rad: Float, width: Float, color: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = width; p.color = color
        c.drawCircle(cx, cy, rad, p)
        p.style = Paint.Style.FILL
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, width: Float, color: Int) {
        p.style = Paint.Style.STROKE; p.strokeWidth = width; p.color = color; p.strokeCap = Paint.Cap.ROUND
        c.drawLine(x1, y1, x2, y2, p)
        p.style = Paint.Style.FILL
    }

    private fun poly(c: Canvas, color: Int, vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i + 1 < pts.size) { path.lineTo(pts[i], pts[i + 1]); i += 2 }
        path.close()
        p.style = Paint.Style.FILL; p.color = color
        c.drawPath(path, p)
    }

    /** Draw [body] once on the right half of the face and once mirrored on the left. */
    private inline fun mirrored(c: Canvas, body: () -> Unit) {
        body()
        c.save(); c.scale(-1f, 1f); body(); c.restore()
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        path.reset()
        path.moveTo(cx, cy + s * 0.9f)
        path.cubicTo(cx - s * 1.4f, cy + s * 0.1f, cx - s * 0.9f, cy - s * 1.0f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.9f, cy - s * 1.0f, cx + s * 1.4f, cy + s * 0.1f, cx, cy + s * 0.9f)
        path.close()
        p.style = Paint.Style.FILL; p.color = color
        c.drawPath(path, p)
    }

    // ---- the stickers

    private fun dog(c: Canvas, nx: Float, ny: Float, mx: Float, my: Float, smile: Float) {
        mirrored(c) {
            oval(c, 1.02f, -0.5f, 0.6f, 1.05f, col(0xFF6B3E1E), -14f)
            oval(c, 1.0f, -0.45f, 0.36f, 0.75f, col(0xFF8D5A2F), -14f)
        }
        if (smile > 0.5f) {
            round(c, mx, my + 0.24f, 0.3f, 0.44f, 0.14f, col(0xFFFF5C8A))
            line(c, mx, my + 0.1f, mx, my + 0.36f, 0.025f, col(0xFFC2185B))
        }
        oval(c, nx, ny, 0.36f, 0.25f, col(0xFF1A1A1A))
        circle(c, nx - 0.08f, ny - 0.05f, 0.045f, col(0x99FFFFFF))
    }

    private fun cat(c: Canvas, nx: Float, ny: Float) {
        mirrored(c) {
            poly(c, col(0xFF3A3A3A), 0.3f, -0.8f, 1.0f, -0.55f, 0.85f, -1.5f)
            poly(c, col(0xFFFFB6C8), 0.47f, -0.9f, 0.88f, -0.72f, 0.8f, -1.2f)
            for (k in -1..1) {
                line(c, 0.3f, ny + 0.12f, 1.35f, ny + 0.12f + k * 0.2f, 0.05f, col(0x99000000))
                line(c, 0.3f, ny + 0.12f, 1.35f, ny + 0.12f + k * 0.2f, 0.024f, col(0xFFFFFFFF))
            }
        }
        poly(c, col(0xFFFF7A9C), nx - 0.11f, ny - 0.06f, nx + 0.11f, ny - 0.06f, nx, ny + 0.08f)
    }

    private fun bunny(c: Canvas, nx: Float, ny: Float, mx: Float, my: Float) {
        mirrored(c) {
            oval(c, 0.42f, -1.7f, 0.5f, 1.5f, col(0xFFBDBDBD), 9f)
            oval(c, 0.42f, -1.7f, 0.44f, 1.44f, col(0xFFF8F8F8), 9f)
            oval(c, 0.42f, -1.66f, 0.2f, 1.05f, col(0xFFFFB3C7), 9f)
        }
        oval(c, nx, ny, 0.22f, 0.16f, col(0xFFFF8FAB))
        for (s in intArrayOf(-1, 1)) {
            round(c, mx + s * 0.065f, my + 0.2f, 0.14f, 0.22f, 0.03f, col(0xFFBDBDBD))
            round(c, mx + s * 0.065f, my + 0.2f, 0.115f, 0.195f, 0.03f, col(0xFFFFFFFF))
        }
    }

    private fun clown(c: Canvas, nx: Float, ny: Float) {
        val cols = longArrayOf(0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF5AC8FA, 0xFFAF52DE, 0xFFFF3B30)
        for (i in 0..6) {
            val a = PI.toFloat() * (1f + i / 6f)
            circle(c, cos(a) * 1.25f, -0.2f + sin(a) * 1.25f, 0.34f, col(cols[i]))
        }
        circle(c, nx, ny, 0.21f, col(0xFFE53935))
        circle(c, nx - 0.06f, ny - 0.07f, 0.05f, col(0xAAFFFFFF))
    }

    private fun shades(c: Canvas) {
        mirrored(c) {
            round(c, 0.5f, 0f, 0.8f, 0.5f, 0.18f, col(0xEE111111))
            line(c, 0.9f, -0.05f, 1.28f, -0.14f, 0.05f, col(0xFF111111))
            line(c, 0.3f, -0.16f, 0.52f, -0.04f, 0.045f, col(0x55FFFFFF))
        }
        round(c, 0f, -0.06f, 0.3f, 0.07f, 0.03f, col(0xFF111111))
    }

    private fun stache(c: Canvas, yM: Float, xM: Float) {
        // round professor glasses
        mirrored(c) { ring(c, 0.5f, 0f, 0.3f, 0.05f, col(0xFF222222)) }
        line(c, -0.2f, 0f, 0.2f, 0f, 0.05f, col(0xFF222222))
        // handlebar moustache
        c.save(); c.translate(xM, 0f)
        path.reset()
        path.moveTo(0f, yM - 0.05f)
        path.cubicTo(-0.15f, yM - 0.17f, -0.5f, yM - 0.12f, -0.62f, yM + 0.08f)
        path.cubicTo(-0.4f, yM + 0.02f, -0.2f, yM + 0.2f, 0f, yM + 0.1f)
        path.cubicTo(0.2f, yM + 0.2f, 0.4f, yM + 0.02f, 0.62f, yM + 0.08f)
        path.cubicTo(0.5f, yM - 0.12f, 0.15f, yM - 0.17f, 0f, yM - 0.05f)
        path.close()
        p.style = Paint.Style.FILL; p.color = col(0xFF3B2314)
        c.drawPath(path, p)
        c.restore()
    }

    private fun crown(c: Canvas) {
        poly(
            c, col(0xFFFFD60A),
            -0.7f, -0.8f, -0.7f, -1.5f, -0.35f, -1.15f, 0f, -1.65f, 0.35f, -1.15f, 0.7f, -1.5f, 0.7f, -0.8f,
        )
        round(c, 0f, -0.86f, 1.4f, 0.12f, 0.05f, col(0xFFC99700))
        circle(c, 0f, -1.0f, 0.07f, col(0xFFE53935))
        circle(c, -0.38f, -0.98f, 0.055f, col(0xFF2979FF))
        circle(c, 0.38f, -0.98f, 0.055f, col(0xFF2979FF))
    }

    private fun devil(c: Canvas, mx: Float, my: Float) {
        mirrored(c) {
            poly(c, col(0xFFD00000), 0.25f, -0.85f, 0.78f, -0.7f, 0.88f, -1.6f)
            poly(c, col(0x66FFFFFF), 0.4f, -0.88f, 0.62f, -0.8f, 0.8f, -1.35f)
        }
        poly(c, col(0xFF5A0000), mx - 0.16f, my + 0.2f, mx + 0.16f, my + 0.2f, mx, my + 0.58f)
    }

    private fun angel(c: Canvas) {
        p.style = Paint.Style.STROKE
        r.set(-0.55f, -1.55f, 0.55f, -1.2f)
        p.strokeWidth = 0.2f; p.color = col(0x44FFD60A); c.drawOval(r, p)
        p.strokeWidth = 0.09f; p.color = col(0xFFFFD60A); c.drawOval(r, p)
        p.style = Paint.Style.FILL
    }

    private fun hearts(c: Canvas, t: Float) {
        val s = 0.36f + 0.05f * sin(t * 8f)
        mirrored(c) {
            heart(c, 0.5f, 0f, s, col(0xFFFF2D55))
            circle(c, 0.5f - s * 0.45f, -s * 0.45f, s * 0.14f, col(0xAAFFFFFF))
        }
    }

    private fun party(c: Canvas) {
        poly(c, col(0xFFFF3B82), -0.55f, -0.85f, 0.55f, -0.85f, 0.05f, -2.15f)
        line(c, -0.38f, -1.2f, 0.3f, -1.0f, 0.07f, col(0xFFFFE066))
        line(c, -0.22f, -1.55f, 0.18f, -1.38f, 0.07f, col(0xFF5AC8FA))
        circle(c, 0.05f, -2.17f, 0.11f, col(0xFFFFE066))
    }

    /** Confetti falls in screen space (not tilted with the head). */
    private fun confetti(c: Canvas, uw: Int, uh: Int, t: Float) {
        val cols = longArrayOf(0xFFFF3B30, 0xFFFFCC00, 0xFF34C759, 0xFF5AC8FA, 0xFFAF52DE, 0xFFFF9500)
        for (i in 0 until 22) {
            val fx = i * 0.61803f; val fy = t * 0.16f + i * 0.381f
            val x = (fx - floor(fx)) * uw; val y = (fy - floor(fy)) * uh
            circle(c, x, y, uh * 0.011f, col(cols[i % cols.size]))
        }
    }

    private fun alien(c: Canvas) {
        oval(c, 0f, 0.4f, 2.0f, 2.7f, col(0x667CFC00))
        mirrored(c) {
            line(c, 0.3f, -0.95f, 0.62f, -1.65f, 0.04f, col(0xFF4CAF50))
            circle(c, 0.62f, -1.65f, 0.1f, col(0xFF76FF03))
            oval(c, 0.5f, 0f, 0.8f, 0.46f, col(0xFF050505), 25f)
            circle(c, 0.64f, -0.07f, 0.055f, col(0xAAFFFFFF))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Picture backgrounds, painted with Canvas (no image files to ship) and cached as YUV planes.
// ---------------------------------------------------------------------------------------------
internal object FxBackdrops {
    fun render(fx: BgFx, w: Int, h: Int, rot: Int): FxPlanes {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.concat(fxUprightMatrix(w, h, rot))
        val sideways = rot == 90 || rot == 270
        draw(c, fx, (if (sideways) h else w).toFloat(), (if (sideways) w else h).toFloat())
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()

        val cw = (w + 1) / 2; val ch = (h + 1) / 2
        val y = ByteArray(w * h); val u = ByteArray(cw * ch); val v = ByteArray(cw * ch)
        for (i in 0 until w * h) {
            val q = px[i]
            y[i] = fxRgbToY((q shr 16) and 0xFF, (q shr 8) and 0xFF, q and 0xFF).coerceIn(16, 235).toByte()
        }
        for (cy in 0 until ch) {
            for (cx in 0 until cw) {
                var rr = 0; var gg = 0; var bb = 0; var n = 0
                for (dy in 0..1) for (dx in 0..1) {
                    val xx = cx * 2 + dx; val yy = cy * 2 + dy
                    if (xx < w && yy < h) {
                        val q = px[yy * w + xx]
                        rr += (q shr 16) and 0xFF; gg += (q shr 8) and 0xFF; bb += q and 0xFF; n++
                    }
                }
                rr /= n; gg /= n; bb /= n
                u[cy * cw + cx] = fxRgbToU(rr, gg, bb).coerceIn(16, 240).toByte()
                v[cy * cw + cx] = fxRgbToV(rr, gg, bb).coerceIn(16, 240).toByte()
            }
        }
        return FxPlanes(y, u, v)
    }

    private fun ints(vararg v: Long) = IntArray(v.size) { v[it].toInt() }
    private fun col(v: Long) = v.toInt()

    private fun vgrad(c: Canvas, p: Paint, W: Float, H: Float, colors: IntArray, pos: FloatArray? = null) {
        p.shader = LinearGradient(0f, 0f, 0f, H, colors, pos, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        p.shader = null
    }

    private fun hills(c: Canvas, p: Paint, W: Float, H: Float, baseY: Float, amp: Float, color: Int, freq: Float, phase: Float) {
        val path = Path()
        path.moveTo(0f, H)
        val n = 48
        for (i in 0..n) path.lineTo(W * i / n, baseY + amp * sin(i * freq * 0.35f + phase))
        path.lineTo(W, H)
        path.close()
        p.style = Paint.Style.FILL; p.color = color
        c.drawPath(path, p)
    }

    private fun pine(c: Canvas, p: Paint, cx: Float, baseY: Float, hgt: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = col(0xFF4E342E); c.drawRect(cx - hgt * 0.04f, baseY - hgt * 0.15f, cx + hgt * 0.04f, baseY, p)
        p.color = color
        for (k in 0..2) {
            val top = baseY - hgt * (0.35f + 0.25f * k) - hgt * 0.3f
            val bot = baseY - hgt * (0.12f + 0.25f * k)
            val half = hgt * (0.34f - 0.07f * k)
            val t = Path()
            t.moveTo(cx, top); t.lineTo(cx - half, bot); t.lineTo(cx + half, bot); t.close()
            c.drawPath(t, p)
        }
    }

    private fun emojiTiles(c: Canvas, p: Paint, W: Float, H: Float, colors: IntArray, emojis: List<String>) {
        vgrad(c, p, W, H, colors)
        val tile = min(W, H) * 0.17f
        p.textAlign = Paint.Align.CENTER
        p.textSize = tile * 0.7f
        p.color = col(0xFFFFFFFF)
        val rows = (H / tile).toInt() + 2; val cols = (W / tile).toInt() + 2
        for (rr in 0 until rows) {
            for (cc in 0 until cols) {
                val x = cc * tile + (rr % 2) * tile / 2f
                val y = rr * tile + tile * 0.7f
                c.save()
                c.rotate(((rr * 7 + cc * 13) % 5 - 2) * 8f, x, y - tile * 0.2f)
                c.drawText(emojis[(rr * 3 + cc) % emojis.size], x, y, p)
                c.restore()
            }
        }
    }

    private fun draw(c: Canvas, fx: BgFx, W: Float, H: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val m = min(W, H)
        val u = m / 360f
        when (fx) {
            BgFx.SUNSET -> {
                vgrad(c, p, W, H, ints(0xFF2B1B5E, 0xFFB4417A, 0xFFFF8A5B, 0xFFFFD08A), floatArrayOf(0f, 0.45f, 0.75f, 1f))
                p.color = col(0xFFFFE6A8); c.drawCircle(W * 0.5f, H * 0.66f, m * 0.17f, p)
                hills(c, p, W, H, H * 0.72f, H * 0.03f, col(0xFF4A2358), 1.3f, 0f)
                hills(c, p, W, H, H * 0.82f, H * 0.035f, col(0xFF2D1440), 0.9f, 2f)
                hills(c, p, W, H, H * 0.92f, H * 0.03f, col(0xFF190A28), 1.7f, 4f)
            }
            BgFx.SPACE -> {
                vgrad(c, p, W, H, ints(0xFF02030F, 0xFF1A1048))
                val rnd = java.util.Random(42)
                for (i in 0 until 150) {
                    p.color = col(0xFFFFFFFF); p.alpha = 90 + rnd.nextInt(165)
                    c.drawCircle(rnd.nextFloat() * W, rnd.nextFloat() * H, (0.6f + rnd.nextFloat() * 2f) * u, p)
                }
                p.alpha = 255
                val pr = m * 0.2f; val px = W * 0.76f; val py = H * 0.22f
                p.shader = RadialGradient(px - pr * 0.3f, py - pr * 0.3f, pr * 1.5f, col(0xFFF6C177), col(0xFF7B3F00), Shader.TileMode.CLAMP)
                c.drawCircle(px, py, pr, p); p.shader = null
                p.style = Paint.Style.STROKE; p.strokeWidth = pr * 0.12f; p.color = col(0xCCE8D5A0)
                c.save(); c.rotate(-20f, px, py)
                c.drawOval(RectF(px - pr * 1.7f, py - pr * 0.35f, px + pr * 1.7f, py + pr * 0.35f), p)
                c.restore()
                p.style = Paint.Style.FILL; p.color = col(0xFFB0BEC5); c.drawCircle(W * 0.18f, H * 0.82f, m * 0.07f, p)
            }
            BgFx.OCEAN -> {
                vgrad(c, p, W, H, ints(0xFF8FD3FF, 0xFFDDF3FF, 0xFF1AA6B7, 0xFF0A3D62), floatArrayOf(0f, 0.5f, 0.5f, 1f))
                p.color = col(0xFFFFF1B0); c.drawCircle(W * 0.78f, H * 0.2f, m * 0.09f, p)
                hills(c, p, W, H, H * 0.6f, H * 0.012f, col(0x552FC4D6), 2.4f, 0f)
                hills(c, p, W, H, H * 0.72f, H * 0.014f, col(0x66138FA3), 2.0f, 1.5f)
                hills(c, p, W, H, H * 0.86f, H * 0.016f, col(0x880B5E80), 1.7f, 3f)
            }
            BgFx.FOREST -> {
                vgrad(c, p, W, H, ints(0xFFBFE8FF, 0xFFEAF9DD))
                hills(c, p, W, H, H * 0.55f, H * 0.04f, col(0xFF8CC17E), 1.1f, 0.5f)
                hills(c, p, W, H, H * 0.65f, H * 0.04f, col(0xFF5FA55A), 1.4f, 2.5f)
                val rnd = java.util.Random(5)
                var x = 0f
                while (x < W + 20f) { pine(c, p, x, H * (0.74f + rnd.nextFloat() * 0.04f), H * (0.17f + rnd.nextFloat() * 0.05f), col(0xFF3E8E41)); x += W * 0.09f }
                p.style = Paint.Style.FILL; p.color = col(0xFF2E6B2E); c.drawRect(0f, H * 0.86f, W, H, p)
                x = W * 0.03f
                while (x < W + 20f) { pine(c, p, x, H * (0.92f + rnd.nextFloat() * 0.04f), H * (0.3f + rnd.nextFloat() * 0.08f), col(0xFF1B5E20)); x += W * 0.17f }
            }
            BgFx.SYNTHWAVE -> {
                val hz = H * 0.62f
                vgrad(c, p, W, H, ints(0xFF0B0221, 0xFF3A0CA3, 0xFFF72585), floatArrayOf(0f, 0.45f, 0.62f))
                val sr = m * 0.28f
                p.shader = LinearGradient(0f, hz - sr, 0f, hz + sr, col(0xFFFFD60A), col(0xFFF72585), Shader.TileMode.CLAMP)
                c.drawCircle(W / 2f, hz - sr * 0.1f, sr, p); p.shader = null
                p.style = Paint.Style.FILL; p.color = col(0xFF14003A); c.drawRect(0f, hz, W, H, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * u; p.color = col(0xCCF72585)
                for (i in -8..8) c.drawLine(W / 2f + i * W * 0.02f, hz, W / 2f + i * W * 0.2f, H, p)
                for (k in 1..8) { val t = k / 8f; val yy = hz + (H - hz) * t * t; c.drawLine(0f, yy, W, yy, p) }
                p.style = Paint.Style.FILL
            }
            BgFx.BOOKS -> {
                vgrad(c, p, W, H, ints(0xFF9A6B45, 0xFF6B4226))
                val palette = longArrayOf(0xFFB23A48, 0xFF2F6690, 0xFF3A7D44, 0xFFE0A526, 0xFF6C4F8B, 0xFFD1783F, 0xFF264653)
                val rnd = java.util.Random(11)
                val rows = 4; val gap = H / rows
                for (row in 0 until rows) {
                    val shelfY = gap * (row + 1) - H * 0.02f
                    var x = W * 0.01f
                    while (x < W) {
                        val bw = W * (0.025f + rnd.nextFloat() * 0.025f)
                        val bh = gap * (0.55f + rnd.nextFloat() * 0.33f)
                        p.color = col(palette[rnd.nextInt(palette.size)])
                        c.drawRect(x, shelfY - bh, x + bw - 1f, shelfY, p)
                        p.color = col(0x33FFFFFF); c.drawRect(x + bw * 0.2f, shelfY - bh, x + bw * 0.3f, shelfY, p)
                        x += bw
                    }
                    p.color = col(0xFF3E2412); c.drawRect(0f, shelfY, W, shelfY + H * 0.025f, p)
                }
            }
            BgFx.CANDY -> emojiTiles(c, p, W, H, ints(0xFFFFC2E0, 0xFFC3B1FF), listOf("🍭", "🍬", "🍩"))
            BgFx.HEARTS -> emojiTiles(c, p, W, H, ints(0xFFFFD1E3, 0xFFFF8FB8), listOf("💖", "💕", "💗"))
            BgFx.STARS -> emojiTiles(c, p, W, H, ints(0xFF1B1464, 0xFF4A3FBF), listOf("⭐", "✨", "🌟"))
            BgFx.PIZZA -> emojiTiles(c, p, W, H, ints(0xFFFFE9A8, 0xFFFFC857), listOf("🍕", "🧀"))
            BgFx.GREEN -> c.drawColor(col(0xFF00B140))
            else -> {}
        }
    }
}
