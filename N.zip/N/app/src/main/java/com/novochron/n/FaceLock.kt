package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A lightweight, fully on-device "does this match a hardcoded face?" gate.
 *
 * How it works: ML Kit finds the eyes, nose, mouth, and full face/eyebrow/eye/nose/lip
 * contours in a camera frame (~70 points total). Every point is re-expressed relative to the
 * eye line — centered on the midpoint between the eyes, rotated so that line is horizontal,
 * and scaled by the distance between the eyes — so the result doesn't depend on head tilt,
 * distance from the phone, or camera framing. That aligned point cloud is compared against
 * the same thing computed from the hardcoded reference photo(s) bundled in the app.
 *
 * This is shape matching, not a trained face-embedding model (like FaceID or a real
 * recognition pipeline uses), so it's meant to keep casual snoopers out, not stand up to
 * someone who looks similar to the reference photo. MATCH_THRESHOLD below is the one knob
 * that trades strictness for tolerance — see FaceLockScreen, which shows the live distance
 * number on screen so you can calibrate it against your own face and a few other people's.
 *
 * To add or change whose face unlocks the app: drop a clear, front-facing, well-lit photo
 * into res/drawable (e.g. ref_face_2.jpg) and add its resource id to REFERENCE_DRAWABLES.
 */
object FaceLock {

    // Hardcoded reference face(s). Add more R.drawable.xxx ids here to allow more than one face.
    private val REFERENCE_DRAWABLES = listOf(R.drawable.ref_face_1)

    // Lower = stricter match. Start here, then watch the on-screen distance number: see the
    // comment in FaceLockScreen for how to tune this to your specific face/lighting/camera.
    private const val MATCH_THRESHOLD = 0.09f

    // A face has to fill at least this fraction of the frame's shorter side to count — keeps
    // a face that just wanders into the background of the shot from being evaluated at all.
    private const val MIN_FACE_FRACTION = 0.15f

    private val landmarkIds = intArrayOf(
        FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE, FaceLandmark.NOSE_BASE,
        FaceLandmark.MOUTH_LEFT, FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM
    )

    // Contour types included in the shape signature, roughly ~70 points combined. Fixed set,
    // in a fixed order, so the resulting vectors are always comparable length-for-length.
    private val contourTypes = intArrayOf(
        FaceContour.FACE,
        FaceContour.LEFT_EYEBROW_TOP,
        FaceContour.RIGHT_EYEBROW_TOP,
        FaceContour.LEFT_EYE,
        FaceContour.RIGHT_EYE,
        FaceContour.NOSE_BRIDGE,
        FaceContour.NOSE_BOTTOM,
        FaceContour.UPPER_LIP_TOP,
        FaceContour.LOWER_LIP_BOTTOM
    )

    private var cachedReferenceVectors: List<FloatArray>? = null

    private val detector: FaceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()
        FaceDetection.getClient(options)
    }

    sealed class Result {
        data class Match(val distance: Float) : Result()
        data class NoMatch(val distance: Float) : Result()
        object NoFaceFound : Result()
        data class Error(val message: String) : Result()
    }

    /** Warms up the reference vectors so the first live frame doesn't stall on decoding them. */
    suspend fun preload(ctx: Context) {
        referenceVectors(ctx)
    }

    /** Runs detection on a single camera frame and compares it against the hardcoded reference(s). */
    suspend fun verifyImage(ctx: Context, image: InputImage): Result {
        return try {
            val faces = detectFaces(image)
            val face = faces
                .filter { largestSideFraction(it, image.width, image.height) >= MIN_FACE_FRACTION }
                .maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
                ?: return Result.NoFaceFound

            val liveVector = faceToVector(face) ?: return Result.NoFaceFound

            val references = referenceVectors(ctx)
            if (references.isEmpty()) return Result.Error("No reference face is bundled in the app.")

            val bestDistance = references.minOf { distance(it, liveVector) }
            if (bestDistance <= MATCH_THRESHOLD) Result.Match(bestDistance) else Result.NoMatch(bestDistance)
        } catch (e: Exception) {
            Result.Error(e.message ?: "face check failed")
        }
    }

    private fun largestSideFraction(face: Face, imageWidth: Int, imageHeight: Int): Float {
        val shorterSide = minOf(imageWidth, imageHeight).coerceAtLeast(1)
        return face.boundingBox.width().toFloat() / shorterSide
    }

    private suspend fun referenceVectors(ctx: Context): List<FloatArray> {
        cachedReferenceVectors?.let { return it }
        val vectors = REFERENCE_DRAWABLES.mapNotNull { resId ->
            val bmp = BitmapFactory.decodeResource(ctx.resources, resId) ?: return@mapNotNull null
            val faces = detectFaces(InputImage.fromBitmap(bmp, 0))
            val face = faces.maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
            face?.let { faceToVector(it) }
        }
        cachedReferenceVectors = vectors
        return vectors
    }

    private suspend fun detectFaces(image: InputImage): List<Face> =
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { faces -> if (cont.isActive) cont.resume(faces) }
                .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
        }

    /**
     * Builds an aligned, scale-normalized point cloud for a face: landmarks + contour points,
     * all expressed relative to the eye line (see class doc). Returns null if any required
     * landmark/contour is missing, so every returned vector has the same fixed length.
     */
    private fun faceToVector(face: Face): FloatArray? {
        val leftEye = face.getLandmark(FaceLandmark.LEFT_EYE)?.position ?: return null
        val rightEye = face.getLandmark(FaceLandmark.RIGHT_EYE)?.position ?: return null

        val midX = (leftEye.x + rightEye.x) / 2f
        val midY = (leftEye.y + rightEye.y) / 2f
        val dx = rightEye.x - leftEye.x
        val dy = rightEye.y - leftEye.y
        val eyeDist = hypot(dx, dy)
        if (eyeDist < 1f) return null

        val angle = atan2(dy.toDouble(), dx.toDouble())
        val cosA = cos(-angle).toFloat()
        val sinA = sin(-angle).toFloat()

        fun normalize(px: Float, py: Float): FloatArray {
            val tx = px - midX
            val ty = py - midY
            val rx = tx * cosA - ty * sinA
            val ry = tx * sinA + ty * cosA
            return floatArrayOf(rx / eyeDist, ry / eyeDist)
        }

        val dims = ArrayList<Float>()

        for (id in landmarkIds) {
            val p = face.getLandmark(id)?.position ?: return null
            dims.addAll(normalize(p.x, p.y).asList())
        }

        for (type in contourTypes) {
            val pts = face.getContour(type)?.points
            if (pts.isNullOrEmpty()) return null
            for (p in pts) dims.addAll(normalize(p.x, p.y).asList())
        }

        return dims.toFloatArray()
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return Float.MAX_VALUE
        var sum = 0f
        for (i in a.indices) {
            val diff = a[i] - b[i]
            sum += diff * diff
        }
        return sqrt(sum / a.size)
    }

    private fun hypot(dx: Float, dy: Float): Float = sqrt(dx * dx + dy * dy)
}
