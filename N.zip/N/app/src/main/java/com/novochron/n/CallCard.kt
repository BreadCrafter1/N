package com.novochron.n

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** What a call card in the chat is showing. */
enum class CallCardState {
    LIVE,      // call is going on and you can [join] it
    IN_CALL,   // you're in this call right now
    ENDED,     // call finished (with a duration)
    MISSED,    // nobody picked up / call ended without ever connecting
}

/**
 * The Messenger-style card that sits in the chat for a call: "X started a video call" with a
 * [join] button while it's live, which flips into "Video call ended · 5:12" (or "Missed video call")
 * once it's over. Purely presentational — MainActivity works out which state to show.
 */
@Composable
fun CallCard(
    video: Boolean,
    state: CallCardState,
    title: String,
    subtitle: String,
    joinEnabled: Boolean,
    onJoin: () -> Unit,
    onReturn: () -> Unit = {},
) {
    val live = state == CallCardState.LIVE || state == CallCardState.IN_CALL
    val iconColor = when (state) {
        CallCardState.LIVE, CallCardState.IN_CALL -> Accent
        CallCardState.MISSED -> Warn
        CallCardState.ENDED -> Dim
    }
    Box(Modifier.fillMaxWidth().padding(vertical = 2.dp), contentAlignment = Alignment.Center) {
        Row(
            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(10.dp))
                .background(Raised)
                .border(1.dp, if (live) Accent.copy(alpha = 0.45f) else Line, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(iconColor.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) { IconGlyph(if (video) Ic.Video else Ic.Call, iconColor, 20.dp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f, fill = false)) {
                Text(title, color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                if (subtitle.isNotBlank()) Text(subtitle, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            }
            when (state) {
                CallCardState.LIVE -> {
                    Spacer(Modifier.width(12.dp))
                    Box(
                        Modifier.heightIn(min = 36.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (joinEnabled) Accent else Dim.copy(alpha = 0.25f))
                            .clickable(enabled = joinEnabled, onClick = onJoin)
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "join", fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            color = if (joinEnabled) Bg else Dim
                        )
                    }
                }
                CallCardState.IN_CALL -> {
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "[return]", color = Accent, fontFamily = TermFont, fontSize = 12.sp,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onReturn).padding(8.dp)
                    )
                }
                else -> {}
            }
        }
    }
}

/** 75 -> "1:15", 3725 -> "1:02:05". */
fun formatCallDuration(sec: Int): String =
    if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
    else "%d:%02d".format(sec / 60, sec % 60)
