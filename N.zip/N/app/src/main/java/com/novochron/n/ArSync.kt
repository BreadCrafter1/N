package com.novochron.n

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private const val AR_DIR = "AR"

/** A floating-text sign left in the world: where it is, what it says, who left it. */
data class ArSign(
    val path: String,
    val from: String,
    val ts: Long,
    val text: String,
    val lat: Double,
    val lon: Double
)

private fun parseArSign(path: String, o: JSONObject) = ArSign(
    path = path,
    from = o.optString("from", "them"),
    ts = o.optLong("ts", 0L),
    text = o.optString("text", ""),
    lat = o.optDouble("lat", Double.NaN),
    lon = o.optDouble("lon", Double.NaN)
)

/** null = couldn't fetch right now (retried on the next poll), or the file was malformed. */
suspend fun fetchArSign(c: GitHubClient, r: RepoRef, path: String): ArSign? {
    val body = try { c.readFile(path, r) } catch (e: Exception) { null } ?: return null
    return try { parseArSign(path, JSONObject(body)) } catch (e: Exception) { null }
}

/** Every sign file currently in the shared repo's AR/ folder, same mailbox idea as chat messages. */
suspend fun listArSignPaths(c: GitHubClient, r: RepoRef): List<String> =
    c.listFiles(AR_DIR, r).filter { !it.isDir && it.path.endsWith(".json") }.map { it.path }

/** Drops a new sign into the shared repo. Both people will pick it up on their next poll. */
suspend fun commitArSign(c: GitHubClient, r: RepoRef, from: String, text: String, lat: Double, lon: Double) {
    val ts = System.currentTimeMillis()
    val path = "$AR_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
    val body = JSONObject().apply {
        put("from", from); put("ts", ts); put("text", text); put("lat", lat); put("lon", lon)
    }
    c.commitFile(path, body.toString(), "n: ar sign", r)
}

// ---- local cache: signs already known show up instantly on reopen, same idea as the chat cache ----

private fun arCacheFile(ctx: Context, repo: String, branch: String) =
    File(ctx.filesDir, "n_ar_${"$repo@$branch".hashCode()}.json")

fun loadArCache(ctx: Context, repo: String, branch: String): List<ArSign> = try {
    val f = arCacheFile(ctx, repo, branch)
    if (!f.exists()) emptyList() else {
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { val o = arr.getJSONObject(it); parseArSign(o.getString("path"), o) }
    }
} catch (e: Exception) { emptyList() }

fun saveArCache(ctx: Context, repo: String, branch: String, signs: List<ArSign>) {
    try {
        val arr = JSONArray()
        for (s in signs) arr.put(JSONObject().apply {
            put("path", s.path); put("from", s.from); put("ts", s.ts)
            put("text", s.text); put("lat", s.lat); put("lon", s.lon)
        })
        arCacheFile(ctx, repo, branch).writeText(arr.toString())
    } catch (_: Exception) {}
}

// ---- geometry: bearing/distance between two GPS points, and a point offset from one ----
// (standard great-circle formulas; fine at the short, human-walking-around distances this is for)

private const val EARTH_RADIUS_M = 6371000.0

fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val phi1 = Math.toRadians(lat1); val phi2 = Math.toRadians(lat2)
    val dPhi = Math.toRadians(lat2 - lat1); val dLambda = Math.toRadians(lon2 - lon1)
    val sinDPhi = sin(dPhi / 2); val sinDLambda = sin(dLambda / 2)
    val a = sinDPhi * sinDPhi + cos(phi1) * cos(phi2) * sinDLambda * sinDLambda
    return 2 * EARTH_RADIUS_M * atan2(sqrt(a), sqrt(1 - a))
}

/** Initial bearing from point 1 to point 2, degrees clockwise from true north, 0..360. */
fun bearingDegrees(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val phi1 = Math.toRadians(lat1); val phi2 = Math.toRadians(lat2)
    val dLambda = Math.toRadians(lon2 - lon1)
    val y = sin(dLambda) * cos(phi2)
    val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dLambda)
    return (Math.toDegrees(atan2(y, x)) + 360) % 360
}

/** The point [distanceM] meters from (lat, lon) along compass bearing [bearingDeg]. */
fun destinationPoint(lat: Double, lon: Double, bearingDeg: Double, distanceM: Double): Pair<Double, Double> {
    val delta = distanceM / EARTH_RADIUS_M
    val theta = Math.toRadians(bearingDeg)
    val phi1 = Math.toRadians(lat); val lambda1 = Math.toRadians(lon)
    val phi2 = Math.asin(sin(phi1) * cos(delta) + cos(phi1) * sin(delta) * cos(theta))
    val lambda2 = lambda1 + atan2(sin(theta) * sin(delta) * cos(phi1), cos(delta) - sin(phi1) * sin(phi2))
    return Math.toDegrees(phi2) to ((Math.toDegrees(lambda2) + 540) % 360 - 180)
}

/** Signed angular difference target-minus-current, normalized to -180..180. */
fun angleDiff(target: Double, current: Double): Double {
    var d = (target - current) % 360.0
    if (d > 180) d -= 360
    if (d < -180) d += 360
    return d
}
