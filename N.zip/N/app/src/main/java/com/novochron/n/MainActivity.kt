package com.novochron.n

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.UUID

// ---- theme, matching Novochron's terminal look ----
val Accent = Color(0xFF3DFF5C)
val Ink = Color(0xFFE8E8E8)
val Dim = Color(0xFF8C8C8C)
val Line = Color(0xFF262626)
val Raised = Color(0xFF101010)
val Warn = Color(0xFFFF5C5C)
val Mine = Color(0xFF0E2A12)
val TermFont = FontFamily.Monospace

private const val MSG_DIR = "Msg"
private const val MSG_MEDIA_DIR = "Msg/media"
private const val POLL_MS = 2000L
private const val MAX_MEDIA_BYTES = 1_000_000L

private enum class MsgType { TEXT, PHOTO, VIDEO }
private data class ChatMsg(
    val path: String, val sender: String, val ts: Long, val type: MsgType,
    val text: String = "", val mediaPath: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color.Black)) {
                NApp(Store(applicationContext))
            }
        }
    }
}

@Composable
fun NApp(store: Store) {
    var repoText by remember { mutableStateOf(store.repo) }
    var tokenText by remember { mutableStateOf(store.token) }
    var nameText by remember { mutableStateOf(store.name.ifBlank { "me" }) }
    var editingSetup by remember { mutableStateOf(store.repo.isBlank() || store.token.isBlank()) }
    var setupStatus by remember { mutableStateOf("") }

    fun repoRef(): RepoRef? = RepoRef.parse(store.repo)
    fun client(): GitHubClient? = if (store.token.isBlank()) null else GitHubClient(store.token, store.branch)

    Column(Modifier.fillMaxSize().background(Color.Black).padding(horizontal = 14.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("N", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            if (!editingSetup) {
                TextButton(onClick = { editingSetup = true }) { Text("[repo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))

        if (editingSetup) {
            SetupForm(
                repoText, tokenText, nameText, setupStatus,
                onRepo = { repoText = it }, onToken = { tokenText = it }, onName = { nameText = it },
                canCancel = store.repo.isNotBlank() && store.token.isNotBlank(),
                onCancel = { editingSetup = false; setupStatus = "" },
                onSave = {
                    if (RepoRef.parse(repoText) == null) {
                        setupStatus = "That doesn't look like \"owner/repo\"."
                    } else if (tokenText.isBlank()) {
                        setupStatus = "Paste a GitHub personal access token (needs the \"repo\" scope)."
                    } else {
                        store.repo = repoText
                        store.token = tokenText
                        store.name = nameText.ifBlank { "me" }
                        editingSetup = false
                        setupStatus = ""
                    }
                }
            )
        } else {
            ChatBody(store)
        }
    }
}

@Composable
private fun SetupForm(
    repoText: String, tokenText: String, nameText: String, status: String,
    onRepo: (String) -> Unit, onToken: (String) -> Unit, onName: (String) -> Unit,
    canCancel: Boolean, onCancel: () -> Unit, onSave: () -> Unit
) {
    Text("Shared repo (owner/name) — both people use the same one:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    NTextField(repoText, onRepo, "owner/repo")
    Spacer(Modifier.height(10.dp))
    Text("GitHub personal access token (needs \"repo\" scope):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    NTextField(tokenText, onToken, "ghp_...", password = true)
    Spacer(Modifier.height(10.dp))
    Text("Your name (shown on your messages):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    NTextField(nameText, onName, "me")
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        TextButton(onClick = onSave) { Text("[save]", color = Accent, fontFamily = TermFont, fontSize = 14.sp) }
        if (canCancel) TextButton(onClick = onCancel) { Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
    }
    if (status.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
    }
}

@Composable
private fun NTextField(value: String, onChange: (String) -> Unit, placeholder: String, password: Boolean = false) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(placeholder, color = Dim, fontFamily = TermFont) },
        visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Raised, unfocusedContainerColor = Raised,
            focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ChatBody(store: Store) {
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    var messages by remember { mutableStateOf(listOf<ChatMsg>()) }
    val known = remember { mutableSetOf<String>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    suspend fun poll() {
        val r = repo ?: return
        val c = client ?: return
        val files = try {
            c.listFiles(MSG_DIR, r)
        } catch (e: GitHubApiException) {
            status = "Couldn't check for messages: ${e.body.take(80)}"; return
        } catch (e: Exception) {
            status = "Couldn't check for messages: ${e.message ?: "unknown error"}"; return
        }
        val newOnes = files.filter { !it.isDir && it.path.endsWith(".json") && it.path !in known }
        if (newOnes.isEmpty()) return
        val parsed = mutableListOf<ChatMsg>()
        for (f in newOnes.sortedBy { it.path }) {
            known += f.path
            val body = try { c.readFile(f.path, r) } catch (e: Exception) { null } ?: continue
            try {
                val o = JSONObject(body)
                parsed += ChatMsg(
                    path = f.path, sender = o.optString("from", "them"), ts = o.optLong("ts", 0L),
                    type = MsgType.valueOf(o.optString("type", "TEXT").uppercase()),
                    text = o.optString("text", ""), mediaPath = o.optString("media", "")
                )
            } catch (e: Exception) { /* skip malformed file */ }
        }
        if (parsed.isNotEmpty()) { messages = (messages + parsed).sortedBy { it.ts }; status = "" }
    }

    LaunchedEffect(store.repo, store.token, store.branch) {
        messages = emptyList(); known.clear()
        if (repo != null && client != null) {
            while (true) { poll(); delay(POLL_MS) }
        }
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    fun sendText(text: String) {
        val r = repo ?: return; val c = client ?: return
        val trimmed = text.trim(); if (trimmed.isEmpty()) return
        input = ""
        scope.launch {
            busy = true; status = "Sending…"
            try {
                val ts = System.currentTimeMillis()
                val path = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
                val body = JSONObject().apply { put("from", store.name.ifBlank { "me" }); put("ts", ts); put("type", "TEXT"); put("text", trimmed) }
                c.commitFile(path, body.toString(), "n: text", r)
                known += path
                messages = messages + ChatMsg(path, store.name.ifBlank { "me" }, ts, MsgType.TEXT, text = trimmed)
                status = ""
            } catch (e: GitHubApiException) { status = "Failed to send: ${e.body.take(80)}" }
            catch (e: Exception) { status = "Failed to send: ${e.message ?: "unknown error"}" }
            busy = false
        }
    }

    fun sendMedia(ctx: android.content.Context, uri: Uri, type: MsgType) {
        val r = repo ?: return; val c = client ?: return
        scope.launch {
            busy = true; status = "Uploading ${if (type == MsgType.PHOTO) "photo" else "video"}…"
            try {
                val bytes = withContext(Dispatchers.IO) { ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } }
                if (bytes == null) { status = "Couldn't read that file."; busy = false; return@launch }
                if (bytes.size.toLong() > MAX_MEDIA_BYTES) {
                    status = "That's ${humanBytes(bytes.size.toLong())} — keep attachments under ${humanBytes(MAX_MEDIA_BYTES)}."
                    busy = false; return@launch
                }
                val ts = System.currentTimeMillis()
                val ext = if (type == MsgType.PHOTO) "jpg" else "mp4"
                val mediaPath = "$MSG_MEDIA_DIR/$ts.$ext"
                c.commitBytes(mediaPath, bytes, "n: ${type.name.lowercase()}", r)
                val jsonPath = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
                val body = JSONObject().apply { put("from", store.name.ifBlank { "me" }); put("ts", ts); put("type", type.name); put("media", mediaPath) }
                c.commitFile(jsonPath, body.toString(), "n: ${type.name.lowercase()}", r)
                known += jsonPath
                messages = messages + ChatMsg(jsonPath, store.name.ifBlank { "me" }, ts, type, mediaPath = mediaPath)
                status = ""
            } catch (e: GitHubApiException) { status = "Failed to send: ${e.body.take(80)}" }
            catch (e: Exception) { status = "Failed to send: ${e.message ?: "unknown error"}" }
            busy = false
        }
    }

    val ctx = LocalContext.current
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(ctx, uri, MsgType.PHOTO) }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(ctx, uri, MsgType.VIDEO) }

    Text("${store.repo} @ ${store.branch} · as \"${store.name.ifBlank { "me" }}\"", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
    Spacer(Modifier.height(6.dp))

    Box(Modifier.weight(1f).fillMaxWidth()) {
        if (messages.isEmpty()) {
            Text(status.ifEmpty { "No messages yet. Say hi below." }, color = Dim, fontFamily = TermFont, fontSize = 13.sp)
        } else {
            LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.path }) { m ->
                    MsgBubble(m, mine = m.sender == store.name.ifBlank { "me" }, client = client, repo = repo)
                }
            }
        }
    }
    if (status.isNotEmpty() && messages.isNotEmpty()) {
        Text(status, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }, enabled = !busy) { Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        TextButton(onClick = { videoLauncher.launch(arrayOf("video/*")) }, enabled = !busy) { Text("[video]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        TextField(
            value = input, onValueChange = { input = it }, singleLine = true, enabled = !busy,
            placeholder = { Text("message…", color = Dim, fontFamily = TermFont) },
            textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { sendText(input) }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
            ),
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { sendText(input) }, enabled = !busy && input.isNotBlank()) {
            Text("[send]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun MsgBubble(m: ChatMsg, mine: Boolean, client: GitHubClient?, repo: RepoRef?) {
    val bg = if (mine) Mine else Raised
    val align = if (mine) Alignment.End else Alignment.Start
    Column(Modifier.fillMaxWidth(), horizontalAlignment = align) {
        Text("${m.sender} · ${timeLabel(m.ts)}", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        Box(Modifier.widthIn(max = 260.dp).clip(RoundedCornerShape(6.dp)).background(bg).padding(10.dp)) {
            when (m.type) {
                MsgType.TEXT -> Text(m.text, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                MsgType.PHOTO -> MediaBubble(m, client, repo, isVideo = false)
                MsgType.VIDEO -> MediaBubble(m, client, repo, isVideo = true)
            }
        }
    }
    Spacer(Modifier.height(2.dp))
}

@Composable
private fun MediaBubble(m: ChatMsg, client: GitHubClient?, repo: RepoRef?, isVideo: Boolean) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bytes by remember(m.path) { mutableStateOf<ByteArray?>(null) }
    var error by remember(m.path) { mutableStateOf("") }
    var loading by remember(m.path) { mutableStateOf(false) }

    fun load(onDone: (ByteArray?) -> Unit) {
        val c = client ?: return; val r = repo ?: return
        loading = true
        scope.launch {
            val result = try { withContext(Dispatchers.IO) { c.readFileBytes(m.mediaPath, r) } } catch (e: Exception) { error = e.message ?: "couldn't load"; null }
            loading = false; bytes = result; onDone(result)
        }
    }

    if (!isVideo) {
        LaunchedEffect(m.path) { if (bytes == null && error.isEmpty()) load {} }
        when {
            bytes != null -> {
                val bmp = remember(bytes) { BitmapFactory.decodeByteArray(bytes, 0, bytes!!.size) }
                if (bmp != null) Image(bmp.asImageBitmap(), contentDescription = "photo", modifier = Modifier.widthIn(max = 240.dp))
                else Text("[photo couldn't be decoded]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
            loading -> Text("[loading photo…]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            error.isNotEmpty() -> Text("[photo failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
            else -> Text("[photo]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        }
    } else {
        Column {
            Text("[ video ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            TextButton(onClick = { load { b -> b?.let { openVideo(ctx, it) } } }, enabled = !loading) {
                Text(if (loading) "[loading…]" else "[play]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            if (error.isNotEmpty()) Text("[video failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
        }
    }
}

private fun openVideo(ctx: android.content.Context, bytes: ByteArray) {
    val dir = File(ctx.cacheDir, "n").apply { mkdirs() }
    val file = File(dir, "clip-${System.currentTimeMillis()}.mp4")
    file.writeBytes(bytes)
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    ctx.startActivity(intent)
}

private fun timeLabel(ts: Long): String {
    if (ts <= 0L) return ""
    val fmt = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
    return fmt.format(java.util.Date(ts))
}

private fun humanBytes(n: Long): String = when {
    n >= 1_000_000 -> "%.1f MB".format(n / 1_000_000.0)
    n >= 1_000 -> "%.0f KB".format(n / 1_000.0)
    else -> "$n B"
}
