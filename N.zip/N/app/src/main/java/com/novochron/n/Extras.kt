package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.max

// ---------------------------------------------------------------------------------------------
// Stickers and GIFs.
//
//  * Emoji stickers are built in: a big emoji sent as a message with no bubble.
//  * Custom stickers are images kept in the repo's Stickers/ folder, so both phones share one
//    collection. Sending one doesn't re-upload anything — the message just points at the file.
//  * GIFs from the gallery are sent as photos (.gif) and animate in the chat (Android 9+).
//  * GIF search uses GIPHY and needs a free API key (see README); without one that box is hidden.
// ---------------------------------------------------------------------------------------------

const val STICKER_DIR = "Stickers"

private val EmojiStickers = ("😀 😂 🤣 😍 😘 😎 🥺 😭 😡 🥳 😴 🤔 🙄 😱 🤗 😏 " +
    "👍 👎 👏 🙏 🤝 💪 👀 🫶 ❤️ 💔 🔥 ✨ 🎉 💯 🌈 🍕 🍿 ☕ 🌙 ⭐").split(" ")

object Stickers {
    suspend fun list(client: GitHubClient, repo: RepoRef): List<RepoFile> =
        client.listFiles(STICKER_DIR, repo).filter { !it.isDir }.sortedBy { it.path }

    /** Shrinks the picked image to a 512px PNG (keeps transparency) and adds it to the shared collection. Returns an error, or null. */
    suspend fun add(ctx: Context, client: GitHubClient, repo: RepoRef, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0) return@withContext "Couldn't read that image."
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
            var bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@withContext "Couldn't read that image."
            val scale = 512f / max(bmp.width, bmp.height)
            if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true)
            val f = File(ctx.cacheDir, "n/sticker-upload.png").apply { parentFile?.mkdirs() }
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            client.commitFileStream("$STICKER_DIR/stk-${System.currentTimeMillis()}.png", f, "n: sticker", repo)
            f.delete()
            null
        } catch (e: Exception) { if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error" }
    }
}

data class GifHit(val thumb: String, val url: String)

object Giphy {
    val enabled: Boolean get() = BuildConfig.GIPHY_KEY.isNotBlank()

    suspend fun search(query: String): List<GifHit> = withContext(Dispatchers.IO) {
        val key = BuildConfig.GIPHY_KEY
        val base = "https://api.giphy.com/v1/gifs/"
        val url = if (query.isBlank()) "${base}trending?api_key=$key&limit=30&rating=pg-13"
        else "${base}search?api_key=$key&q=${URLEncoder.encode(query, "UTF-8")}&limit=30&rating=pg-13&lang=en"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000; conn.readTimeout = 15_000
        try {
            val body = conn.inputStream.bufferedReader().readText()
            val data = JSONObject(body).getJSONArray("data")
            (0 until data.length()).mapNotNull { i ->
                val im = data.getJSONObject(i).optJSONObject("images") ?: return@mapNotNull null
                val thumb = im.optJSONObject("fixed_width_small_still")?.optString("url").orEmpty()
                val full = (im.optJSONObject("fixed_width")?.optString("url")).orEmpty()
                if (thumb.isBlank() || full.isBlank()) null else GifHit(thumb, full)
            }
        } finally { conn.disconnect() }
    }

    suspend fun bytes(url: String): ByteArray? = withContext(Dispatchers.IO) {
        try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000; conn.readTimeout = 30_000
            try { conn.inputStream.readBytes() } finally { conn.disconnect() }
        } catch (_: Exception) { null }
    }

    suspend fun download(url: String, dest: File): Boolean {
        val b = bytes(url) ?: return false
        return withContext(Dispatchers.IO) { dest.parentFile?.mkdirs(); dest.writeBytes(b); true }
    }
}

/** A repo image (a custom sticker), fetched once and then served from the shared media cache. */
@Composable
fun RepoImage(client: GitHubClient?, repo: RepoRef?, path: String, maxDim: Int, modifier: Modifier) {
    val ctx = LocalContext.current
    var bmp by remember(path) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(path) {
        bmp = withContext(Dispatchers.IO) {
            try {
                val f = mediaCacheFile(ctx, path)
                if (!(f.exists() && f.length() > 0)) {
                    if (client == null || repo == null) return@withContext null
                    f.parentFile?.mkdirs()
                    if (!client.downloadFile(path, repo, f)) return@withContext null
                }
                decodeSampled(f, maxDim)
            } catch (_: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), contentDescription = "sticker", modifier = modifier)
    else Box(modifier, contentAlignment = Alignment.Center) { Text("…", color = Dim, fontFamily = TermFont) }
}

@Composable
private fun UrlImage(url: String, modifier: Modifier) {
    var bmp by remember(url) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(url) {
        val b = Giphy.bytes(url)
        bmp = b?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
    }
    val v = bmp
    if (v != null) Image(v.asImageBitmap(), contentDescription = "gif", modifier = modifier)
    else Box(modifier.background(Raised))
}

/** A GIF that actually moves. Only call on Android 9 (API 28) and up. */
@RequiresApi(28)
@Composable
fun AnimatedGif(file: File, modifier: Modifier, onClick: () -> Unit) {
    AndroidView(
        factory = { c ->
            ImageView(c).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                try {
                    val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file))
                    setImageDrawable(d)
                    (d as? AnimatedImageDrawable)?.let { it.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; it.start() }
                } catch (_: Exception) {}
                setOnClickListener { onClick() }
            }
        },
        modifier = modifier
    )
}

private sealed class Cell {
    data class Header(val text: String) : Cell()
    data class Emoji(val e: String) : Cell()
    data class Custom(val f: RepoFile) : Cell()
}

@Composable
private fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Raised, unfocusedContainerColor = Raised,
    focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
)

/**
 * The sticker / GIF picker. Tapping something sends it and closes the picker.
 * [onAddStickerPick] opens the gallery to choose an image for the shared sticker collection;
 * the caller then calls back into [Stickers.add] and bumps [refreshKey] so the new one shows up.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StickerGifPicker(
    client: GitHubClient?, repo: RepoRef?, refreshKey: Int,
    onDismiss: () -> Unit,
    onEmoji: (String) -> Unit,
    onRepoSticker: (String) -> Unit,
    onAddStickerPick: () -> Unit,
    onGifFromGallery: () -> Unit,
    onGifUrl: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var custom by remember { mutableStateOf<List<RepoFile>>(emptyList()) }
    var note by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf<RepoFile?>(null) }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(refreshKey, reload) {
        if (client != null && repo != null) {
            try { custom = Stickers.list(client, repo) } catch (e: Exception) { note = "Couldn't load stickers." }
        }
    }

    var query by remember { mutableStateOf("") }
    var gifs by remember { mutableStateOf<List<GifHit>>(emptyList()) }
    var gifBusy by remember { mutableStateOf(false) }
    fun searchGifs() {
        scope.launch {
            gifBusy = true; note = ""
            try { gifs = Giphy.search(query.trim()) } catch (e: Exception) { note = "GIF search failed." }
            gifBusy = false
        }
    }
    LaunchedEffect(tab) { if (tab == 1 && Giphy.enabled && gifs.isEmpty()) searchGifs() }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth().fillMaxHeight(0.7f).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                .background(Bg).padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { tab = 0 }) {
                    Text(if (tab == 0) "[● stickers]" else "[stickers]", color = if (tab == 0) Accent else Ink, fontFamily = TermFont, fontSize = 14.sp)
                }
                TextButton(onClick = { tab = 1 }) {
                    Text(if (tab == 1) "[● gifs]" else "[gifs]", color = if (tab == 1) Accent else Ink, fontFamily = TermFont, fontSize = 14.sp)
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("[close]", color = Dim, fontFamily = TermFont, fontSize = 13.sp) }
            }
            if (note.isNotEmpty()) Text(note, color = Warn, fontFamily = TermFont, fontSize = 11.sp)

            if (tab == 0) {
                val cells = buildList<Cell> {
                    add(Cell.Header("emoji"))
                    EmojiStickers.forEach { add(Cell.Emoji(it)) }
                    add(Cell.Header("our stickers · shared through the repo"))
                    custom.forEach { add(Cell.Custom(it)) }
                }
                LazyVerticalGrid(columns = GridCells.Adaptive(64.dp), modifier = Modifier.weight(1f)) {
                    items(cells, span = { if (it is Cell.Header) GridItemSpan(maxLineSpan) else GridItemSpan(1) }) { cell ->
                        when (cell) {
                            is Cell.Header -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(cell.text, color = Dim, fontFamily = TermFont, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
                                if (cell.text.startsWith("our")) {
                                    TextButton(onClick = onAddStickerPick) { Text("[+ add]", color = Accent, fontFamily = TermFont, fontSize = 12.sp) }
                                }
                            }
                            is Cell.Emoji -> Box(
                                Modifier.size(64.dp).clickable { onEmoji(cell.e); onDismiss() },
                                contentAlignment = Alignment.Center
                            ) { Text(cell.e, fontSize = 34.sp) }
                            is Cell.Custom -> Box(
                                Modifier.size(64.dp).padding(4.dp).combinedClickable(
                                    onClick = { onRepoSticker(cell.f.path); onDismiss() },
                                    onLongClick = { confirmDelete = cell.f }
                                ),
                                contentAlignment = Alignment.Center
                            ) { RepoImage(client, repo, cell.f.path, 200, Modifier.fillMaxSize()) }
                        }
                    }
                }
                if (custom.isEmpty()) Text("Tap [+ add] to save an image as a sticker for both of you. Long-press one to remove it.", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
            } else {
                TextButton(onClick = { onGifFromGallery(); onDismiss() }) {
                    Text("[pick a gif from gallery]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (Giphy.enabled) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            placeholder = { Text("search gifs…", color = Dim, fontFamily = TermFont) },
                            textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
                            colors = fieldColors(), modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { searchGifs() }, enabled = !gifBusy) { Text("[go]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
                    }
                    LazyVerticalGrid(columns = GridCells.Adaptive(96.dp), modifier = Modifier.weight(1f)) {
                        items(gifs) { g ->
                            UrlImage(g.thumb, Modifier.padding(2.dp).height(90.dp).fillMaxWidth().clip(RoundedCornerShape(4.dp)).clickable { onGifUrl(g.url); onDismiss() })
                        }
                    }
                    Text("Powered by GIPHY", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
                } else {
                    Text(
                        "GIF search isn't set up. Add a free GIPHY API key (giphyKey in local.properties, or the N_GIPHY_KEY secret in CI) — see the README. Gallery GIFs work without it.",
                        color = Dim, fontFamily = TermFont, fontSize = 11.sp
                    )
                }
            }
        }
    }

    confirmDelete?.let { f ->
        Dialog(onDismissRequest = { confirmDelete = null }) {
            Column(Modifier.clip(RoundedCornerShape(10.dp)).background(Raised).padding(16.dp)) {
                Text("Remove this sticker for both of you?", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Row {
                    TextButton(onClick = {
                        confirmDelete = null
                        scope.launch {
                            try { if (client != null && repo != null) client.deleteFile(f.path, f.sha, "n: remove sticker", repo); reload++ }
                            catch (e: Exception) { note = "Couldn't remove it." }
                        }
                    }) { Text("[remove]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    TextButton(onClick = { confirmDelete = null }) { Text("[keep]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
                }
            }
        }
    }
}
