package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.sqrt

/**
 * A lightweight, fully on-device "does this match a hardcoded face?" gate.
 *
 * How it works: ML Kit's face detector finds a handful of facial landmarks (eyes, nose,
 * mouth corners). We turn those into a small set of distances between landmarks, normalized
 * by the distance between the eyes so it doesn't matter how close the phone is to your face.
 * That normalized vector is compared against the same vector computed from the reference
 * photo(s) bundled in the app. It's geometry-based, not a trained face-embedding model, so
 * treat it as a "good enough to keep casual snoopers out" lock, not a hardened biometric.
 *
 * To add or change whose face unlocks the app: drop a clear, front-facing photo into
 * res/drawable (e.g. ref_face_2.jpg) and add its resource id to REFERENCE_DRAWABLES below.
 */
object FaceLock {

    // Hardcoded reference face(s). Add more R.drawable.xxx ids here to allow more than one face.
    private val REFERENCE_DRAWABLES = listOf(R.drawable.ref_face_1)

    // Lower = stricter match. This is a heuristic; if it's rejecting the right face, raise it
    // a bit (e.g. 0.22-0.26); if it's accepting the wrong face, lower it.
    private const val MATCH_THRESHOLD = 0.20f

    private const val MAX_DECODE_DIM = 1024

    private val landmarkIds = intArrayOf(
        FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE, FaceLandmark.NOSE_BASE,
        FaceLandmark.MOUTH_LEFT, FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM
    )

    private var cachedReferenceVectors: List<FloatArray>? = null

    /** Creates a content:// Uri (via the app's existing FileProvider) for the camera to write a capture into. */
    fun newCaptureUri(ctx: Context): Uri {
        val dir = File(ctx.cacheDir, "n").apply { mkdirs() }
        val file = File(dir, "facelock-${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    }

    sealed class Result {
        object Match : Result()
        object NoMatch : Result()
        object NoFaceFound : Result()
        data class Error(val message: String) : Result()
    }

    /** Runs detection on the captured photo and compares it against the hardcoded reference(s). */
    suspend fun verify(ctx: Context, capturedUri: Uri): Result {
        return try {
            val bitmap = decodeSampledBitmap(ctx, capturedUri) ?: return Result.Error("Couldn't read the photo.")
            val liveVector = detectFeatureVector(bitmap) ?: return Result.NoFaceFound

            val references = referenceVectors(ctx)
            if (references.isEmpty()) return Result.Error("No reference face is bundled in the app.")

            val bestDistance = references.minOf { distance(it, liveVector) }
            if (bestDistance <= MATCH_THRESHOLD) Result.Match else Result.NoMatch
        } catch (e: Exception) {
            Result.Error(e.message ?: "face check failed")
        }
    }

    private suspend fun referenceVectors(ctx: Context): List<FloatArray> {
        cachedReferenceVectors?.let { return it }
        val vectors = REFERENCE_DRAWABLES.mapNotNull { resId ->
            val bmp = BitmapFactory.decodeResource(ctx.resources, resId) ?: return@mapNotNull null
            detectFeatureVector(bmp)
        }
        cachedReferenceVectors = vectors
        return vectors
    }

    private suspend fun detectFeatureVector(bitmap: Bitmap): FloatArray? {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()
        val detector: FaceDetector = FaceDetection.getClient(options)
        val faces = try {
            detectFaces(detector, InputImage.fromBitmap(bitmap, 0))
        } finally {
            detector.close()
        }
        // Assume the largest face in frame is the one trying to unlock.
        val face = faces.maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() } ?: return null
        return faceToVector(face)
    }

    private suspend fun detectFaces(detector: FaceDetector, image: InputImage): List<Face> =
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { faces -> if (cont.isActive) cont.resume(faces) }
                .addOnFailureListener { e -> if (cont.isActive) cont.resume(emptyList()) }
        }

    private fun faceToVector(face: Face): FloatArray? {
        val points = landmarkIds.map { id ->
            face.getLandmark(id)?.position ?: return null
        }
        val leftEye = points[0]
        val rightEye = points[1]
        val eyeDist = hypot(leftEye.x - rightEye.x, leftEye.y - rightEye.y)
        if (eyeDist < 1f) return null

        val dims = ArrayList<Float>()
        for (i in points.indices) {
            for (j in i + 1 until points.size) {
                // Skip the eye-to-eye distance itself: it's the normalizer, always ~1.0.
                if (i == 0 && j == 1) continue
                val d = hypot(points[i].x - points[j].x, points[i].y - points[j].y) / eyeDist
                dims.add(d)
            }
        }
        return dims.toFloatArray()
    }

    private fun distance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return Float.MAX_VALUE
        var sum = 0f
        for (i in a.indices) {
            val diff = a[i] - b[i]
            sum += diff * diff
        }
        return sqrt(sum / a.size)
    }

    private fun hypot(dx: Float, dy: Float): Float = sqrt(dx * dx + dy * dy)

    private fun decodeSampledBitmap(ctx: Context, uri: Uri): Bitmap? {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null

        var sample = 1
        while (bounds.outWidth / sample > MAX_DECODE_DIM || bounds.outHeight / sample > MAX_DECODE_DIM) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }
}
