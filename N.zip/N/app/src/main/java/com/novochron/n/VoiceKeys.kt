package com.novochron.n

import org.json.JSONArray
import org.json.JSONObject

/** Where the list of repo voice keys lives — in the *base* repo, next to Config/secret.txt. */
internal const val VOICE_KEYS_PATH = "Config/voicekeys.json"

/** One extra voice key: say [word] at the gate and N opens on [repo] ("owner/name") instead. */
data class VoiceKey(val word: String, val repo: String)

internal fun parseVoiceKeys(json: String?): List<VoiceKey> {
    if (json.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val w = o.optString("word").trim(); val r = o.optString("repo").trim()
            if (w.isBlank() || RepoRef.parse(r) == null) null else VoiceKey(w, RepoRef.parse(r)!!.full)
        }
    } catch (_: Exception) { emptyList() }
}

internal fun voiceKeysToJson(keys: List<VoiceKey>): String {
    val arr = JSONArray()
    keys.forEach { arr.put(JSONObject().apply { put("word", it.word); put("repo", it.repo) }) }
    return arr.toString(2)
}

/**
 * Checks the list typed in the debug panel. Returns the cleaned list, or an error message.
 * Rows that are completely empty are dropped; half-filled rows, bad repo names and two keys
 * with the same spoken word are rejected (the gate couldn't tell them apart).
 */
internal fun validateVoiceKeys(rows: List<VoiceKey>, mainWord: String): Pair<List<VoiceKey>?, String> {
    val out = ArrayList<VoiceKey>()
    val seen = HashSet<String>()
    val main = normalizeSpeech(mainWord).trim()
    rows.forEachIndexed { i, row ->
        val w = row.word.trim(); val r = row.repo.trim()
        if (w.isBlank() && r.isBlank()) return@forEachIndexed
        val n = i + 1
        if (w.isBlank()) return null to "Key #$n has a repo but no word."
        val ref = RepoRef.parse(r) ?: return null to "Key #$n: bad repo — expected \"owner/name\"."
        val norm = normalizeSpeech(w).trim()
        if (norm.isBlank()) return null to "Key #$n: the word has no letters or digits."
        if (norm == main) return null to "Key #$n is the same as the main secret word."
        if (!seen.add(norm)) return null to "Key #$n repeats another key's word."
        out.add(VoiceKey(w, ref.full))
    }
    return out to ""
}
