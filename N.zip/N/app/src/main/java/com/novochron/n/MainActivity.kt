package com.novochron.n

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

// ---- theme, matching Novochron's terminal look ----
val Accent = Color(0xFF3DFF5C)
val Ink = Color(0xFFE8E8E8)
val Dim = Color(0xFF8C8C8C)
val Line = Color(0xFF262626)
val Raised = Color(0xFF101010)
val Warn = Color(0xFFFF5C5C)
val Mine = Color(0xFF0E2A12)
val TermFont = FontFamily.Monospace

private const val MSG_DIR = "Msg"
private const val MSG_MEDIA_DIR = "Msg/media"
private const val POLL_MS = 1000L              // cheap: unchanged polls come back as empty 304s
private const val FETCH_PARALLELISM = 6         // new message files fetched this many at a time
// GitHub's Contents API tops out at 100 MB per file — that's the real ceiling for photos/videos/voice.
private const val MAX_MEDIA_BYTES = 100L * 1024 * 1024

private enum class MsgType { TEXT, PHOTO, VIDEO, VOICE }
/** A snapshot of the message being replied to, so the quote still shows even if the original is gone. */
private data class ReplyRef(val path: String, val from: String, val preview: String)
private data class ChatMsg(
    val path: String, val sender: String, val ts: Long, val type: MsgType,
    val text: String = "", val mediaPath: String = "", val durationMs: Long = 0L,
    val pending: Boolean = false, val reply: ReplyRef? = null
)

/** In-memory event log shown in the debug panel. Never records the secret word or what was said at the gate. */
object DebugLog {
    val lines = mutableStateListOf<String>()
    fun add(msg: String) {
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        if (lines.lastOrNull()?.drop(10) == msg) return          // collapse repeats (e.g. polling while offline)
        lines.add("$stamp  $msg")
        while (lines.size > 100) lines.removeAt(0)
    }
}

/**
 * Debug-only runtime toggles, flipped from the debug panel to make the app misbehave on purpose
 * so its error paths / retry logic / UI states can be exercised. All reset to defaults on process
 * restart — nothing here is persisted.
 */
object DebugFlags {
    var simulateSendFailure by mutableStateOf(false)   // every send throws instead of hitting the network
    var verbosePolling by mutableStateOf(false)        // log every poll tick, not just changes
    var pollIntervalMs by mutableStateOf(POLL_MS)       // overrides the normal 1s poll cadence
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color.Black)) {
                NApp(Store(applicationContext))
            }
        }
    }
}

private const val SECRET_PATH = "Config/secret.txt"   // lives in the shared repo, never inside the app

@Composable
fun NApp(store: Store) {
    var nameText by remember { mutableStateOf(store.name.ifBlank { "me" }) }
    var editingSetup by remember { mutableStateOf(store.name.isBlank()) }
    var setupStatus by remember { mutableStateOf("") }

    // Voice gate state. Nothing here is persisted: every launch starts locked, and the secret word
    // is only ever held in memory after being fetched from the repo.
    var unlocked by remember { mutableStateOf(false) }
    var secret by remember { mutableStateOf<String?>(null) }
    var showDebug by remember { mutableStateOf(false) }
    var showAr by remember { mutableStateOf(false) }
    var reloadTick by remember { mutableStateOf(0) }   // bumped when the chat should reload (name changed, cache cleared)
    LaunchedEffect(Unit) { DebugLog.add("app started v${BuildConfig.VERSION_NAME}") }

    // While locked, keep fetching the word from the repo. Fails closed: no word (offline, missing
    // file, bad token) means the gate simply stays shut.
    LaunchedEffect(unlocked) {
        if (unlocked) { secret = null; return@LaunchedEffect }
        val r = RepoRef.parse(store.repo)
        if (r == null || store.token.isBlank()) return@LaunchedEffect
        val c = GitHubClient(store.token, store.branch)
        while (true) {
            val w = try {
                c.readFile(SECRET_PATH, r)?.trim().also { if (it == null) DebugLog.add("secret file not found in repo") }
            } catch (e: Exception) { DebugLog.add("secret fetch error: ${e.message?.take(60)}"); null }
            if (!w.isNullOrBlank()) secret = w
            delay(if (secret == null) 3000 else 8000)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!unlocked) {
            // Pitch black. No text, no title — just the mic listening until the word is heard.
            VoiceGate(secret, paused = showDebug) { DebugLog.add("gate: unlocked by voice"); unlocked = true }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("N", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TextButton(onClick = { showAr = true }) { Text("[AR]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                }
                Spacer(Modifier.height(8.dp))

                if (editingSetup) {
                    SetupForm(
                        nameText, setupStatus,
                        onName = { nameText = it },
                        canCancel = store.name.isNotBlank(),
                        onCancel = { editingSetup = false; setupStatus = "" },
                        onSave = {
                            store.name = nameText.ifBlank { "me" }
                            editingSetup = false
                            setupStatus = ""
                        }
                    )
                } else {
                    key(reloadTick) { ChatBody(store) }
                }
            }
        }

        if (showDebug) {
            DebugPanel(
                store,
                onWordSaved = { secret = it },
                onNameSaved = { nameText = it; reloadTick++ },
                onCacheCleared = { reloadTick++ },
                onLock = { DebugLog.add("locked from debug"); unlocked = false; showDebug = false },
                onForceUnlock = { DebugLog.add("force-unlocked from debug"); unlocked = true; showDebug = false },
                onReset = {
                    store.name = ""; store.branch = "main"
                    nameText = ""; editingSetup = true; reloadTick++
                    DebugLog.add("app reset from debug"); showDebug = false
                },
                onClose = { showDebug = false }
            )
        } else {
            // The invisible debug button, top-left. Five quick taps opens the debug panel.
            var taps by remember { mutableStateOf(0) }
            var lastTap by remember { mutableStateOf(0L) }
            Box(
                Modifier.align(Alignment.TopStart).size(56.dp).clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null
                ) {
                    val now = System.currentTimeMillis()
                    taps = if (now - lastTap < 1500) taps + 1 else 1
                    lastTap = now
                    if (taps >= 5) { taps = 0; showDebug = true }
                }
            )
        }

        if (showAr) {
            ArScreen(store, onClose = { showAr = false })
        }
    }
}

private fun normalizeSpeech(t: String): String =
    " " + t.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim().replace(Regex("\\s+"), " ") + " "

/**
 * Black screen that listens with the mic non-stop (restarting the recognizer whenever it times out)
 * and only lets go once the secret word is heard. [word] == null means it isn't known yet
 * (still fetching / unreachable) — the gate stays shut and keeps listening.
 */
@Composable
private fun VoiceGate(word: String?, paused: Boolean, onPass: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(Manifest.permission.RECORD_AUDIO) }

    val currentWord by rememberUpdatedState(word)
    val passed by rememberUpdatedState(onPass)

    DisposableEffect(granted, paused) {
        view.keepScreenOn = true
        if (!granted || paused || !SpeechRecognizer.isRecognitionAvailable(ctx)) {
            return@DisposableEffect onDispose { view.keepScreenOn = false }
        }
        val handler = Handler(Looper.getMainLooper())
        var alive = true
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        fun listen() { if (alive) try { sr.startListening(intent) } catch (_: Exception) { handler.postDelayed({ if (alive) listen() }, 1000) } }
        fun relisten(delayMs: Long) { handler.postDelayed({ if (alive) { try { sr.cancel() } catch (_: Exception) {}; listen() } }, delayMs) }
        fun heard(list: List<String>?): Boolean {
            val w = currentWord?.let { normalizeSpeech(it) } ?: return false
            if (w.isBlank()) return false
            if (list?.any { normalizeSpeech(it).contains(w) } == true) {
                alive = false
                handler.removeCallbacksAndMessages(null)
                try { sr.cancel(); sr.destroy() } catch (_: Exception) {}
                passed()
                return true
            }
            return false
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                if (!heard(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))) relisten(150)
            }
            override fun onPartialResults(partial: Bundle?) {
                heard(partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION))
            }
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) return
                relisten(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000 else 250)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        listen()
        onDispose {
            alive = false
            handler.removeCallbacksAndMessages(null)
            try { sr.cancel(); sr.destroy() } catch (_: Exception) {}
            view.keepScreenOn = false
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black))
}

/** Hidden debug screen. The secret word is read from / written to the repo — it isn't stored in the app. */
@Composable
private fun DebugPanel(
    store: Store, onWordSaved: (String) -> Unit, onNameSaved: (String) -> Unit,
    onCacheCleared: () -> Unit, onLock: () -> Unit, onForceUnlock: () -> Unit,
    onReset: () -> Unit, onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }
    var word by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var dbgName by remember { mutableStateOf(store.name) }
    var nameStatus by remember { mutableStateOf("") }
    var toolStatus by remember { mutableStateOf("") }
    var cacheInfo by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var heard by remember { mutableStateOf("") }
    var simulateFailure by remember { mutableStateOf(DebugFlags.simulateSendFailure) }
    var verbosePolling by remember { mutableStateOf(DebugFlags.verbosePolling) }
    var pollMs by remember { mutableStateOf(DebugFlags.pollIntervalMs) }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmArDelete by remember { mutableStateOf(false) }
    var clearingAr by remember { mutableStateOf(false) }
    var arStatus by remember { mutableStateOf("") }
    var msgFolder by remember { mutableStateOf("") }
    val micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    BackHandler(onBack = onClose)

    fun refreshCacheInfo() {
        val chat = msgCacheFile(ctx, store.repo, store.branch)
        val ar = dirSize(File(ctx.cacheDir, "n/ar_media")) + dirSize(File(ctx.cacheDir, "n/ar_pending"))
        cacheInfo = "chat ${humanBytes(chat.length())} · media ${humanBytes(dirSize(File(ctx.cacheDir, "n/media")))} · AR ${humanBytes(ar)}"
    }

    fun deleteArFiles() {
        val r = repo; val c = client
        if (r == null || c == null) { arStatus = "No repo/token configured."; return }
        scope.launch {
            clearingAr = true; arStatus = "Deleting AR signs…"
            try {
                withContext(Dispatchers.IO) {
                    try { c.deleteTree(AR_DIR, r, "n: clear AR signs") }
                    catch (e: Exception) { c.deleteAll(AR_DIR, r, "n: clear AR signs") }   // slow fallback
                }
                withContext(Dispatchers.IO) { clearArCache(ctx, store.repo, store.branch) }
                refreshCacheInfo()
                arStatus = "All AR signs deleted."; DebugLog.add("AR signs cleared")
            } catch (e: Exception) {
                arStatus = "Couldn't delete AR signs: ${errText(e)}"; DebugLog.add("AR clear failed: ${errText(e)}")
            }
            clearingAr = false
        }
    }

    suspend fun load() {
        val r = repo; val c = client
        if (r == null || c == null) { status = "No repo/token configured."; loaded = true; return }
        working = true; status = "Loading word from repo…"
        try {
            val w = c.readFile(SECRET_PATH, r)?.trim()
            if (w == null) { status = "No word set in the repo yet ($SECRET_PATH). Type one and [save]." }
            else { word = w; status = "" }
        } catch (e: Exception) { status = "Couldn't load: ${errText(e)}" }
        working = false; loaded = true
    }
    LaunchedEffect(Unit) { load(); refreshCacheInfo() }

    // Voice test: one-shot listen that shows what the recognizer heard and whether it matches the word typed above.
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) { heard = ""; testing = true } }
    DisposableEffect(testing) {
        if (!testing) return@DisposableEffect onDispose {}
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            heard = "(no speech recognizer on this device)"; testing = false
            return@DisposableEffect onDispose {}
        }
        val sr = SpeechRecognizer.createSpeechRecognizer(ctx)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard = it }
                testing = false
            }
            override fun onPartialResults(partial: Bundle?) {
                partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard = it }
            }
            override fun onError(error: Int) { if (heard.isBlank()) heard = "(nothing heard — error $error)"; testing = false }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        try { sr.startListening(intent) } catch (e: Exception) { heard = "(couldn't start: ${e.message})"; testing = false }
        onDispose { try { sr.cancel(); sr.destroy() } catch (_: Exception) {} }
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().imePadding()
            .padding(horizontal = 14.dp, vertical = 12.dp).verticalScroll(rememberScrollState())
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("debug", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }

        // ---- info
        Text("${store.repo} @ ${store.branch} · v${BuildConfig.VERSION_NAME} · token ${if (store.token.isBlank()) "MISSING" else "set"}",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Text("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MODEL}", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Text("mic ${if (micGranted) "granted" else "denied"} · speech service ${if (SpeechRecognizer.isRecognitionAvailable(ctx)) "yes" else "no"} · cache $cacheInfo",
            color = Dim, fontFamily = TermFont, fontSize = 11.sp)

        // ---- secret word
        Spacer(Modifier.height(16.dp))
        Text("Secret word (stored in the repo at $SECRET_PATH):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        NTextField(word, { word = it }, "secret word", password = !show)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = { show = !show }) { Text(if (show) "[hide]" else "[show]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { scope.launch { load() } }, enabled = !working) { Text("[reload]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(
                enabled = !working && loaded && word.isNotBlank(),
                onClick = {
                    val r = repo; val c = client; if (r == null || c == null) return@TextButton
                    val w = word.trim()
                    scope.launch {
                        working = true; status = "Saving…"
                        try {
                            withContext(Dispatchers.IO) { c.writeFile(SECRET_PATH, w, "n: config", r) }
                            word = w; onWordSaved(w); status = "Saved to the repo."; DebugLog.add("secret word updated")
                        } catch (e: Exception) { status = "Couldn't save: ${errText(e)}"; DebugLog.add("secret save failed: ${errText(e)}") }
                        working = false
                    }
                }
            ) { Text("[save]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        }
        if (status.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
        }

        // ---- name
        Spacer(Modifier.height(20.dp))
        Text("Your name (can only be changed here):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        NTextField(dbgName, { dbgName = it }, "me")
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                val n = dbgName.trim().ifBlank { "me" }
                store.name = n; dbgName = n; onNameSaved(n); nameStatus = "Name changed to \"$n\"."; DebugLog.add("name changed")
            }) { Text("[save name]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            if (nameStatus.isNotEmpty()) Text(nameStatus, color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        }

        // ---- test tools
        Spacer(Modifier.height(20.dp))
        Text("Tools:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    toolStatus = "Pinging GitHub…"
                    toolStatus = try { c.ping(r) } catch (e: Exception) { "Ping failed: ${errText(e)}" }
                    DebugLog.add("ping: $toolStatus")
                }
            }) { Text("[ping github]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    val me = store.name.ifBlank { "me" }
                    val ts = System.currentTimeMillis()
                    val path = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
                    toolStatus = "Sending test message…"
                    try {
                        val body = JSONObject().apply { put("from", me); put("ts", ts); put("type", "TEXT"); put("text", "[debug] test message") }
                        withContext(Dispatchers.IO) { c.commitFile(path, body.toString(), "n: debug test", r) }
                        toolStatus = "Test message sent."; DebugLog.add("test message sent")
                    } catch (e: Exception) { toolStatus = "Test failed: ${errText(e)}"; DebugLog.add("test message failed: ${errText(e)}") }
                }
            }) { Text("[test message]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                scope.launch {
                    withContext(Dispatchers.IO) {
                        msgCacheFile(ctx, store.repo, store.branch).delete()
                        File(ctx.cacheDir, "n/media").deleteRecursively()
                    }
                    refreshCacheInfo(); onCacheCleared(); toolStatus = "Local cache cleared."; DebugLog.add("local cache cleared")
                }
            }) { Text("[clear cache]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                if (testing) testing = false
                else if (micGranted) { heard = ""; testing = true }
                else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }) { Text(if (testing) "[stop voice test]" else "[test voice]", color = if (testing) Warn else Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        if (toolStatus.isNotEmpty()) Text(toolStatus, color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        if (testing || heard.isNotEmpty()) {
            Text("heard: ${heard.ifEmpty { "…" }}", color = Ink, fontFamily = TermFont, fontSize = 12.sp)
            if (word.isNotBlank() && heard.isNotBlank() && !heard.startsWith("(")) {
                val ok = normalizeSpeech(heard).contains(normalizeSpeech(word))
                Text(if (ok) "matches the word above" else "doesn't match the word above", color = if (ok) Accent else Warn, fontFamily = TermFont, fontSize = 12.sp)
            }
        }

        // ---- AR
        Spacer(Modifier.height(16.dp))
        Text("AR signs:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = { confirmArDelete = true }, enabled = !clearingAr) {
                Text(
                    if (clearingAr) "[deleting…]" else "[delete all AR files]",
                    color = Warn, fontFamily = TermFont, fontSize = 13.sp
                )
            }
        }
        if (arStatus.isNotEmpty()) Text(arStatus, color = Dim, fontFamily = TermFont, fontSize = 12.sp)

        // ---- more tools
        Spacer(Modifier.height(16.dp))
        Text("More tools:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = onForceUnlock) { Text("[force unlock]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    toolStatus = "Checking rate limit…"
                    toolStatus = try {
                        withContext(Dispatchers.IO) { c.rateLimit() }
                    } catch (e: Exception) { "Rate limit check failed: ${errText(e)}" }
                    DebugLog.add("rate limit: $toolStatus")
                }
            }) { Text("[rate limit]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = {
                val r = repo; val c = client
                if (r == null || c == null) { toolStatus = "No repo/token configured."; return@TextButton }
                scope.launch {
                    toolStatus = "Listing $MSG_DIR…"
                    try {
                        val files = withContext(Dispatchers.IO) { c.listFiles(MSG_DIR, r) }
                        msgFolder = files.joinToString("\n") { it.path }
                        toolStatus = "${files.size} entries in $MSG_DIR."
                        DebugLog.add("listed $MSG_DIR: ${files.size} entries")
                    } catch (e: Exception) { toolStatus = "Listing failed: ${errText(e)}"; DebugLog.add("list failed: ${errText(e)}") }
                }
            }) { Text("[list ${MSG_DIR}]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                simulateFailure = !simulateFailure; DebugFlags.simulateSendFailure = simulateFailure
                DebugLog.add("simulate send failure: ${if (simulateFailure) "ON" else "off"}")
            }) {
                Text(
                    if (simulateFailure) "[simulate failure: ON]" else "[simulate failure: off]",
                    color = if (simulateFailure) Warn else Ink, fontFamily = TermFont, fontSize = 13.sp
                )
            }
            TextButton(onClick = {
                verbosePolling = !verbosePolling; DebugFlags.verbosePolling = verbosePolling
                DebugLog.add("verbose polling: ${if (verbosePolling) "ON" else "off"}")
            }) {
                Text(
                    if (verbosePolling) "[verbose polling: ON]" else "[verbose polling: off]",
                    color = if (verbosePolling) Accent else Ink, fontFamily = TermFont, fontSize = 13.sp
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("poll every:", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            listOf(250L to "250ms", 1000L to "1s", 5000L to "5s", 15000L to "15s").forEach { (ms, label) ->
                TextButton(onClick = { pollMs = ms; DebugFlags.pollIntervalMs = ms; DebugLog.add("poll interval set to $label") }) {
                    Text(if (pollMs == ms) "[$label]" else label, color = if (pollMs == ms) Accent else Ink, fontFamily = TermFont, fontSize = 12.sp)
                }
            }
        }
        if (msgFolder.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(msgFolder, color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                val report = buildString {
                    appendLine("N debug report")
                    appendLine("repo: ${store.repo} @ ${store.branch}")
                    appendLine("version: ${BuildConfig.VERSION_NAME}")
                    appendLine("token: ${if (store.token.isBlank()) "MISSING" else "set (" + store.token.take(4) + "…)"}")
                    appendLine("name: ${store.name}")
                    appendLine("android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MODEL}")
                    appendLine("mic: ${if (micGranted) "granted" else "denied"} · speech service: ${if (SpeechRecognizer.isRecognitionAvailable(ctx)) "yes" else "no"}")
                    appendLine("cache: $cacheInfo")
                    appendLine("simulate failure: $simulateFailure · verbose polling: $verbosePolling · poll interval: ${pollMs}ms")
                    appendLine("---- log tail ----")
                    DebugLog.lines.takeLast(30).forEach { appendLine(it) }
                }
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("N debug report", report))
                Toast.makeText(ctx, "Debug report copied", Toast.LENGTH_SHORT).show()
                DebugLog.add("debug report copied")
            }) { Text("[copy debug report]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }

        // ---- log
        Spacer(Modifier.height(20.dp))
        val log = DebugLog.lines
        Text("Log (${log.size}):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        if (log.isEmpty()) Text("(empty)", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
        log.takeLast(30).forEach { Text(it, color = Dim, fontFamily = TermFont, fontSize = 10.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextButton(onClick = {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("N log", log.joinToString("\n")))
                Toast.makeText(ctx, "Log copied", Toast.LENGTH_SHORT).show()
            }) { Text("[copy log]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { log.clear() }) { Text("[clear log]", color = Ink, fontFamily = TermFont, fontSize = 13.sp) }
        }

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            TextButton(onClick = onLock) { Text("[lock now]", color = Warn, fontFamily = TermFont, fontSize = 13.sp) }
            TextButton(onClick = { confirmReset = true }) { Text("[reset app]", color = Warn, fontFamily = TermFont, fontSize = 13.sp) }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset this app?", fontFamily = TermFont) },
            text = { Text("Clears your saved name and branch on this device and drops you back at setup. Chat history in the repo is untouched.", fontFamily = TermFont, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { confirmReset = false; onReset() }) {
                    Text("[reset]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("[cancel]", color = Ink, fontFamily = TermFont) }
            }
        )
    }
    if (confirmArDelete) {
        AlertDialog(
            onDismissRequest = { confirmArDelete = false },
            title = { Text("Delete all AR signs?", fontFamily = TermFont) },
            text = { Text("Removes every sign — and its photo, if it has one — from the shared repo's AR/ folder for both of you, and clears the local AR cache on this device. Can't be undone.", fontFamily = TermFont, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { confirmArDelete = false; deleteArFiles() }) {
                    Text("[delete]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmArDelete = false }) { Text("[cancel]", color = Ink, fontFamily = TermFont) }
            }
        )
    }
}

@Composable
private fun SetupForm(
    nameText: String, status: String,
    onName: (String) -> Unit,
    canCancel: Boolean, onCancel: () -> Unit, onSave: () -> Unit
) {
    Text("Your name (shown on your messages):", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
    Spacer(Modifier.height(4.dp))
    NTextField(nameText, onName, "me")
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        TextButton(onClick = onSave) { Text("[save]", color = Accent, fontFamily = TermFont, fontSize = 14.sp) }
        if (canCancel) TextButton(onClick = onCancel) { Text("[cancel]", color = Ink, fontFamily = TermFont, fontSize = 14.sp) }
    }
    if (status.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text(status, color = Warn, fontFamily = TermFont, fontSize = 12.sp)
    }
}

@Composable
private fun NTextField(value: String, onChange: (String) -> Unit, placeholder: String, password: Boolean = false) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(placeholder, color = Dim, fontFamily = TermFont) },
        visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Raised, unfocusedContainerColor = Raised,
            focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ColumnScope.ChatBody(store: Store) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }

    var messages by remember { mutableStateOf(listOf<ChatMsg>()) }
    val known = remember { mutableSetOf<String>() }
    var input by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<ChatMsg?>(null) }   // message currently being replied to
    var busy by remember { mutableStateOf(false) }          // a photo/video/voice upload is in progress
    var status by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var clearing by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<Pair<File, String>?>(null) }   // photo open full-screen: (file, mediaPath)
    var cacheReady by remember { mutableStateOf(false) }
    val sendLock = remember { Mutex() }                     // commits to one branch go out one at a time
    val listState = rememberLazyListState()
    val cacheFile = remember(store.repo, store.branch) { msgCacheFile(ctx, store.repo, store.branch) }

    // If either of these is null, nothing below can talk to GitHub at all. Surface that
    // clearly instead of every call silently no-op'ing (see poll()/sendText()/etc below).
    val configError = when {
        repo == null -> "Bad repo format (\"${store.repo}\") — expected \"owner/name\"."
        client == null -> "No GitHub token configured. If this is a local build, fill in " +
            "local.properties. If this came from CI, add the N_GH_TOKEN repo secret and rerun the build."
        else -> null
    }

    suspend fun poll() {
        val r = repo ?: return
        val c = client ?: return
        if (DebugFlags.verbosePolling) DebugLog.add("poll: checking $MSG_DIR")
        val files = try {
            c.listFiles(MSG_DIR, r)
        } catch (e: GitHubApiException) {
            status = "Couldn't check for messages: ${e.body.take(80)}"; DebugLog.add("poll error: HTTP ${e.code}"); return
        } catch (e: Exception) {
            status = "Couldn't check for messages: ${e.message ?: "unknown error"}"; DebugLog.add("poll error: ${e.message?.take(60)}"); return
        }
        val jsonFiles = files.filter { !it.isDir && it.path.endsWith(".json") }

        // Drop messages that were deleted remotely (e.g. the other person hit [clear]).
        val listed = jsonFiles.mapTo(HashSet()) { it.path }
        val recent = System.currentTimeMillis() - 30_000
        val gone = messages.filter { !it.pending && it.path !in listed && it.ts < recent }.mapTo(HashSet()) { it.path }
        if (gone.isNotEmpty()) { messages = messages.filter { it.path !in gone }; known.removeAll(gone) }

        val newOnes = jsonFiles.filter { it.path !in known }
        if (newOnes.isEmpty()) {
            if (DebugFlags.verbosePolling) DebugLog.add("poll: ${jsonFiles.size} files, 0 new")
            return
        }

        // Fetch all new message files at once (a few at a time) instead of one after another.
        val gate = Semaphore(FETCH_PARALLELISM)
        val parsed = coroutineScope {
            newOnes.sortedBy { it.path }.map { f -> async { gate.withPermit { fetchMessage(c, r, f.path, known) } } }.awaitAll()
        }.filterNotNull()
        for (m in parsed) known += m.path
        if (parsed.isNotEmpty()) { messages = (messages + parsed).sortedBy { it.ts }; status = "" }
        if (DebugFlags.verbosePolling) DebugLog.add("poll: ${jsonFiles.size} files, ${parsed.size} new")
    }

    LaunchedEffect(store.repo, store.token, store.branch) {
        messages = emptyList(); known.clear(); cacheReady = false
        if (configError != null) { status = configError; return@LaunchedEffect }
        // Show the last-seen chat instantly, then catch up with whatever's new.
        val cached = withContext(Dispatchers.IO) { loadMsgCache(cacheFile) }
        messages = cached; known.addAll(cached.map { it.path }); cacheReady = true
        if (repo != null && client != null) {
            while (true) { poll(); delay(DebugFlags.pollIntervalMs) }
        }
    }
    LaunchedEffect(messages, cacheReady) {
        if (!cacheReady) return@LaunchedEffect
        delay(400)
        val snapshot = messages
        withContext(Dispatchers.IO) { saveMsgCache(cacheFile, snapshot) }
    }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    fun markSent(path: String) { messages = messages.map { if (it.path == path) it.copy(pending = false) else it } }
    fun dropFailed(path: String) { known -= path; messages = messages.filter { it.path != path } }

    // Text goes on screen instantly; the commit happens in the background.
    fun sendText(text: String) {
        val r = repo ?: return; val c = client ?: run { status = configError ?: "Not configured."; return }
        val trimmed = text.trim(); if (trimmed.isEmpty()) return
        input = ""
        val target = replyTo; val rr = target?.toReplyRef(); replyTo = null
        val me = store.name.ifBlank { "me" }
        val ts = System.currentTimeMillis()
        val path = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
        known += path
        messages = messages + ChatMsg(path, me, ts, MsgType.TEXT, text = trimmed, pending = true, reply = rr)
        scope.launch {
            try {
                if (DebugFlags.simulateSendFailure) throw Exception("Simulated failure (debug)")
                val body = JSONObject().apply { put("from", me); put("ts", ts); put("type", "TEXT"); put("text", trimmed); rr?.let { putReply(it) } }
                sendLock.withLock { c.commitFile(path, body.toString(), "n: text", r) }
                markSent(path)
            } catch (e: Exception) {
                dropFailed(path)
                if (input.isBlank()) input = trimmed
                if (replyTo == null) replyTo = target
                status = "Failed to send: ${errText(e)}"; DebugLog.add("send failed: ${errText(e)}")
            }
        }
    }

    /** [local] is already in the media cache, so the bubble shows it right away while it uploads. */
    suspend fun sendMediaFile(local: File, mediaPath: String, type: MsgType, ts: Long, durationMs: Long = 0L, reply: ReplyRef? = null) {
        val r = repo; val c = client
        if (r == null || c == null) { local.delete(); status = configError ?: "Not configured."; busy = false; return }
        val me = store.name.ifBlank { "me" }
        val label = type.name.lowercase()
        val jsonPath = "$MSG_DIR/$ts-${UUID.randomUUID().toString().take(6)}.json"
        busy = true
        status = "Uploading $label…"
        known += jsonPath
        messages = messages + ChatMsg(jsonPath, me, ts, type, mediaPath = mediaPath, durationMs = durationMs, pending = true, reply = reply)
        try {
            if (DebugFlags.simulateSendFailure) throw Exception("Simulated failure (debug)")
            sendLock.withLock {
                c.commitFileStream(mediaPath, local, "n: $label", r) { pct -> status = "Uploading $label… $pct%" }
                val body = JSONObject().apply {
                    put("from", me); put("ts", ts); put("type", type.name); put("media", mediaPath)
                    if (durationMs > 0) put("duration", durationMs)
                    reply?.let { putReply(it) }
                }
                c.commitFile(jsonPath, body.toString(), "n: $label", r)
            }
            markSent(jsonPath)
            status = ""
        } catch (e: Exception) {
            dropFailed(jsonPath); local.delete()
            status = "Failed to send: ${errText(e)}"; DebugLog.add("$label send failed: ${errText(e)}")
        }
        busy = false
    }

    fun sendMedia(uri: Uri, type: MsgType) {
        val rr = replyTo?.toReplyRef(); replyTo = null
        scope.launch {
            busy = true
            status = "Preparing ${type.name.lowercase()}…"
            val ts = System.currentTimeMillis()
            val ext = if (type == MsgType.PHOTO) photoExt(ctx.contentResolver.getType(uri).orEmpty()) else "mp4"
            val mediaPath = "$MSG_MEDIA_DIR/$ts.$ext"
            val local = mediaCacheFile(ctx, mediaPath)
            val copied = withContext(Dispatchers.IO) {
                try {
                    val stream = ctx.contentResolver.openInputStream(uri) ?: return@withContext false
                    local.parentFile?.mkdirs()
                    stream.use { i -> local.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                    true
                } catch (e: Exception) { false }
            }
            if (!copied) { local.delete(); status = "Couldn't read that file."; busy = false; return@launch }
            if (local.length() > MAX_MEDIA_BYTES) {
                val size = local.length(); local.delete()
                status = "That's ${humanBytes(size)} — the max is ${humanBytes(MAX_MEDIA_BYTES)}."
                busy = false; return@launch
            }
            sendMediaFile(local, mediaPath, type, ts, reply = rr)
        }
    }

    fun clearHistory() {
        val r = repo ?: return; val c = client ?: run { status = configError ?: "Not configured."; return }
        scope.launch {
            clearing = true
            status = "Clearing chat history…"
            try {
                withContext(Dispatchers.IO) {
                    try { c.deleteTree(MSG_DIR, r, "n: clear chat history") }
                    catch (e: Exception) { c.deleteAll(MSG_DIR, r, "n: clear chat history") }   // slow fallback
                }
                withContext(Dispatchers.IO) { File(ctx.cacheDir, "n/media").deleteRecursively() }
                messages = emptyList()
                known.clear()
                status = ""; DebugLog.add("chat history cleared")
            } catch (e: Exception) {
                status = "Couldn't clear history: ${errText(e)}"; DebugLog.add("clear failed: ${errText(e)}")
            }
            clearing = false
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(uri, MsgType.PHOTO) }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) sendMedia(uri, MsgType.VIDEO) }

    var hasMicPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var recordStartMs by remember { mutableStateOf(0L) }
    var isRecording by remember { mutableStateOf(false) }
    var recordedSec by remember { mutableStateOf(0) }

    fun startRecording() {
        if (busy || isRecording) return
        val dir = File(ctx.cacheDir, "n").apply { mkdirs() }
        val file = File(dir, "rec-${System.currentTimeMillis()}.m4a")
        val rec = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(file.absolutePath)
        }
        try {
            rec.prepare(); rec.start()
            recorder = rec; recordingFile = file; recordStartMs = System.currentTimeMillis()
            isRecording = true; recordedSec = 0; status = ""
        } catch (e: Exception) {
            status = "Couldn't start recording: ${e.message ?: "unknown error"}"
            try { rec.release() } catch (_: Exception) {}
        }
    }

    fun stopRecording(send: Boolean) {
        val rec = recorder ?: return
        val file = recordingFile
        val durationMs = System.currentTimeMillis() - recordStartMs
        isRecording = false; recorder = null; recordingFile = null
        try { rec.stop() } catch (_: Exception) {}
        rec.release()
        if (send && file != null && durationMs >= 500) {
            val ts = System.currentTimeMillis()
            val mediaPath = "$MSG_MEDIA_DIR/$ts.m4a"
            val dest = mediaCacheFile(ctx, mediaPath)
            dest.parentFile?.mkdirs()
            if (!file.renameTo(dest)) { file.copyTo(dest, overwrite = true); file.delete() }
            val rr = replyTo?.toReplyRef(); replyTo = null
            scope.launch { sendMediaFile(dest, mediaPath, MsgType.VOICE, ts, durationMs, rr) }
        } else {
            file?.delete()
            if (send) status = "Recording was too short."
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasMicPermission = granted
        if (granted) startRecording()
    }

    LaunchedEffect(isRecording) {
        while (isRecording) { delay(1000); recordedSec += 1 }
    }
    DisposableEffect(Unit) {
        onDispose { recorder?.let { try { it.stop() } catch (_: Exception) {}; it.release() } }
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${store.repo} @ ${store.branch} · as \"${store.name.ifBlank { "me" }}\"", color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        TextButton(onClick = { confirmClear = true }, enabled = !clearing && messages.isNotEmpty()) {
            Text(if (clearing) "[clearing…]" else "[clear]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(6.dp))

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear chat history?", fontFamily = TermFont) },
            text = { Text("This deletes every message and photo/video for both of you from ${store.repo} — not just on this phone. This can't be undone.", fontFamily = TermFont, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; clearHistory() }) {
                    Text("[delete all]", color = Warn, fontFamily = TermFont, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("[cancel]", color = Ink, fontFamily = TermFont) }
            }
        )
    }

    viewing?.let { (file, mediaPath) ->
        PhotoViewer(file, mediaPath, onClose = { viewing = null })
    }

    Box(Modifier.weight(1f).fillMaxWidth()) {
        if (messages.isEmpty()) {
            Text(status.ifEmpty { "No messages yet. Say hi below." }, color = Dim, fontFamily = TermFont, fontSize = 13.sp)
        } else {
            LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.path }) { m ->
                    MsgBubble(
                        m, mine = m.sender == store.name.ifBlank { "me" }, client = client, repo = repo,
                        onOpenPhoto = { f -> viewing = f to m.mediaPath },
                        onReply = { replyTo = m },
                        onJump = { path ->
                            val idx = messages.indexOfFirst { it.path == path }
                            if (idx >= 0) scope.launch { listState.animateScrollToItem(idx) }
                        }
                    )
                }
            }
        }
    }
    if (status.isNotEmpty() && messages.isNotEmpty()) {
        Text(status, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
    }

    replyTo?.let { t ->
        Row(
            Modifier.fillMaxWidth().padding(bottom = 4.dp).clip(RoundedCornerShape(6.dp)).background(Raised),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(3.dp).height(36.dp).background(Accent))
            Column(Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 4.dp)) {
                Text("replying to ${t.sender}", color = Accent, fontFamily = TermFont, fontSize = 10.sp)
                Text(previewOf(t).ifBlank { "…" }, color = Dim, fontFamily = TermFont, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            TextButton(onClick = { replyTo = null }) { Text("[x]", color = Dim, fontFamily = TermFont, fontSize = 13.sp) }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TextButton(onClick = { photoLauncher.launch(arrayOf("image/*")) }, enabled = !busy && !isRecording) { Text("[photo]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        TextButton(onClick = { videoLauncher.launch(arrayOf("video/*")) }, enabled = !busy && !isRecording) { Text("[video]", color = Accent, fontFamily = TermFont, fontSize = 13.sp) }
        TextButton(
            onClick = {
                if (isRecording) stopRecording(send = true)
                else if (hasMicPermission) startRecording()
                else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            },
            enabled = !busy || isRecording
        ) {
            Text(
                if (isRecording) "[● %d:%02d — stop]".format(recordedSec / 60, recordedSec % 60) else "[mic]",
                color = if (isRecording) Warn else Accent, fontFamily = TermFont, fontSize = 13.sp
            )
        }
        if (isRecording) {
            TextButton(onClick = { stopRecording(send = false) }) { Text("[cancel]", color = Dim, fontFamily = TermFont, fontSize = 13.sp) }
        }
        TextField(
            value = input, onValueChange = { input = it }, singleLine = true, enabled = !isRecording,
            placeholder = { Text("message…", color = Dim, fontFamily = TermFont) },
            textStyle = TextStyle(color = Ink, fontFamily = TermFont, fontSize = 14.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { sendText(input) }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Raised, unfocusedContainerColor = Raised,
                focusedIndicatorColor = Accent, unfocusedIndicatorColor = Line, cursorColor = Accent
            ),
            modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { sendText(input) }, enabled = input.isNotBlank()) {
            Text("[send]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun MsgBubble(
    m: ChatMsg, mine: Boolean, client: GitHubClient?, repo: RepoRef?,
    onOpenPhoto: (File) -> Unit, onReply: () -> Unit, onJump: (String) -> Unit
) {
    val bg = if (mine) Mine else Raised
    val align = if (mine) Alignment.End else Alignment.Start
    val threshold = with(LocalDensity.current) { 56.dp.toPx() }
    var dx by remember(m.path) { mutableStateOf(0f) }

    // Swipe a message sideways (either direction) to reply, like Messenger. Long-press works too.
    Box(Modifier.fillMaxWidth()) {
        if (abs(dx) > threshold / 3) {
            Text(
                "↩", color = if (abs(dx) >= threshold) Accent else Dim, fontFamily = TermFont, fontSize = 18.sp,
                modifier = Modifier.align(if (dx > 0) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = 6.dp)
            )
        }
        Column(
            Modifier.fillMaxWidth()
                .offset { IntOffset(dx.roundToInt(), 0) }
                .pointerInput(m.path) {
                    detectHorizontalDragGestures(
                        onDragEnd = { if (abs(dx) >= threshold) onReply(); dx = 0f },
                        onDragCancel = { dx = 0f }
                    ) { change, amount ->
                        change.consume()
                        dx = (dx + amount * 0.6f).coerceIn(-threshold * 1.5f, threshold * 1.5f)
                    }
                },
            horizontalAlignment = align
        ) {
            Text("${m.sender} · ${if (m.pending) "sending…" else timeLabel(m.ts)}", color = Dim, fontFamily = TermFont, fontSize = 10.sp)
            Box(
                Modifier.widthIn(max = 260.dp).clip(RoundedCornerShape(6.dp)).background(bg)
                    .pointerInput(m.path) { detectTapGestures(onLongPress = { onReply() }) }
                    .padding(10.dp)
            ) {
                Column {
                    m.reply?.let { rp -> ReplyQuote(rp, onJump) }
                    when (m.type) {
                        MsgType.TEXT -> Text(m.text, color = Ink, fontFamily = TermFont, fontSize = 14.sp)
                        else -> MediaBubble(m, client, repo, type = m.type, onOpenPhoto = onOpenPhoto)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(2.dp))
}

/** The small quoted block at the top of a reply. Tap it to jump to the original message. */
@Composable
private fun ReplyQuote(rp: ReplyRef, onJump: (String) -> Unit) {
    Row(
        Modifier.padding(bottom = 6.dp).height(IntrinsicSize.Min).clip(RoundedCornerShape(4.dp))
            .background(Color(0x22FFFFFF)).clickable { onJump(rp.path) }
    ) {
        Box(Modifier.width(2.dp).fillMaxHeight().background(Accent))
        Column(Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
            Text(rp.from, color = Accent, fontFamily = TermFont, fontSize = 10.sp)
            Text(rp.preview.ifBlank { "…" }, color = Dim, fontFamily = TermFont, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MediaBubble(m: ChatMsg, client: GitHubClient?, repo: RepoRef?, type: MsgType, onOpenPhoto: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var file by remember(m.path) { mutableStateOf<File?>(null) }
    var error by remember(m.path) { mutableStateOf("") }
    var loading by remember(m.path) { mutableStateOf(false) }

    /** Gets the media onto disk (instant if it's already cached or we sent it ourselves). */
    fun load(onDone: (File?) -> Unit) {
        file?.let { onDone(it); return }
        val c = client ?: return; val r = repo ?: return
        loading = true; error = ""
        scope.launch {
            val result = try {
                withContext(Dispatchers.IO) {
                    val dest = mediaCacheFile(ctx, m.mediaPath)
                    if (dest.exists() && dest.length() > 0) dest
                    else if (c.downloadFile(m.mediaPath, r, dest)) dest else null
                }
            } catch (e: Exception) { error = e.message ?: "couldn't load"; null }
            if (result == null && error.isEmpty()) error = "not found"
            loading = false; file = result; onDone(result)
        }
    }

    when (type) {
        MsgType.PHOTO -> {
            LaunchedEffect(m.path) { if (file == null && error.isEmpty()) load {} }
            val f = file
            var thumb by remember(f) { mutableStateOf<Bitmap?>(null) }
            var decodeFailed by remember(f) { mutableStateOf(false) }
            LaunchedEffect(f) {
                if (f != null) {
                    val b = withContext(Dispatchers.IO) { decodeSampled(f, 720) }
                    if (b == null) decodeFailed = true else thumb = b
                }
            }
            val bmp = thumb
            when {
                bmp != null && f != null -> Image(
                    bmp.asImageBitmap(), contentDescription = "photo (tap to view or save)",
                    modifier = Modifier.widthIn(max = 240.dp).clickable { onOpenPhoto(f) }
                )
                decodeFailed -> Text("[photo couldn't be decoded]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                error.isNotEmpty() -> Text("[photo failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 12.sp)
                loading || f != null -> Text("[loading photo…]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
                else -> Text("[photo]", color = Dim, fontFamily = TermFont, fontSize = 12.sp)
            }
        }
        MsgType.VIDEO -> {
            Column {
                Text("[ video ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = { load { f -> f?.let { openVideo(ctx, it) } } }, enabled = !loading) {
                    Text(if (loading) "[loading…]" else "[play]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
                }
                if (error.isNotEmpty()) Text("[video failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        MsgType.VOICE -> {
            var player by remember(m.path) { mutableStateOf<MediaPlayer?>(null) }
            var playing by remember(m.path) { mutableStateOf(false) }
            DisposableEffect(m.path) { onDispose { player?.release() } }

            fun playFile(f: File) {
                val mp = MediaPlayer().apply {
                    setDataSource(f.absolutePath)
                    setOnCompletionListener { playing = false }
                    prepare()
                    start()
                }
                player = mp; playing = true
            }

            val labelLen = if (m.durationMs > 0) {
                val s = (m.durationMs / 1000).toInt()
                " · %d:%02d".format(s / 60, s % 60)
            } else ""
            Column {
                Text("[ voice$labelLen ]", color = Ink, fontFamily = TermFont, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                TextButton(
                    onClick = {
                        if (playing) {
                            player?.stop(); player?.release(); player = null; playing = false
                        } else {
                            load { f -> f?.let { playFile(it) } }
                        }
                    },
                    enabled = !loading
                ) {
                    Text(
                        if (loading) "[loading…]" else if (playing) "[■ stop]" else "[▶ play]",
                        color = Accent, fontFamily = TermFont, fontSize = 13.sp
                    )
                }
                if (error.isNotEmpty()) Text("[voice failed: $error]", color = Warn, fontFamily = TermFont, fontSize = 11.sp)
            }
        }
        MsgType.TEXT -> {}
    }
}

/** Full-screen photo with a [save] button that puts the original file in Pictures/N. */
@Composable
private fun PhotoViewer(file: File, mediaPath: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember(file) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(file) { bmp = withContext(Dispatchers.IO) { decodeSampled(file, 2048) } }

    val name = "N-" + mediaPath.substringAfterLast('/')
    val mime = mimeForExt(name.substringAfterLast('.', "jpg"))

    fun save() {
        scope.launch {
            val ok = withContext(Dispatchers.IO) { saveImageToGallery(ctx, file, name, mime) }
            Toast.makeText(ctx, if (ok) "Saved to Pictures/N" else "Couldn't save photo", Toast.LENGTH_SHORT).show()
        }
    }
    // Android 9 and older need a storage permission to write to Pictures; 10+ doesn't.
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) save() else Toast.makeText(ctx, "Storage permission is needed to save photos on this Android version", Toast.LENGTH_LONG).show()
    }
    fun onSaveClick() {
        val needsPermission = Build.VERSION.SDK_INT < 29 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else save()
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), contentDescription = "photo", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                Text("[loading…]", color = Dim, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
            }
            Row(
                Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = { onSaveClick() }, enabled = b != null) {
                    Text("[save]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                TextButton(onClick = onClose) { Text("[close]", color = Ink, fontFamily = TermFont, fontSize = 15.sp) }
            }
        }
    }
}

// ---------------- helpers ----------------

private fun previewOf(m: ChatMsg): String = when (m.type) {
    MsgType.TEXT -> m.text.replace('\n', ' ').take(80)
    MsgType.PHOTO -> "[photo]"
    MsgType.VIDEO -> "[video]"
    MsgType.VOICE -> "[voice message]"
}
private fun ChatMsg.toReplyRef() = ReplyRef(path, sender, previewOf(this))
private fun JSONObject.putReply(r: ReplyRef) { put("reply_to", r.path); put("reply_from", r.from); put("reply_text", r.preview) }
private fun dirSize(f: File): Long = if (!f.exists()) 0L else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

private fun errText(e: Exception): String = if (e is GitHubApiException) e.body.take(80) else e.message ?: "unknown error"

/** Where a media file lives on this phone once downloaded (or before upload, for our own). */
private fun mediaCacheFile(ctx: Context, mediaPath: String): File =
    File(ctx.cacheDir, "n/media/" + mediaPath.replace('/', '_'))

private fun photoExt(mime: String): String = when (mime.lowercase()) {
    "image/png" -> "png"
    "image/webp" -> "webp"
    "image/gif" -> "gif"
    "image/heic" -> "heic"
    "image/heif" -> "heif"
    else -> "jpg"
}

private fun mimeForExt(ext: String): String = when (ext.lowercase()) {
    "png" -> "image/png"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "heic" -> "image/heic"
    "heif" -> "image/heif"
    else -> "image/jpeg"
}

/** Decodes at reduced size so a 50 MB photo doesn't blow up memory. Result is at least [maxDim] px where possible. */
private fun decodeSampled(file: File, maxDim: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) sample *= 2
    return BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}

/** Copies the original, full-quality file into the gallery (Pictures/N). */
private fun saveImageToGallery(ctx: Context, src: File, displayName: String, mime: String): Boolean = try {
    if (Build.VERSION.SDK_INT >= 29) {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/N")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) false else {
            val out = resolver.openOutputStream(uri)
            if (out == null) false else {
                out.use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } }
                values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            }
        }
    } else {
        @Suppress("DEPRECATION")
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "N").apply { mkdirs() }
        val dest = File(dir, displayName)
        src.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
        true
    }
} catch (e: Exception) { false }

private fun openVideo(ctx: Context, file: File) {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "video/mp4"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    ctx.startActivity(intent)
}

// ---- message parsing + on-disk cache of the chat (so it appears instantly on launch) ----

private fun parseMsg(path: String, o: JSONObject) = ChatMsg(
    path = path, sender = o.optString("from", "them"), ts = o.optLong("ts", 0L),
    type = MsgType.valueOf(o.optString("type", "TEXT").uppercase()),
    text = o.optString("text", ""), mediaPath = o.optString("media", ""),
    durationMs = o.optLong("duration", 0L),
    reply = o.optString("reply_to", "").takeIf { it.isNotEmpty() }
        ?.let { ReplyRef(it, o.optString("reply_from", ""), o.optString("reply_text", "")) }
)

/** null = couldn't fetch right now (retried on the next poll). Malformed files are marked known and skipped for good. */
private suspend fun fetchMessage(c: GitHubClient, r: RepoRef, path: String, known: MutableSet<String>): ChatMsg? {
    val body = try { c.readFile(path, r) } catch (e: Exception) { null } ?: return null
    return try { parseMsg(path, JSONObject(body)) } catch (e: Exception) { known += path; null }
}

private fun msgCacheFile(ctx: Context, repo: String, branch: String) =
    File(ctx.filesDir, "n_chat_${"$repo@$branch".hashCode()}.json")

private fun saveMsgCache(f: File, list: List<ChatMsg>) {
    try {
        val arr = JSONArray()
        for (m in list) if (!m.pending) arr.put(JSONObject().apply {
            put("path", m.path); put("from", m.sender); put("ts", m.ts); put("type", m.type.name)
            put("text", m.text); put("media", m.mediaPath); put("duration", m.durationMs)
            m.reply?.let { putReply(it) }
        })
        f.writeText(arr.toString())
    } catch (_: Exception) {}
}

private fun loadMsgCache(f: File): List<ChatMsg> = try {
    if (!f.exists()) emptyList() else {
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { val o = arr.getJSONObject(it); parseMsg(o.getString("path"), o) }.sortedBy { it.ts }
    }
} catch (e: Exception) { emptyList() }

private fun timeLabel(ts: Long): String {
    if (ts <= 0L) return ""
    val fmt = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
    return fmt.format(java.util.Date(ts))
}

private fun humanBytes(n: Long): String = when {
    n >= 1_000_000 -> "%.1f MB".format(n / 1_000_000.0)
    n >= 1_000 -> "%.0f KB".format(n / 1_000.0)
    else -> "$n B"
}
