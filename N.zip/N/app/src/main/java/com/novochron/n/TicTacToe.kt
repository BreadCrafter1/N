package com.novochron.n

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

// ---------------------------------------------------------------------------------------------
// Tic Tac Toe, two players. Same design as chess: one small file per game in the shared repo
// (Games/ttt/<id>.json) holding both names and the board; only the player whose turn it is
// writes, and both phones poll the folder (ETag'd, so idle polling is free).
// ---------------------------------------------------------------------------------------------

private const val TTT_DIR = "Games/ttt"
private val TTT_LINES = arrayOf(
    intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
    intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
    intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
)

private data class TttGame(
    val id: String,
    val x: String,          // username playing X (moves first), "" = seat open
    val o: String,
    val board: String,      // 9 chars of 'X', 'O' or '.'
    val result: String,     // "" in progress, "x" / "o" won, "draw"
    val rev: Int,
    val created: Long
) {
    fun toJson(): String = JSONObject().apply {
        put("id", id); put("x", x); put("o", o); put("board", board)
        put("result", result); put("rev", rev); put("created", created)
    }.toString(2)

    val marks: Int get() = board.count { it != '.' }
    val xToMove: Boolean get() = marks % 2 == 0
    fun sideOf(user: String): Char? = if (user == x) 'X' else if (user == o) 'O' else null
}

private fun parseTtt(text: String): TttGame? = try {
    val j = JSONObject(text)
    val b = j.optString("board", ".........")
    TttGame(
        j.getString("id"), j.optString("x", ""), j.optString("o", ""),
        if (b.length == 9) b else ".........", j.optString("result", ""), j.optInt("rev", 0), j.optLong("created", 0L)
    )
} catch (_: Exception) { null }

/** The winning line (3 indices) if someone has three in a row, else null. */
private fun winLine(board: String): IntArray? {
    for (l in TTT_LINES) {
        val c = board[l[0]]
        if (c != '.' && board[l[1]] == c && board[l[2]] == c) return l
    }
    return null
}

private fun tttResultText(g: TttGame) = when (g.result) {
    "x" -> "${Profiles.display(g.x)} won (X)"
    "o" -> "${Profiles.display(g.o)} won (O)"
    else -> "draw"
}

@Composable
fun TicTacToeScreen(store: Store) {
    val me = store.name.ifBlank { "me" }
    val repo = remember(store.repo) { RepoRef.parse(store.repo) }
    val client = remember(store.token, store.branch) { if (store.token.isBlank()) null else GitHubClient(store.token, store.branch) }
    val scope = rememberCoroutineScope()
    val games = remember { mutableStateMapOf<String, TttGame>() }
    val shas = remember { HashMap<String, String>() }
    val inflight = remember { HashMap<String, Int>() }
    val writeLock = remember { Mutex() }
    var openId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    val openNow by rememberUpdatedState(openId)
    BackHandler(enabled = openId != null) { openId = null }

    LaunchedEffect(client, repo) {
        if (client == null || repo == null) { status = "no repo / token configured"; loaded = true; return@LaunchedEffect }
        while (true) {
            try {
                val files = client.listFiles(TTT_DIR, repo)
                    .filter { !it.isDir && it.path.endsWith(".json") }
                    .sortedBy { it.path }.takeLast(40)
                val present = HashSet<String>()
                for (f in files) {
                    val id = f.path.substringAfterLast('/').removeSuffix(".json")
                    present.add(id)
                    if (shas[id] == f.sha) continue
                    val d = client.readFile(f.path, repo)?.let { parseTtt(it) } ?: continue
                    val cur = games[id]
                    if (cur == null || d.rev >= cur.rev) games[id] = d
                    shas[id] = f.sha
                }
                for (id in games.keys.toList()) {
                    if (id !in present && (inflight[id] ?: 0) == 0) { games.remove(id); shas.remove(id) }
                }
                status = ""
            } catch (e: Exception) { status = "sync: ${e.message?.take(80)}" }
            loaded = true
            delay(if (openNow != null) 1500L else 4000L)
        }
    }

    fun save(id: String) {
        val c = client ?: return
        val r = repo ?: return
        inflight[id] = (inflight[id] ?: 0) + 1
        scope.launch {
            writeLock.withLock {
                var attempt = 0
                while (attempt < 3) {
                    try {
                        val g = games[id] ?: break
                        c.writeFile("$TTT_DIR/$id.json", g.toJson(), "n: tictactoe", r)
                        status = ""
                        break
                    } catch (e: Exception) {
                        attempt++
                        status = "couldn't save: ${e.message?.take(80)}"
                        delay(1500)
                    }
                }
            }
            val left = (inflight[id] ?: 1) - 1
            if (left <= 0) inflight.remove(id) else inflight[id] = left
        }
    }

    fun create(pref: String, xUser: String? = null, oUser: String? = null) {
        val iAmX = when (pref) { "x" -> true; "o" -> false; else -> kotlin.random.Random.nextBoolean() }
        val id = "${System.currentTimeMillis()}_${safeName(me)}"
        val g = if (xUser != null || oUser != null) TttGame(id, xUser ?: "", oUser ?: "", ".........", "", 1, System.currentTimeMillis())
        else TttGame(id, if (iAmX) me else "", if (iAmX) "" else me, ".........", "", 1, System.currentTimeMillis())
        games[id] = g
        openId = id
        save(id)
    }

    fun join(id: String) {
        val g = games[id] ?: return
        if (g.x == me || g.o == me) { openId = id; return }
        if (g.x.isBlank()) games[id] = g.copy(x = me, rev = g.rev + 1)
        else if (g.o.isBlank()) games[id] = g.copy(o = me, rev = g.rev + 1)
        else { openId = id; return }
        openId = id
        save(id)
    }

    fun play(id: String, cell: Int) {
        val g = games[id] ?: return
        val side = g.sideOf(me) ?: return
        if (g.result.isNotBlank() || g.x.isBlank() || g.o.isBlank()) return
        if ((side == 'X') != g.xToMove || g.board[cell] != '.') return
        val nb = g.board.substring(0, cell) + side + g.board.substring(cell + 1)
        val res = when {
            winLine(nb) != null -> side.lowercaseChar().toString()
            nb.none { it == '.' } -> "draw"
            else -> ""
        }
        games[id] = g.copy(board = nb, result = res, rev = g.rev + 1)
        save(id)
    }

    fun rematch(g: TttGame) {
        // Swap sides so the other person gets to start. The opponent finds it under "your games".
        create("", xUser = g.o, oUser = g.x)
    }

    fun delete(id: String) {
        val c = client ?: return
        val r = repo ?: return
        scope.launch {
            try {
                val f = c.listFiles(TTT_DIR, r).firstOrNull { it.path.substringAfterLast('/') == "$id.json" }
                if (f != null) c.deleteFile(f.path, f.sha, "n: tictactoe delete", r)
                games.remove(id); shas.remove(id)
                if (openId == id) openId = null
            } catch (e: Exception) { status = "couldn't delete: ${e.message?.take(80)}" }
        }
    }

    val open = openId?.let { games[it] }
    if (open == null) {
        TttLobby(games, me, loaded, status, onCreate = { create(it) }, onOpen = { openId = it }, onJoin = { join(it) })
    } else {
        TttBoard(open, me, status, onPlay = { play(open.id, it) }, onRematch = { rematch(open) }, onDelete = { delete(open.id) }, onBack = { openId = null })
    }
}

@Composable
private fun TttLobby(
    games: Map<String, TttGame>, me: String, loaded: Boolean, status: String,
    onCreate: (String) -> Unit, onOpen: (String) -> Unit, onJoin: (String) -> Unit
) {
    val all = games.values.sortedByDescending { it.id }
    val mine = { g: TttGame -> g.x == me || g.o == me }
    val active = all.filter { it.result.isBlank() && mine(it) }
    val openGames = all.filter { it.result.isBlank() && !mine(it) && (it.x.isBlank() || it.o.isBlank()) }
    val finished = all.filter { it.result.isNotBlank() && mine(it) }.take(10)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GTitle("start a game")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            GBtn("[play X]") { onCreate("x") }
            GBtn("[play O]") { onCreate("o") }
            GBtn("[random]") { onCreate("random") }
        }
        GHint("X always moves first. The other person can join from their own tic tac toe screen.")
        if (status.isNotEmpty()) { Spacer(Modifier.height(6.dp)); GHint(status, Warn) }

        GTitle("your games")
        if (!loaded) GHint("loading…")
        else if (active.isEmpty()) GHint("no games in progress")
        else active.forEach { g ->
            val iAmX = g.x == me
            val opp = if (iAmX) g.o else g.x
            val myTurn = opp.isNotBlank() && iAmX == g.xToMove
            val sub = if (opp.isBlank()) "you're ${if (iAmX) "X" else "O"} \u00B7 waiting for someone to join"
            else "you're ${if (iAmX) "X" else "O"} \u00B7 ${if (myTurn) "your turn" else "their turn"}"
            LobbyRow(if (opp.isBlank()) "open game" else "vs ${Profiles.display(opp)}", sub, "[open]", highlight = myTurn) { onOpen(g.id) }
        }

        if (openGames.isNotEmpty()) {
            GTitle("open games")
            openGames.forEach { g ->
                val host = if (g.x.isNotBlank()) g.x else g.o
                LobbyRow("${Profiles.display(host)} is waiting", "you'd play ${if (g.x.isBlank()) "X" else "O"}", "[join]") { onJoin(g.id) }
            }
        }

        if (finished.isNotEmpty()) {
            GTitle("finished")
            finished.forEach { g ->
                val opp = if (g.x == me) g.o else g.x
                LobbyRow("vs ${Profiles.display(opp)}", tttResultText(g), "[view]") { onOpen(g.id) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun TttPlayer(user: String, mark: String, toMove: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (user.isNotBlank()) Avatar(user, 28.dp)
        else Box(Modifier.size(28.dp).clip(CircleShape).background(Raised), contentAlignment = Alignment.Center) {
            Text("?", color = Dim, fontFamily = TermFont, fontSize = 14.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(
                if (user.isBlank()) "waiting for opponent…" else Profiles.display(user),
                color = Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1
            )
            Text(mark + (if (toMove) " \u00B7 to move" else ""), color = if (toMove) Accent else Dim, fontFamily = TermFont, fontSize = 10.sp)
        }
    }
}

@Composable
private fun TttBoard(
    g: TttGame, me: String, status: String,
    onPlay: (Int) -> Unit, onRematch: () -> Unit, onDelete: () -> Unit, onBack: () -> Unit
) {
    val side = g.sideOf(me)
    val ready = g.x.isNotBlank() && g.o.isNotBlank()
    val over = g.result.isNotBlank()
    val myTurn = ready && !over && side != null && (side == 'X') == g.xToMove
    val line = winLine(g.board)?.toSet() ?: emptySet()
    var confirmDelete by remember(g.id) { mutableStateOf(false) }
    val opp = if (side == 'O') g.x else g.o

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth()) { GBtn("[\u2190 games]", Ink) { onBack() } }

        // Me (or, for a spectator, X) at the bottom; the other side on top.
        val bottomIsO = side == 'O'
        TttPlayer(if (bottomIsO) g.x else g.o, if (bottomIsO) "X" else "O", ready && !over && (if (bottomIsO) g.xToMove else !g.xToMove))

        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val cell = minOf(maxWidth / 3, 110.dp)
            Column(Modifier.size(cell * 3), verticalArrangement = Arrangement.spacedBy(0.dp)) {
                for (r in 0 until 3) {
                    Row {
                        for (c in 0 until 3) {
                            val i = r * 3 + c
                            val ch = g.board[i]
                            val win = i in line
                            Box(
                                Modifier.size(cell)
                                    .background(if (win) Accent.copy(alpha = 0.28f) else Raised)
                                    .border(1.dp, Line)
                                    .clickable(enabled = myTurn && ch == '.') { onPlay(i) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (ch != '.') Text(
                                    ch.toString(),
                                    color = if (ch == 'X') Accent else Ink,
                                    fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = (cell.value * 0.6f).sp
                                )
                            }
                        }
                    }
                }
            }
        }

        TttPlayer(if (bottomIsO) g.o else g.x, if (bottomIsO) "O" else "X", ready && !over && (if (bottomIsO) !g.xToMove else g.xToMove))

        val line1 = when {
            over -> tttResultText(g)
            !ready -> "waiting for an opponent to join\u2026"
            side == null -> "${Profiles.display(if (g.xToMove) g.x else g.o)} to move (you're watching)"
            myTurn -> "your move"
            else -> "waiting for ${Profiles.display(opp)}\u2026"
        }
        Text(line1, color = if (over || myTurn) Accent else Ink, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (status.isNotEmpty()) GHint(status, Warn)

        if (over && side != null) {
            Spacer(Modifier.height(6.dp))
            val iWon = (g.result == "x" && side == 'X') || (g.result == "o" && side == 'O')
            if (iWon) GHint("nice one \u2014 you won")
            GBtn("[rematch \u2014 swap sides]") { onRematch() }
        }

        if (over || (!ready && side != null)) {
            if (confirmDelete) {
                Text("delete this game for everyone?", color = Warn, fontFamily = TermFont, fontSize = 13.sp)
                Row { GBtn("[yes, delete]", Warn) { confirmDelete = false; onDelete() }; GBtn("[no]", Ink) { confirmDelete = false } }
            } else GBtn(if (over) "[delete game]" else "[cancel this game]", Ink) { confirmDelete = true }
        }
        Spacer(Modifier.height(16.dp))
    }
}
