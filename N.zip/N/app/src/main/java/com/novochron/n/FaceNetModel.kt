package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/**
 * Thin wrapper around the bundled FaceNet TFLite model: turns a cropped, upright face photo
 * into a 128-dimensional embedding — a point in "face space" where photos of the same person
 * land close together and different people land far apart. This is the same technique real
 * on-device face-unlock features use, and it's what makes this a face *recognition* system
 * rather than the old shape-matching approximation.
 *
 * The model file (facenet.tflite, ~23 MB) isn't committed to the repo — it's downloaded at
 * build time straight into assets/ (see the downloadFaceNetModel task in app/build.gradle.kts).
 */
object FaceNetModel {

    private const val MODEL_ASSET = "facenet.tflite"
    const val INPUT_SIZE = 160
    const val EMBEDDING_DIM = 128

    private var interpreter: Interpreter? = null

    /** Cropped face bitmap of any size in, in an L2-normalized 128-d embedding out. */
    @Synchronized
    fun embed(ctx: Context, faceBitmap: Bitmap): FloatArray {
        val model = interpreter ?: Interpreter(
            loadModelFile(ctx),
            Interpreter.Options().apply { setNumThreads(4) }
        ).also { interpreter = it }

        val input = toInputBuffer(faceBitmap)
        val output = Array(1) { FloatArray(EMBEDDING_DIM) }
        model.run(input, output)
        return l2Normalize(output[0])
    }

    /** Resizes to the model's expected 160x160 and maps RGB bytes to floats in [-1, 1]. */
    private fun toInputBuffer(bitmap: Bitmap): ByteBuffer {
        val scaled =
            if (bitmap.width == INPUT_SIZE && bitmap.height == INPUT_SIZE) bitmap
            else Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)

        val buffer = ByteBuffer.allocateDirect(4 * INPUT_SIZE * INPUT_SIZE * 3)
            .order(ByteOrder.nativeOrder())
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        scaled.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        for (p in pixels) {
            buffer.putFloat((((p shr 16) and 0xFF) - 127.5f) / 127.5f) // R
            buffer.putFloat((((p shr 8) and 0xFF) - 127.5f) / 127.5f)  // G
            buffer.putFloat(((p and 0xFF) - 127.5f) / 127.5f)          // B
        }
        buffer.rewind()
        return buffer
    }

    // Normalizing to unit length up front means comparing two embeddings later is just a dot
    // product (see FaceLock.cosineDistance) instead of a full cosine-similarity computation.
    private fun l2Normalize(v: FloatArray): FloatArray {
        var sumSq = 0f
        for (x in v) sumSq += x * x
        val norm = sqrt(sumSq).coerceAtLeast(1e-10f)
        return FloatArray(v.size) { v[it] / norm }
    }

    private fun loadModelFile(ctx: Context): ByteBuffer {
        val afd = ctx.assets.openFd(MODEL_ASSET)
        FileInputStream(afd.fileDescriptor).use { input ->
            return input.channel.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength)
        }
    }
}
