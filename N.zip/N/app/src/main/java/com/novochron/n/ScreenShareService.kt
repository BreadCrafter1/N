package com.novochron.n

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Holds a foreground-service "slot" of type mediaProjection while a screenshare is active.
 * Starting on Android 14, the OS refuses to start screen capture unless a foreground service of
 * this type is already running, so CallManager starts this right before creating the WebRTC
 * screen capturer and stops it again as soon as the share ends. The actual capturing happens in
 * CallManager in the same process — this service does no work of its own, it just satisfies the
 * OS requirement and shows the (mandatory, can't-be-hidden) "screen is being shared" notification.
 */
class ScreenShareService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "n_screenshare"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(channelId, "Screen sharing", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("N")
            .setContentText("Your screen is being shared in the call")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            @Suppress("DEPRECATION")
            startForeground(1, notification)
        }
        return START_NOT_STICKY
    }
}
