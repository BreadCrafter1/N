package com.novochron.n

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/**
 * Foreground-service "slot" kept alive for the whole duration of a call.
 *
 * Without this, the app is just a plain background process once you leave it (Home button,
 * switching apps): Android mutes microphone/camera input for backgrounded apps starting on
 * Android 9, and can freeze or kill the process entirely a short while later since it holds no
 * foreground service — either way the call dies even though nothing in the call logic itself
 * failed. Running this service for the duration of the call keeps the process at foreground
 * priority and keeps mic/camera access alive, so a call started here survives you leaving the app,
 * the same way it would in a phone or WhatsApp call. CallManager starts this right before opening
 * the mic (in startCall/accept) and stops it in endLocally() -- it does no work of its own beyond
 * satisfying that OS requirement and showing the (mandatory) "call in progress" notification.
 *
 * Also re-started with sharingScreen=true/false when a mid-call screenshare starts/stops, so the
 * type below picks up FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION for as long as sharing is active -
 * otherwise an audio-only call's screenshare is the first video-ish work in that call with nothing
 * marking it as important, and OEM battery managers can starve its encode pipeline even though the
 * Activity is visible.
 */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val video = intent?.getBooleanExtra("video", false) == true
        val sharingScreen = intent?.getBooleanExtra("sharingScreen", false) == true
        val channelId = "n_call"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(
                NotificationChannel(channelId, "Calls", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Constellation")
            .setContentText(if (video) "Video call in progress" else "Call in progress")
            .setSmallIcon(android.R.drawable.presence_audio_online)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
        // Android throws a SecurityException (which used to take the whole app down) if a service is
        // started as "microphone"/"camera" without that permission actually granted, so only claim
        // the types we really have, and never let a refusal crash the app: the call just runs
        // without the keep-alive notification.
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                var type = 0
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (video && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (sharingScreen) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                if (type == 0) { stopSelf(); return START_NOT_STICKY }
                startForeground(2, notification, type)
            } else {
                @Suppress("DEPRECATION")
                startForeground(2, notification)
            }
        } catch (e: Exception) {
            DebugLog.add("call service: couldn't go foreground: ${e.javaClass.simpleName}")
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
