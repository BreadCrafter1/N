import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.novochron.n"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novochron.n"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Fixed debug signing so every CI build installs over the last one on your phone.
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }

    // The FaceNet model has to be mmap'd straight out of assets/ (see FaceNetModel.kt) — that
    // only works if it's stored uncompressed in the APK.
    androidResources { noCompress += "tflite" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Bundled (offline, no Play Services needed) face detector, used only to find and crop the
    // face rectangle before it's handed to FaceNet — see FaceLock.kt.
    implementation("com.google.mlkit:face-detection:16.1.7")

    // Runs the bundled FaceNet .tflite model (see downloadFaceNetModel below) to turn a cropped
    // face into a 128-dimensional embedding for real face *recognition*, not just shape matching.
    implementation("org.tensorflow:tensorflow-lite:2.16.1")

    // Live front-camera preview + frame analysis, so the face-lock scan is hands-free
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
}

// --------------------------------------------------------------------------------------------
// FaceNet model download
//
// facenet.tflite (~23 MB) isn't committed to this repo — a binary that size doesn't belong in
// git history, and CI would have to clone it on every run regardless. Instead we pull it down
// once, at build time, straight into src/main/assets, from shubham0204/FaceRecognition_With_-
// FaceNet_Android (Apache-2.0) — a long-standing, widely-reused, single-file source for this
// exact model (see e.g. PSMRI/HWC-Mobile-App and Bertverbeek4PS/FaceId, which source it the
// same way). No Gradle plugin needed, just java.net.URL — but it has to run and finish *before*
// the asset-merge task looks for it, hence wiring it into every merge*Assets task below rather
// than relying on task-graph ordering alone.
val faceNetModelUrl =
    "https://raw.githubusercontent.com/shubham0204/FaceRecognition_With_FaceNet_Android/master/app/src/main/assets/facenet.tflite"

val downloadFaceNetModel by tasks.registering {
    val modelFile = file("src/main/assets/facenet.tflite")
    outputs.file(modelFile)
    doLast {
        if (!modelFile.exists() || modelFile.length() == 0L) {
            modelFile.parentFile.mkdirs()
            println("Downloading FaceNet model from $faceNetModelUrl")
            URL(faceNetModelUrl).openStream().use { input ->
                modelFile.outputStream().use { output -> input.copyTo(output) }
            }
            check(modelFile.length() > 1_000_000) {
                "Downloaded facenet.tflite looks too small (${modelFile.length()} bytes) — the download likely failed."
            }
        }
    }
}

tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }
    .configureEach { dependsOn(downloadFaceNetModel) }
