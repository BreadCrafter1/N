package com.novochron.n

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Gate shown before the chat/repo is reachable: the app must see a face matching the
 * hardcoded reference photo(s) in FaceLock before it calls onUnlocked().
 */
@Composable
fun FaceLockScreen(onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var status by remember { mutableStateOf("Look at the camera to unlock.") }
    var busy by remember { mutableStateOf(false) }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }

    fun runVerification(uri: Uri) {
        scope.launch {
            busy = true
            status = "Checking…"
            val result = withContext(Dispatchers.Default) { FaceLock.verify(ctx, uri) }
            busy = false
            when (result) {
                is FaceLock.Result.Match -> onUnlocked()
                is FaceLock.Result.NoMatch -> status = "Face not recognized. Try again."
                is FaceLock.Result.NoFaceFound -> status = "No face found — center your face in the frame and try again."
                is FaceLock.Result.Error -> status = "Couldn't check that photo: ${result.message}"
            }
        }
    }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val uri = pendingUri
        if (success && uri != null) runVerification(uri) else status = "Capture cancelled."
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val uri = FaceLock.newCaptureUri(ctx)
            pendingUri = uri
            takePicture.launch(uri)
        } else {
            status = "Camera permission is required to unlock."
        }
    }

    fun startScan() {
        status = "Opening camera…"
        cameraPermission.launch(android.Manifest.permission.CAMERA)
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("N", color = Accent, fontFamily = TermFont, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 28.sp)
        Spacer(Modifier.height(6.dp))
        Text("locked", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
        Spacer(Modifier.height(28.dp))
        Text(status, color = Ink, fontFamily = TermFont, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp))
        Spacer(Modifier.height(20.dp))
        TextButton(onClick = { if (!busy) startScan() }, enabled = !busy) {
            Text(if (busy) "[checking…]" else "[scan face]", color = Accent, fontFamily = TermFont, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "On-device only — nothing leaves your phone for this check.",
            color = Dim, fontFamily = TermFont, fontSize = 10.sp
        )
    }
}
