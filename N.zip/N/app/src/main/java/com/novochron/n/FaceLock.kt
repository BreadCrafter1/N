package com.novochron.n

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * A lightweight, fully on-device "does this match a hardcoded face?" gate — now backed by real
 * face *recognition* rather than shape matching.
 *
 * How it works: ML Kit's face detector finds the face rectangle in a frame (that's all it's
 * used for here — no landmarks, no mesh). That rectangle is cropped out and fed to a bundled
 * FaceNet model (see FaceNetModel.kt), which turns the cropped face into a 128-dimensional
 * embedding: a point in "face space" where photos of the same person land close together and
 * different people land far apart, regardless of angle, lighting, or expression. The live
 * frame's embedding is compared against the same thing computed from the hardcoded reference
 * photo(s) bundled in the app, using cosine distance.
 *
 * MATCH_THRESHOLD is the one knob that trades strictness for tolerance — FaceLockScreen shows
 * the live distance number on screen so you can calibrate it against your own face and a few
 * other people's.
 *
 * To add or change whose face unlocks the app: drop a clear, front-facing, well-lit photo into
 * res/drawable (e.g. ref_face_2.jpg) and add its resource id to REFERENCE_DRAWABLES.
 */
object FaceLock {

    // Hardcoded reference face(s). Add more R.drawable.xxx ids here to allow more than one face.
    private val REFERENCE_DRAWABLES = listOf(R.drawable.ref_face_1)

    // Lower = stricter match. This is 1 - cosine similarity between two L2-normalized FaceNet
    // embeddings (0 = identical direction, 2 = opposite). Start here, then watch the on-screen
    // distance number: see the comment in FaceLockScreen for how to tune this to your specific
    // face/lighting/camera.
    private const val MATCH_THRESHOLD = 0.35f

    // A face has to fill at least this fraction of the frame's shorter side to count — keeps
    // a face that just wanders into the background of the shot from being evaluated at all.
    private const val MIN_FACE_FRACTION = 0.15f

    private var cachedReferenceEmbeddings: List<FloatArray>? = null

    private val detector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
    }

    sealed class Result {
        data class Match(val distance: Float) : Result()
        data class NoMatch(val distance: Float) : Result()
        object NoFaceFound : Result()
        data class Error(val message: String) : Result()
    }

    /** Warms up the reference embeddings so the first live frame doesn't stall on decoding them. */
    suspend fun preload(ctx: Context) {
        referenceEmbeddings(ctx)
    }

    /**
     * Runs face detection + FaceNet on a single camera frame and compares it against the
     * hardcoded reference(s). [frame] must already be upright — see FaceLockScreen for how a
     * raw camera frame gets rotated into this before it's passed in.
     */
    suspend fun verifyFrame(ctx: Context, frame: Bitmap): Result {
        return try {
            val faces = detectFaces(InputImage.fromBitmap(frame, 0))
            val face = faces
                .filter { largestSideFraction(it.boundingBox, frame.width, frame.height) >= MIN_FACE_FRACTION }
                .maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
                ?: return Result.NoFaceFound

            val crop = cropFace(frame, face.boundingBox) ?: return Result.NoFaceFound
            val liveEmbedding = FaceNetModel.embed(ctx, crop)

            val references = referenceEmbeddings(ctx)
            if (references.isEmpty()) return Result.Error("No reference face is bundled in the app.")

            val bestDistance = references.minOf { cosineDistance(it, liveEmbedding) }
            if (bestDistance <= MATCH_THRESHOLD) Result.Match(bestDistance) else Result.NoMatch(bestDistance)
        } catch (e: Exception) {
            Result.Error(e.message ?: "face check failed")
        }
    }

    private fun largestSideFraction(box: Rect, imageWidth: Int, imageHeight: Int): Float {
        val shorterSide = minOf(imageWidth, imageHeight).coerceAtLeast(1)
        return box.width().toFloat() / shorterSide
    }

    private fun cropFace(bitmap: Bitmap, box: Rect): Bitmap? {
        val left = box.left.coerceIn(0, bitmap.width)
        val top = box.top.coerceIn(0, bitmap.height)
        val right = box.right.coerceIn(0, bitmap.width)
        val bottom = box.bottom.coerceIn(0, bitmap.height)
        val w = right - left
        val h = bottom - top
        if (w <= 0 || h <= 0) return null
        return Bitmap.createBitmap(bitmap, left, top, w, h)
    }

    private suspend fun referenceEmbeddings(ctx: Context): List<FloatArray> {
        cachedReferenceEmbeddings?.let { return it }
        val embeddings = REFERENCE_DRAWABLES.mapNotNull { resId ->
            val bmp = BitmapFactory.decodeResource(ctx.resources, resId) ?: return@mapNotNull null
            val faces = detectFaces(InputImage.fromBitmap(bmp, 0))
            val face = faces.maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height() }
                ?: return@mapNotNull null
            val crop = cropFace(bmp, face.boundingBox) ?: return@mapNotNull null
            FaceNetModel.embed(ctx, crop)
        }
        cachedReferenceEmbeddings = embeddings
        return embeddings
    }

    private suspend fun detectFaces(image: InputImage): List<Face> =
        suspendCancellableCoroutine { cont ->
            detector.process(image)
                .addOnSuccessListener { faces -> if (cont.isActive) cont.resume(faces) }
                .addOnFailureListener { if (cont.isActive) cont.resume(emptyList()) }
        }

    /** 1 - cosine similarity. Cheap here because both vectors are already L2-normalized. */
    private fun cosineDistance(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 2f
        var dot = 0f
        for (i in a.indices) dot += a[i] * b[i]
        return 1f - dot
    }
}
