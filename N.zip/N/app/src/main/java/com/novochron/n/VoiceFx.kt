package com.novochron.n

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Voice changer.
//
// A recorded voice message (AAC in an .m4a) is decoded to raw samples, run through one of the
// effects below on the phone, and written out as a 16-bit mono WAV. The other person just gets a
// normal voice message that already sounds different — nothing special is needed on their side.
// "original" skips all of this and sends the untouched .m4a.
// ---------------------------------------------------------------------------------------------

enum class VoiceEffect(val label: String) {
    NONE("original"), DEEP("deep"), CHIPMUNK("chipmunk"), ROBOT("robot"), ECHO("echo"), RADIO("radio")
}

class Pcm(val samples: ShortArray, val rate: Int)

object VoiceFx {

    /** Decodes any audio file Android can read into mono 16-bit samples. Null if it can't. */
    fun decode(file: File): Pcm? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(file.absolutePath)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0); c.start()

            val info = MediaCodec.BufferInfo()
            val bytes = ByteArrayOutputStream()
            var inDone = false; var outDone = false
            val deadline = System.currentTimeMillis() + 30_000
            while (!outDone && System.currentTimeMillis() < deadline) {
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) { c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)!!
                    val chunk = ByteArray(info.size)
                    ob.position(info.offset); ob.get(chunk)
                    bytes.write(chunk)
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE); channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            val raw = bytes.toByteArray()
            val total = raw.size / 2
            val frames = total / max(1, channels)
            if (frames <= 0) return null
            val out = ShortArray(frames)
            for (i in 0 until frames) {
                var sum = 0
                for (ch in 0 until channels) {
                    val idx = (i * channels + ch) * 2
                    sum += ((raw[idx + 1].toInt() shl 8) or (raw[idx].toInt() and 0xFF)).toShort().toInt()
                }
                out[i] = (sum / channels).toShort()
            }
            return Pcm(out, rate)
        } catch (e: Exception) {
            DebugLog.add("voice decode failed: ${e.message?.take(60)}")
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }

    /** Plays the samples back faster (ratio > 1: higher and shorter) or slower (< 1: lower and longer). */
    private fun resample(src: ShortArray, ratio: Double): FloatArray {
        val n = (src.size / ratio).toInt()
        val out = FloatArray(n)
        for (i in 0 until n) {
            val pos = i * ratio
            val i0 = pos.toInt()
            val frac = (pos - i0).toFloat()
            val a = src[min(i0, src.size - 1)].toFloat()
            val b = src[min(i0 + 1, src.size - 1)].toFloat()
            out[i] = a * (1 - frac) + b * frac
        }
        return out
    }

    private fun toFloat(src: ShortArray) = FloatArray(src.size) { src[it].toFloat() }

    fun apply(p: Pcm, e: VoiceEffect): Pcm {
        val rate = p.rate
        val f: FloatArray = when (e) {
            VoiceEffect.NONE -> return p
            VoiceEffect.DEEP -> resample(p.samples, 0.78)
            VoiceEffect.CHIPMUNK -> resample(p.samples, 1.55)
            VoiceEffect.ROBOT -> {
                val x = toFloat(p.samples)
                FloatArray(x.size) { i -> x[i] * (0.25f + 0.95f * sin(2.0 * PI * 55.0 * i / rate).toFloat()) }
            }
            VoiceEffect.ECHO -> {
                val x = toFloat(p.samples)
                val d = (rate * 0.28).toInt()
                val y = FloatArray(x.size + rate + rate / 2)
                for (i in y.indices) {
                    val dry = if (i < x.size) x[i] else 0f
                    y[i] = dry + if (i >= d) 0.45f * y[i - d] else 0f
                }
                y
            }
            VoiceEffect.RADIO -> {
                val x = toFloat(p.samples)
                val hp = 1f - (2f * PI.toFloat() * 450f / rate)      // one-pole high-pass, ~450 Hz
                val lpA = (2f * PI.toFloat() * 3200f / rate).coerceAtMost(1f) // one-pole low-pass, ~3.2 kHz
                var prevX = 0f; var prevHp = 0f; var lp = 0f
                FloatArray(x.size) { i ->
                    val h = hp * (prevHp + x[i] - prevX)
                    prevX = x[i]; prevHp = h
                    lp += lpA * (h - lp)
                    (lp * 2.4f).coerceIn(-14000f, 14000f)       // gentle clipping = that crunchy radio grit
                }
            }
        }
        // Normalise so every effect ends up at a similar, non-clipping volume.
        var peak = 1f
        for (v in f) peak = max(peak, abs(v))
        val gain = 29000f / peak
        return Pcm(ShortArray(f.size) { (f[it] * gain).toInt().coerceIn(-32768, 32767).toShort() }, rate)
    }

    fun writeWav(p: Pcm, out: File) {
        out.parentFile?.mkdirs()
        val dataLen = p.samples.size * 2
        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(0)
            fun le32(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
            fun le16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())
            raf.write("RIFF".toByteArray()); raf.write(le32(36 + dataLen)); raf.write("WAVE".toByteArray())
            raf.write("fmt ".toByteArray()); raf.write(le32(16)); raf.write(le16(1)); raf.write(le16(1))
            raf.write(le32(p.rate)); raf.write(le32(p.rate * 2)); raf.write(le16(2)); raf.write(le16(16))
            raf.write("data".toByteArray()); raf.write(le32(dataLen))
            val buf = ByteArray(dataLen)
            for (i in p.samples.indices) {
                val s = p.samples[i].toInt()
                buf[i * 2] = s.toByte(); buf[i * 2 + 1] = (s shr 8).toByte()
            }
            raf.write(buf)
        }
    }

    fun durationMs(p: Pcm): Long = p.samples.size * 1000L / p.rate
}

/**
 * Shown after you stop recording: pick a voice, preview it, then send (or discard).
 * [onSend] gets the final file, its extension ("m4a" untouched, or "wav" if an effect was applied)
 * and its duration.
 */
@Composable
fun VoiceBar(
    src: File, durationMs: Long,
    onDiscard: () -> Unit,
    onSend: (file: File, ext: String, durationMs: Long) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var effect by remember(src) { mutableStateOf(VoiceEffect.NONE) }
    var busy by remember(src) { mutableStateOf(false) }
    var playing by remember(src) { mutableStateOf(false) }
    var error by remember(src) { mutableStateOf("") }
    var player by remember(src) { mutableStateOf<MediaPlayer?>(null) }
    var pcm by remember(src) { mutableStateOf<Pcm?>(null) }
    DisposableEffect(src) { onDispose { try { player?.release() } catch (_: Exception) {} } }

    fun stopPlayback() { try { player?.stop() } catch (_: Exception) {}; try { player?.release() } catch (_: Exception) {}; player = null; playing = false }

    /** Renders the chosen effect to [dest] (decoding the recording once and reusing it). Returns its duration, or -1. */
    suspend fun render(dest: File): Long = withContext(Dispatchers.IO) {
        val base = pcm ?: VoiceFx.decode(src)?.also { pcm = it } ?: return@withContext -1L
        val out = VoiceFx.apply(base, effect)
        VoiceFx.writeWav(out, dest)
        VoiceFx.durationMs(out)
    }

    fun playFile(f: File) {
        val mp = MediaPlayer().apply {
            setDataSource(f.absolutePath)
            setOnCompletionListener { playing = false }
            prepare(); start()
        }
        player = mp; playing = true
    }

    fun preview() {
        if (playing) { stopPlayback(); return }
        error = ""
        scope.launch {
            busy = true
            try {
                if (effect == VoiceEffect.NONE) playFile(src)
                else {
                    val tmp = File(ctx.cacheDir, "n/voice-preview.wav")
                    if (render(tmp) < 0) error = "Couldn't process that recording." else playFile(tmp)
                }
            } catch (e: Exception) { error = "Couldn't play preview." }
            busy = false
        }
    }

    Column(Modifier.fillMaxWidth()) {
        val s = (durationMs / 1000).toInt()
        Text("voice message · %d:%02d — pick a voice".format(s / 60, s % 60), color = Dim, fontFamily = TermFont, fontSize = 11.sp)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            VoiceEffect.values().forEach { e ->
                TextButton(onClick = { stopPlayback(); effect = e }, enabled = !busy) {
                    Text(
                        if (e == effect) "[● ${e.label}]" else "[${e.label}]",
                        color = if (e == effect) Accent else Ink, fontFamily = TermFont,
                        fontWeight = if (e == effect) FontWeight.Bold else FontWeight.Normal, fontSize = 13.sp
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { preview() }, enabled = !busy) {
                Text(if (busy) "[working…]" else if (playing) "[■ stop]" else "[▶ preview]", color = Accent, fontFamily = TermFont, fontSize = 13.sp)
            }
            TextButton(
                enabled = !busy,
                onClick = {
                    stopPlayback(); error = ""
                    if (effect == VoiceEffect.NONE) {
                        onSend(src, "m4a", durationMs)
                    } else scope.launch {
                        busy = true
                        val out = File(ctx.cacheDir, "n/voice-out-${System.currentTimeMillis()}.wav")
                        val ms = try { render(out) } catch (e: Exception) { -1L }
                        busy = false
                        if (ms < 0) error = "Couldn't process that recording." else onSend(out, "wav", ms)
                    }
                }
            ) { Text("[send]", color = Accent, fontFamily = TermFont, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            TextButton(onClick = { stopPlayback(); onDiscard() }, enabled = !busy) {
                Text("[discard]", color = Dim, fontFamily = TermFont, fontSize = 13.sp)
            }
        }
        if (error.isNotEmpty()) Text(error, color = Warn, fontFamily = TermFont, fontSize = 11.sp)
    }
}
