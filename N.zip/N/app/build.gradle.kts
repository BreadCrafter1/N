import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Reads the token from local.properties (git-ignored, for local builds) with a fallback to
// an environment variable named N_GH_TOKEN (for CI, set as a GitHub Actions secret). Either
// way, the token never has to be written into a source file that gets committed.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val ghToken: String = localProps.getProperty("githubToken") ?: System.getenv("N_GH_TOKEN") ?: ""

android {
    namespace = "com.novochron.n"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novochron.n"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        buildConfigField("String", "GITHUB_TOKEN", "\"$ghToken\"")
    }

    // Fixed debug signing so every CI build installs over the last one on your phone.
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
