package com.novochron.n

import org.webrtc.JavaI420Buffer
import org.webrtc.VideoFrame
import org.webrtc.VideoProcessor
import org.webrtc.VideoSink
import java.nio.ByteBuffer

// ---------------------------------------------------------------------------------------------
// Video call filters.
//
// Every camera frame passes through FilterProcessor before it is encoded, so the other person
// sees the filter and so does your own preview. Filters work directly on the frame's YUV planes
// (Y = brightness, U/V = colour), which makes colour filters very cheap. With "none" selected the
// frame is passed straight through without being touched.
// ---------------------------------------------------------------------------------------------

enum class VideoFx(val label: String) {
    NONE("none"), MONO("mono"), SEPIA("sepia"), WARM("warm"), COOL("cool"),
    NEGATIVE("negative"), VIGNETTE("vignette"), PIXEL("pixel");

    fun next(): VideoFx = values()[(ordinal + 1) % values().size]
}

class FilterProcessor : VideoProcessor {
    @Volatile var mode: VideoFx = VideoFx.NONE
    @Volatile private var sink: VideoSink? = null

    override fun setSink(s: VideoSink?) { sink = s }
    override fun onCapturerStarted(success: Boolean) {}
    override fun onCapturerStopped() {}

    override fun onFrameCaptured(frame: VideoFrame) {
        val s = sink ?: return
        val m = mode
        if (m == VideoFx.NONE) { s.onFrame(frame); return }
        val i420 = try { frame.buffer.toI420() } catch (_: Exception) { null }
        if (i420 == null) { s.onFrame(frame); return }
        val out = try { VideoFilters.apply(i420, m) } catch (_: Exception) { null }
        i420.release()
        if (out == null) { s.onFrame(frame); return }
        val filtered = VideoFrame(out, frame.rotation, frame.timestampNs)
        s.onFrame(filtered)
        filtered.release()
    }
}

private object VideoFilters {
    private fun clamp(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    private fun read(buf: ByteBuffer, stride: Int, w: Int, h: Int): ByteArray {
        val out = ByteArray(w * h)
        val b = buf.duplicate()
        for (r in 0 until h) { b.position(r * stride); b.get(out, r * w, w) }
        return out
    }

    private fun write(buf: ByteBuffer, stride: Int, w: Int, h: Int, data: ByteArray) {
        val b = buf.duplicate()
        for (r in 0 until h) { b.position(r * stride); b.put(data, r * w, w) }
    }

    fun apply(src: VideoFrame.I420Buffer, mode: VideoFx): JavaI420Buffer {
        val w = src.width; val h = src.height
        val cw = (w + 1) / 2; val ch = (h + 1) / 2
        val y = read(src.dataY, src.strideY, w, h)
        val u = read(src.dataU, src.strideU, cw, ch)
        val v = read(src.dataV, src.strideV, cw, ch)

        when (mode) {
            VideoFx.NONE -> {}
            VideoFx.MONO -> { u.fill(128.toByte()); v.fill(128.toByte()) }
            VideoFx.SEPIA -> { u.fill(108.toByte()); v.fill(150.toByte()) }
            VideoFx.WARM -> for (i in u.indices) {
                u[i] = clamp((u[i].toInt() and 0xFF) - 10).toByte()
                v[i] = clamp((v[i].toInt() and 0xFF) + 12).toByte()
            }
            VideoFx.COOL -> for (i in u.indices) {
                u[i] = clamp((u[i].toInt() and 0xFF) + 12).toByte()
                v[i] = clamp((v[i].toInt() and 0xFF) - 10).toByte()
            }
            VideoFx.NEGATIVE -> {
                for (i in y.indices) y[i] = (255 - (y[i].toInt() and 0xFF)).toByte()
                for (i in u.indices) {
                    u[i] = clamp(256 - (u[i].toInt() and 0xFF)).toByte()
                    v[i] = clamp(256 - (v[i].toInt() and 0xFF)).toByte()
                }
            }
            VideoFx.VIGNETTE -> {
                val dx2 = FloatArray(w) { val d = (it - w / 2f) / (w / 2f); d * d }
                for (r in 0 until h) {
                    val dy = (r - h / 2f) / (h / 2f); val dy2 = dy * dy
                    val base = r * w
                    for (c in 0 until w) {
                        val d2 = (dx2[c] + dy2) / 2f
                        val f = (1f - 0.95f * d2 * d2 * 1.6f).coerceIn(0.08f, 1f)
                        y[base + c] = ((y[base + c].toInt() and 0xFF) * f).toInt().toByte()
                    }
                }
            }
            VideoFx.PIXEL -> {
                val b = 16
                for (r in 0 until h) {
                    val rr = r - r % b
                    for (c in 0 until w) y[r * w + c] = y[rr * w + (c - c % b)]
                }
                val cb = b / 2
                for (r in 0 until ch) {
                    val rr = r - r % cb
                    for (c in 0 until cw) {
                        u[r * cw + c] = u[rr * cw + (c - c % cb)]
                        v[r * cw + c] = v[rr * cw + (c - c % cb)]
                    }
                }
            }
        }

        val dst = JavaI420Buffer.allocate(w, h)
        write(dst.dataY, dst.strideY, w, h, y)
        write(dst.dataU, dst.strideU, cw, ch, u)
        write(dst.dataV, dst.strideV, cw, ch, v)
        return dst
    }
}
