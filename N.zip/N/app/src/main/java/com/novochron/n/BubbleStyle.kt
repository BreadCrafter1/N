package com.novochron.n

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------------------------
// Message bubble styles, TikTok-chat-theme style: the box around a message can have a signature
// colour, rounder corners, a faint tiled pattern of little emoji, and animal ears sitting on top
// (bunny / kitty / bear).
//
// Each person picks a style for THEIR sent messages in Settings. The choice is saved in their
// profile (Config/profiles/<user>.json), so it shows up on both phones.
// ---------------------------------------------------------------------------------------------

/** Ears that sit on top of a bubble. [heightDp] is how far they stick up above it. */
enum class Ears(val heightDp: Int) { NONE(0), BUNNY(24), CAT(14), BEAR(13) }

enum class BubbleStyle(
    val key: String,
    val label: String,
    val emoji: String,
    private val darkTint: Long,     // signature colour in dark mode (0 = follow the accent colour)
    private val lightTint: Long,    // ...and in light mode, a deeper shade so text stays readable
    val ears: Ears = Ears.NONE,
    val pattern: String = "",       // emoji tiled faintly across the bubble
    val radius: Int = 6,
    private val fixedFill: Long = 0,   // non-zero = always this exact bubble colour (ignores theme tint)
    private val fixedInk: Long = 0,    // ...with this text colour so it stays readable on it
) {
    CLASSIC("classic", "classic", "💬", 0, 0),
    BUNNY("bunny", "bunny", "🐰", 0xFFFF9CC8, 0xFFE0508F, Ears.BUNNY, "", 18, 0xFFFFFFFF, 0xFF1A1A1A),
    KITTY("kitty", "kitty", "🐱", 0xFFFFB066, 0xFFC26A12, Ears.CAT, "🐾", 18),
    BEAR("bear", "bear", "🐻", 0xFFD9A066, 0xFF8A5A2B, Ears.BEAR, "🍯", 18),
    HEARTS("hearts", "hearts", "💖", 0xFFFF6B8B, 0xFFC2185B, Ears.NONE, "💗", 18),
    STARS("stars", "stars", "✨", 0xFF8C7BFF, 0xFF4B3BC4, Ears.NONE, "⭐", 16),
    BLOSSOM("blossom", "blossom", "🌸", 0xFFFFB3A0, 0xFFC4553C, Ears.NONE, "🌸", 18),
    GHOST("ghost", "ghost", "👻", 0xFFB980FF, 0xFF6A2BC9, Ears.NONE, "👻", 18),
    FROG("frog", "frog", "🐸", 0xFF7BE07B, 0xFF2E8B3A, Ears.NONE, "🍃", 18);

    /** The style's main colour for the current light/dark mode. */
    fun tint(): Color = when {
        this == CLASSIC -> Accent
        ThemeState.dark -> Color(darkTint)
        else -> Color(lightTint)
    }

    /** True for styles with a fixed colour (the white bunny): they get a hairline outline so they show on a white page. */
    val solid: Boolean get() = fixedFill != 0L

    /** Text colour inside the bubble: the theme's letter colour, unless the style has its own fill that needs a fixed one. */
    fun ink(): Color = if (fixedInk != 0L) Color(fixedInk) else Ink

    /** Bubble fill. Mine is a stronger tint than theirs, like the classic look. Classic keeps the original colours. */
    fun fill(mine: Boolean): Color {
        if (this == CLASSIC) return if (mine) Mine else Raised
        if (fixedFill != 0L) return Color(fixedFill)
        val base = if (ThemeState.dark) Color(0xFF101010) else Color(0xFFF1F1F1)
        val amount = if (ThemeState.dark) (if (mine) 0.42f else 0.24f) else (if (mine) 0.30f else 0.16f)
        return lerp(base, tint(), amount).copy(alpha = if (ThemeState.hasImageBg) 0.82f else 1f)
    }

    companion object {
        fun fromKey(key: String): BubbleStyle = values().firstOrNull { it.key == key } ?: CLASSIC
    }
}

private val EarInner = Color(0xFFFF8FB8).copy(alpha = 0.9f)
private val Outline = Color(0x26000000)

/**
 * First half of a styled bubble: reserves room above it and draws the ears there. Put it FIRST in the
 * modifier chain, then [bubbleBody]. Ears lean to the right edge for my messages and the left for theirs.
 */
fun Modifier.bubbleOuter(style: BubbleStyle, mine: Boolean, plain: Boolean): Modifier {
    if (plain || style.ears == Ears.NONE) return this
    val fill = style.fill(mine)
    return this.drawBehind { drawEars(style.ears, fill, mine, if (style.solid) Outline else null) }.padding(top = style.ears.heightDp.dp)
}

/** Second half: the rounded, tinted (and optionally patterned) bubble itself. [plain] = no box at all (a bare sticker). */
fun Modifier.bubbleBody(style: BubbleStyle, mine: Boolean, plain: Boolean): Modifier {
    val shape = RoundedCornerShape(style.radius.dp)
    if (plain) return this.clip(shape)
    var m = this.clip(shape).background(style.fill(mine))
    if (style.solid) m = m.border(1.dp, Outline, shape)
    if (style.pattern.isNotEmpty()) m = m.emojiPattern(style.pattern, 0.2f)
    return m
}

/** Tiles [emoji] across the bubble in staggered rows, faintly, behind the text. */
private fun Modifier.emojiPattern(emoji: String, strength: Float): Modifier = drawWithCache {
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 13.dp.toPx()
        this.alpha = (strength * 255).toInt()
    }
    val step = 28.dp.toPx()
    onDrawBehind {
        val canvas = drawContext.canvas.nativeCanvas
        var row = 0
        var y = step * 0.7f
        while (y < size.height + step) {
            var x = if (row % 2 == 0) step * 0.2f else step * 0.7f
            while (x < size.width) {
                canvas.drawText(emoji, x, y, paint)
                x += step
            }
            y += step * 0.8f
            row++
        }
    }
}

/** Two ears sitting on the top edge (y = ears height). Everything is clipped at that edge so ears never overlap the bubble. */
private fun DrawScope.drawEars(ears: Ears, fill: Color, right: Boolean, outline: Color?) {
    val h = ears.heightDp.dp.toPx()
    val gap = 28.dp.toPx()
    val margin = 24.dp.toPx()
    val first = if (right) size.width - margin - gap else margin
    clipRect(0f, 0f, size.width, h) {
        for (i in 0..1) {
            val cx = first + i * gap
            val lean = if (i == 0) -1f else 1f
            when (ears) {
                Ears.BUNNY -> rotate(degrees = lean * 9f, pivot = Offset(cx, h)) {
                    drawOval(fill, topLeft = Offset(cx - 7.dp.toPx(), 0f), size = Size(14.dp.toPx(), 36.dp.toPx()))
                    if (outline != null) drawOval(outline, topLeft = Offset(cx - 7.dp.toPx(), 0f), size = Size(14.dp.toPx(), 36.dp.toPx()), style = Stroke(1.dp.toPx()))
                    drawOval(EarInner, topLeft = Offset(cx - 3.5.dp.toPx(), 5.dp.toPx()), size = Size(7.dp.toPx(), 22.dp.toPx()))
                }
                Ears.CAT -> {
                    val bw = 10.dp.toPx()
                    val outer = Path().apply {
                        moveTo(cx - bw, h + 1f); lineTo(cx + lean * 4.dp.toPx(), 0f); lineTo(cx + bw, h + 1f); close()
                    }
                    drawPath(outer, fill)
                    if (outline != null) drawPath(outer, outline, style = Stroke(1.dp.toPx()))
                    val iw = 5.dp.toPx()
                    val inner = Path().apply {
                        moveTo(cx - iw, h + 1f); lineTo(cx + lean * 3.dp.toPx(), 5.dp.toPx()); lineTo(cx + iw, h + 1f); close()
                    }
                    drawPath(inner, EarInner)
                }
                Ears.BEAR -> {
                    drawCircle(fill, radius = 10.dp.toPx(), center = Offset(cx, h + 3.dp.toPx()))
                    if (outline != null) drawCircle(outline, radius = 10.dp.toPx(), center = Offset(cx, h + 3.dp.toPx()), style = Stroke(1.dp.toPx()))
                    drawCircle(EarInner, radius = 5.dp.toPx(), center = Offset(cx, h + 3.dp.toPx()))
                }
                Ears.NONE -> {}
            }
        }
    }
}

/** A small tappable preview of a style (a sample bubble with its label), used by the picker in Settings. */
@Composable
fun BubbleStylePreview(style: BubbleStyle, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.width(92.dp).clip(shape)
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Line, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(vertical = 8.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.height(58.dp), contentAlignment = Alignment.BottomCenter) {
            Box(Modifier.bubbleOuter(style, true, false).bubbleBody(style, true, false).padding(horizontal = 10.dp, vertical = 7.dp)) {
                Text("hi ${style.emoji}", color = style.ink(), fontFamily = TermFont, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(style.label, color = if (selected) Accent else Dim, fontFamily = TermFont, fontSize = 10.sp)
    }
}
