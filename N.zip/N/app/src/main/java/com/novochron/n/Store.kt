package com.novochron.n

import android.content.Context

/**
 * Everything N remembers between launches.
 *
 * The shared repo defaults to the hardcoded value below — every install of this particular
 * build talks to the same repo out of the box. That default can be overridden per-install from
 * the debug panel (a "custom repo" set there is stored locally in prefs and takes priority);
 * clearing it falls back to the built-in default again.
 *
 * The GitHub token is NOT hardcoded here. It's injected at build time into BuildConfig from
 * either local.properties (git-ignored — see local.properties.example) for local builds, or
 * an N_GH_TOKEN GitHub Actions secret for CI builds. See app/build.gradle.kts.
 *
 * ⚠️ It still ends up baked into the built APK as a string constant — anyone with the APK can
 * pull it back out with a decompiler or even `strings`, same as before. What this setup fixes
 * is the token being committed to git/GitHub, where secret scanning would auto-revoke it (or
 * where anyone with repo access could read it out of history) regardless of whether the repo
 * is public or private. Use a token scoped to only this one repo, and if it's ever exposed
 * more widely than intended, rotate it on GitHub (Settings → Developer settings → Personal
 * access tokens).
 */
class Store(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("n_prefs", Context.MODE_PRIVATE)

    private val defaultRepo = "BreadCrafter1/chonke"

    /** The custom repo override, or "" if none is set (falls back to [defaultRepo]). */
    var customRepo: String
        get() = prefs.getString("custom_repo", "") ?: ""
        set(v) { prefs.edit().putString("custom_repo", v.trim()).apply() }

    /** The repo actually in use: the custom override if one is set, else the built-in default. */
    val repo: String get() = customRepo.ifBlank { defaultRepo }

    val token: String = BuildConfig.GITHUB_TOKEN

    var branch: String
        get() = prefs.getString("branch", "main") ?: "main"
        set(v) { prefs.edit().putString("branch", v.trim().ifBlank { "main" }).apply() }

    var name: String
        get() = prefs.getString("name", "") ?: ""
        set(v) { prefs.edit().putString("name", v.trim()).apply() }
}
